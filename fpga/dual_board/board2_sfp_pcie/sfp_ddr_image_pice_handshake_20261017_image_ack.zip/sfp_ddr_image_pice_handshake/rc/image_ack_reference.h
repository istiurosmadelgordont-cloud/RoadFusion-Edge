#ifndef ROADFUSION_IMAGE_ACK_REFERENCE_H
#define ROADFUSION_IMAGE_ACK_REFERENCE_H
/* Optional image receipt protocol. Same driver lock as frame DMA.
 * C99 adapter reference, not an installed Linux driver.
 */
#include "image_control_reference.h"

#define RF_IMG_ACK_ADDR 0x218u
#define RF_IMG_ACK_BYTES 128u
#define RF_IMG_RECEIVED 1u
#define RF_IMG_APPLIED 2u

struct rf_image_ack_ops {
    /* area 0: RECEIVED; area 1: APPLIED. Return decoded LE32, READ_ONCE.
     * Allocate coherent DMA memory or implement the required DMA sync here. */
    uint32_t (*read_word)(void *ctx,unsigned area,unsigned dw);
    /* Clear both 64-byte records before publishing a new unique cookie. */
    void (*clear)(void *ctx);
};

/* Zero-initialize once per known FPGA session; preserve last_cookie on STOP.
 * One outstanding image submission. Do not mix other image MMIO writers.
 */
struct rf_image_ack {
    const struct rf_image_ack_ops *ops;
    void *ctx;
    uint32_t cookie,last_cookie;
    unsigned bound,pending,flags;
};

/* Call after original four-buffer + STOP-status registration, while stopped.
 * addr/status must be the same DMA/IOVA addresses registered with the FPGA.
 * Binding is posted; the first receipt confirms the whole round trip.
 */
static inline int rf_image_ack_bind(struct rf_image_ack *a,const struct rf_hs *s,
        const struct rf_image_ack_ops *ops,void *ctx,const uint64_t addr[4],
        uint64_t status,uint64_t mailbox)
{
    unsigned i;
    if(!a || !s || !s->ops || !s->ops->bar_write32 || !ops ||
       !ops->read_word || !ops->clear || !addr || !s->configured ||
       s->running || s->stopping || a->bound || a->pending) return -1;
    if(!mailbox || (mailbox&63) ||
       mailbox>UINT64_C(0x100000000)-RF_IMG_ACK_BYTES ||
       !status || (status&63) || status>UINT64_C(0x100000000)-64) return -1;
    if(!(status+64<=mailbox || mailbox+RF_IMG_ACK_BYTES<=status)) return -1;
    for(i=0;i<4;i++) {
        if(!addr[i] || (addr[i]&63) || addr[i]>UINT64_C(0x100000000)-RF_BUFFER_BYTES)
            return -1;
        if(!(addr[i]+RF_BUFFER_BYTES<=mailbox || mailbox+RF_IMG_ACK_BYTES<=addr[i]))
            return -1;
    }
    a->ops=ops;a->ctx=ctx;a->cookie=0;a->flags=0;
    s->ops->bar_write32(s->ctx,RF_IMG_ACK_ADDR,(uint32_t)mailbox);
    a->bound=1;
    return 0;
}

/* Returns 0: submitted only. Poll RECEIVED/APPLIED for hardware confirmation.
 * Use all five words, even when only one switch changes. Never reuse cookies.
 * A timeout leaves pending set and memory mapped; STOP/drain before recovery.
 */
static inline int rf_image_submit_ack(struct rf_image_ack *a,const struct rf_hs *s,
        const struct rf_image_config *config,uint32_t *cookie)
{
    unsigned i;
    if(!a || !s || !s->ops || !s->ops->bar_write32 || !s->ops->write_barrier ||
       !config || !cookie || !a->bound || !a->ops || !a->ops->clear ||
       a->pending || !s->configured || s->stopping || a->last_cookie==UINT32_MAX)
        return -1;
    a->cookie=++a->last_cookie;a->flags=0;a->pending=1;
    a->ops->clear(a->ctx);
    s->ops->write_barrier(s->ctx);
    for(i=0;i<5;i++)
        s->ops->bar_write32(s->ctx,RF_IMG_WORD0+i*4u,config->word[i]);
    s->ops->bar_write32(s->ctx,RF_IMG_COMMIT,a->cookie);
    *cookie=a->cookie;
    return 0;
}

static inline int rf_image_ack_matches(const struct rf_image_ack *a,
        const struct rf_hs *s,unsigned area)
{
    unsigned i;
    for(i=0;i<16;i++)
        if(a->ops->read_word(a->ctx,area,i)!=a->cookie) return 0;
    s->ops->read_barrier(s->ctx);
    return a->ops->read_word(a->ctx,area,0)==a->cookie;
}

/* Returns bit0 RECEIVED, bit1 APPLIED; 0 waiting; -1 invalid/stopping.
 * APPLIED means a frame ACK occurred, not that that frame is already on screen.
 */
static inline int rf_image_poll_ack(struct rf_image_ack *a,const struct rf_hs *s)
{
    if(!a || !s || !s->ops || !s->ops->read_barrier || !a->bound ||
       !a->ops || !a->ops->read_word || !a->cookie || s->stopping) return -1;
    if(rf_image_ack_matches(a,s,0)) a->flags|=RF_IMG_RECEIVED;
    if((a->flags&RF_IMG_RECEIVED) && rf_image_ack_matches(a,s,1))
        a->flags|=RF_IMG_APPLIED;
    if(a->flags&RF_IMG_APPLIED) a->pending=0;
    return (int)a->flags;
}

/* Use with the original rf_hs_request_stop(). Only a real STOP ACK unbinds
 * the mailbox. Re-register 0x218 before the next acknowledged submission.
 */
static inline int rf_image_ack_poll_stop(struct rf_image_ack *a,struct rf_hs *s)
{
    int result;
    if(!a || !s || !s->ops) return -1;
    result=rf_hs_poll_stop(s);
    if(result==1) { a->bound=0;a->pending=0;a->cookie=0;a->flags=0; }
    return result;
}
#endif
