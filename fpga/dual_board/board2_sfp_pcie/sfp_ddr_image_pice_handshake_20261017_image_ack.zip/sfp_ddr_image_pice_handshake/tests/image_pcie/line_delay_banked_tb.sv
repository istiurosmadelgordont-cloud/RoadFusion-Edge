`timescale 1ns/1ps
module line_delay_case #(
    parameter WIDTH=58, LINE=2200, EXTRA=18
)(input clk,input rst_n,input [31:0] random_data);
    localparam TOTAL=LINE+EXTRA;
    wire [WIDTH-1:0] din={random_data,~random_data};
    wire [WIDTH-1:0] dout;
    reg [WIDTH-1:0] history[0:TOTAL-1];
    integer i,history_index=0,checks=0;
    video_line_delay #(.DATA_WIDTH(WIDTH),.LINE_CLOCKS(LINE),.EXTRA_CLOCKS(EXTRA)) dut(
        .clk(clk),.rst_n(rst_n),.pre_data(din),.post_data(dout));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            for(i=0;i<TOTAL;i=i+1)history[i]=0;
            history_index=0;
        end
        else begin
            // Independent N-clock history, stored circularly to keep the
            // reference model constant-time even for a full 2200-clock line.
            history[history_index]=din;
            history_index=history_index==TOTAL-1 ? 0 : history_index+1;
        end
        #1;
        if(dout!==history[history_index])
            $fatal(1,"line delay mismatch width=%0d line=%0d extra=%0d got=%h expected=%h",WIDTH,LINE,EXTRA,dout,history[history_index]);
        checks=checks+1;
    end
endmodule

module line_delay_banked_tb;
    reg clk=0,rst_n=0;
    reg [31:0] random_data=32'h3a7416de;
    always #5 clk=~clk;
    always @(negedge clk)
        random_data={random_data[30:0],random_data[31]^random_data[21]^random_data[1]^random_data[0]};
    line_delay_case #(.WIDTH(58),.LINE(2200),.EXTRA(18)) a(clk,rst_n,random_data);
    line_delay_case #(.WIDTH(31),.LINE(2200),.EXTRA(48)) b(clk,rst_n,random_data);
    line_delay_case #(.WIDTH(27),.LINE(2200),.EXTRA(48)) c(clk,rst_n,random_data);
    line_delay_case #(.WIDTH(1),.LINE(2200),.EXTRA(48)) d(clk,rst_n,random_data);
    line_delay_case #(.WIDTH(22),.LINE(2048),.EXTRA(3)) e(clk,rst_n,random_data);
    line_delay_case #(.WIDTH(8),.LINE(2049),.EXTRA(1)) f(clk,rst_n,random_data);
    line_delay_case #(.WIDTH(8),.LINE(4095),.EXTRA(2)) g(clk,rst_n,random_data);
    line_delay_case #(.WIDTH(5),.LINE(16),.EXTRA(5)) h(clk,rst_n,random_data);
    line_delay_case #(.WIDTH(5),.LINE(17),.EXTRA(1)) j(clk,rst_n,random_data);
    line_delay_case #(.WIDTH(7),.LINE(3),.EXTRA(1)) k(clk,rst_n,random_data);
    initial begin
        repeat(3)@(negedge clk);rst_n=1;
        repeat(1000)@(negedge clk);#2;rst_n=0;
        repeat(3)@(negedge clk);rst_n=1;
        repeat(14000)@(negedge clk);#2;rst_n=0;
        repeat(3)@(negedge clk);rst_n=1;
        repeat(15000)@(negedge clk);
        $display("PASS split line RAM: 10 cases, 30000 data clocks, reset before/after fill, bit-exact full raster delay");
        $finish;
    end
endmodule
