`timescale 1ns/1ps
module dma_input_debug_tb;
    reg clk=0,pix=0,rstn=0,vs=0,de=0;
    reg [15:0] rgb=0;
    always #5 clk=~clk;
    always #7 pix=~pix;
    pcie_dma_ctrl dut(
        .clk(clk),.pix_clk_out(pix),.rstn(rstn),
        .axis_master_tvalid(1'b0),.axis_master_tdata(128'd0),
        .axis_master_tkeep(4'd0),.axis_master_tlast(1'b0),.axis_master_tuser(8'd0),
        .ep_bus_num(8'd1),.ep_dev_num(5'd0),.AXIS_S_TREADY(1'b1),
        .hdmi_data_in(rgb),.vs_in(vs),.de_in(de),
        .image_cfg_ack(1'b0),.image_ready(1'b1));
    task pixels(input integer count,input integer first);
        integer n;
        for(n=0;n<count;n=n+1)begin
            @(negedge pix);de=1;rgb=first+n;
        end
        @(negedge pix);de=0;
    endtask
    task latch_frame;
        @(negedge pix);vs=1;
        repeat(3)@(negedge pix);
        vs=0;
    endtask
    task check(input bit ok,input string msg);
        if(!ok)$fatal(1,"%s",msg);
    endtask
    initial begin
        repeat(3)@(negedge pix);rstn=1;
        force dut.frame_active=1'b0;
        repeat(5)@(negedge pix);
        pixels(5,16'h1000);#1;
        check(dut.dbg_image_unselected==0,"DE-low unselected flag");
        force dut.frame_active=1'b1;
        repeat(5)@(negedge pix);
        pixels(12,16'h2000);
        dut.u_hdmi_pcie_fifo.inject_full=1;
        pixels(4,16'h3000);
        dut.u_hdmi_pcie_fifo.inject_full=0;
        repeat(4)@(negedge pix);
        latch_frame();
        check(dut.dbg_image_pixels_last==21,"processed DE pixel count");
        check(dut.dbg_fifo_pixels_last==12,"actual FIFO write pixel count");
        check(dut.dbg_first_rgb565==16'h2000 && dut.dbg_last_rgb565==16'h200b,"first/last accepted RGB565");
        check(dut.dbg_input_overflow_last,"last frame overflow not retained");
        pixels(9,16'h4000);latch_frame();
        check(dut.dbg_image_pixels_last==9 && dut.dbg_fifo_pixels_last==9,"next frame counters not independent");
        check(!dut.dbg_input_overflow_last,"overflow sticky across frames");
        check(dut.dbg_first_rgb565==16'h4000 && dut.dbg_last_rgb565==16'h4008,"next frame RGB samples");
        rstn=0;#2;
        check(dut.dbg_image_pixels_last==0 && dut.dbg_fifo_pixels_last==0 && !dut.dbg_input_overflow_last,"debug reset");
        release dut.frame_active;
        $display("PASS DMA input debug: unselected pixels, accepted pixels, FIFO full, frame snapshots, RGB565 samples, reset");
        $finish;
    end
endmodule
