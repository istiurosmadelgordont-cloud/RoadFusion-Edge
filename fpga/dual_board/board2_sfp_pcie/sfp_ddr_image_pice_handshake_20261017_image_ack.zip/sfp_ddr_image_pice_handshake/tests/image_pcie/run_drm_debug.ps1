param([string]$Iverilog='iverilog',[string]$Vvp='vvp',[string]$OutputDirectory='')
$ErrorActionPreference='Stop'
$testsRoot=Split-Path $PSScriptRoot -Parent
$projectRoot=Split-Path $testsRoot -Parent
if(!$OutputDirectory){$OutputDirectory=Join-Path $PSScriptRoot '.out_drm'}
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null

$outputPath=Join-Path $OutputDirectory 'line_delay_banked_tb.vvp'
& $Iverilog -g2012 -s line_delay_banked_tb -o $outputPath (Join-Path $projectRoot 'source/src/common/video_line_delay.v') (Join-Path $PSScriptRoot 'line_delay_banked_tb.sv')
if($LASTEXITCODE -ne 0){throw 'Line RAM test compilation failed'}
& $Vvp $outputPath
if($LASTEXITCODE -ne 0){throw 'Line RAM simulation failed'}

$outputPath=Join-Path $OutputDirectory 'dma_input_debug_tb.vvp'
& $Iverilog -g2012 -s dma_input_debug_tb -o $outputPath (Join-Path $projectRoot 'source/source/pcie_dma_ctrl.v') (Join-Path $testsRoot 'fifo_model.v') (Join-Path $PSScriptRoot 'dma_input_debug_tb.sv')
if($LASTEXITCODE -ne 0){throw 'DMA input debug test compilation failed'}
& $Vvp $outputPath
if($LASTEXITCODE -ne 0){throw 'DMA input debug simulation failed'}
