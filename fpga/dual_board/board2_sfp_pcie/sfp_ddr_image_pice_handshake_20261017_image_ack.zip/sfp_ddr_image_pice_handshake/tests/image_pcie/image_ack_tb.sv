`timescale 1ns/1ps
module image_ack_tb;
    reg clk=0,pix=0,rstn=0,pix_rst=0,image_ready=1;
    always #5 clk=~clk;
    always #7 pix=~pix;
    reg rxvalid=0,rxlast=0;
    reg [127:0] rxdata=0;
    reg [3:0] rxkeep=0;
    reg [7:0] rxuser=0;
    wire rxready,valid,last,user;
    wire [127:0] data;
    reg ready=1,vs=0,de=0,frame_start=0;
    reg random_backpressure=0;
    reg [31:0] lfsr=32'h12345678;
    always @(negedge clk) if(random_backpressure) begin
        lfsr={lfsr[30:0],lfsr[31]^lfsr[21]^lfsr[1]^lfsr[0]};
        ready=lfsr[0] || lfsr[2];
    end
    wire [159:0] requested,active;
    wire apply_toggle,ack_toggle,busy;
    image_runtime_control runtime(.clk(pix),.rst_n(pix_rst),
        .frame_start(frame_start),.requested_config(requested),
        .apply_toggle(apply_toggle),.frame_config(),.active_config(active),
        .pending(),.ack_toggle(ack_toggle));
    pcie_dma_ctrl #(.IMAGE_TLP_COUNT(2)) dut(
        .clk(clk),.pix_clk_out(pix),.rstn(rstn),
        .axis_master_tvalid(rxvalid),.axis_master_tready(rxready),
        .axis_master_tdata(rxdata),.axis_master_tkeep(rxkeep),
        .axis_master_tlast(rxlast),.axis_master_tuser(rxuser),
        .image_ready(image_ready),.image_cfg_ack(ack_toggle),.image_cfg_data(requested),
        .image_cfg_apply(apply_toggle),.image_cfg_busy(busy),
        .ep_bus_num(8'h01),.ep_dev_num(5'h00),
        .AXIS_S_TREADY(ready),.AXIS_S_TVALID(valid),.AXIS_S_TDATA(data),
        .AXIS_S_TLAST(last),.AXIS_S_TUSER(user),
        .hdmi_data_in(16'h1234),.vs_in(vs),.de_in(de),
        .video_enhance_lightdown_num(),.video_enhance_lightdown_sw(),
        .video_enhance_darkup_num(),.video_enhance_darkup_sw());
    localparam MAILBOX=32'h09000000,STOP_ADDR=32'h08000000;
    localparam [159:0] DEFAULT_CONFIG=160'h0080c040020301900000410000f38034000001c0;
    function [31:0] swap(input [31:0] v);
        swap={v[7:0],v[15:8],v[23:16],v[31:24]};
    endfunction
    task tick(input integer n); repeat(n) @(negedge clk); endtask
    task check(input bit good,input string message);
        if(!good) $fatal(1,"%s at %t",message,$time);
    endtask
    task command_keep(input [11:0] addr,input [31:0] value,
                      input [3:0] header_keep,input [3:0] payload_keep);
        @(negedge clk);rxvalid=1;rxlast=0;rxkeep=header_keep;rxuser=8'h10;rxdata=0;
        rxdata[31:24]=8'h40;rxdata[9:0]=1;rxdata[39:32]=8'h0f;rxdata[75:64]=addr;
        @(negedge clk);rxlast=1;rxkeep=payload_keep;rxdata={96'd0,swap(value)};
        @(negedge clk);rxvalid=0;rxlast=0;tick(2);
    endtask
    task cmd(input [11:0] addr,input [31:0] value);
        command_keep(addr,value,7,1);
    endtask
    task words(input [31:0] switches);
        cmd(12'h200,switches);cmd(12'h204,32'h00f38034);cmd(12'h208,32'h00004100);
        cmd(12'h20c,32'h02030190);cmd(12'h210,32'h0080c040);
    endtask
    task submit(input [31:0] switches,input [31:0] cookie);
        words(switches);cmd(12'h214,cookie);
    endtask
    task pixel_frame;
        @(negedge pix);frame_start=1;@(negedge pix);frame_start=0;tick(20);
    endtask
    task video_frame;
        @(negedge clk);vs=1;tick(12);vs=0;tick(10);
    endtask

    // Model ARM memory at the external PCIe TX boundary, decoding every beat.
    integer beat=0,kind=0,received_packets=0,applied_packets=0,stop_packets=0;
    integer image_packets=0,frame_packets=0,j,n,ack_packets=0;
    integer ack_data_stalls=0;
    reg [31:0] address,packet_cookie,stop_cookie=0;
    reg [31:0] mailbox_received[0:15],mailbox_applied[0:15];
    reg [31:0] token[0:3];
    reg saw_applied_6=0,stalled=0;
    reg [127:0] held_data;
    reg held_last;
    always @(posedge clk) if(rstn) begin
        if(valid && !ready && dut.packet_kind==3 && dut.tx_state==5)
            ack_data_stalls++;
        if(stalled && (!valid || data!==held_data || last!==held_last))
            $fatal(1,"AXIS receipt/image packet changed under backpressure");
        stalled=valid && !ready;held_data=data;held_last=last;
        if(valid && ready) begin
            if(beat==0) begin
                check(!last && data[31:24]==8'h40 && data[9:0]==16,"Bad TX header");
                address=data[95:64];kind=0;
                if(address==MAILBOX) kind=1;
                else if(address==MAILBOX+64) kind=2;
                else if(address==STOP_ADDR) kind=3;
                else begin
                    check(address>=32'h01000000 && address<32'h05000000,"Unexpected DMA destination");
                    if(address[23:0]==128) kind=4;
                end
                beat=1;
            end else begin
                check(last==(beat==4),"Bad TX TLAST");
                if(kind!=0) begin
                    if(beat==1) packet_cookie=swap(data[31:0]);
                    for(j=0;j<4;j=j+1) begin
                        check(swap(data[j*32+:32])==packet_cookie,"Nonuniform ACK/token payload");
                        if(kind==1) mailbox_received[(beat-1)*4+j]=packet_cookie;
                        if(kind==2) mailbox_applied[(beat-1)*4+j]=packet_cookie;
                    end
                end
                if(last) begin
                    case(kind)
                        0: image_packets=image_packets+1;
                        1: begin received_packets++;ack_packets++;end
                        2: begin
                            applied_packets++;ack_packets++;
                            if(packet_cookie==6) saw_applied_6=1;
                        end
                        3: begin stop_packets++;stop_cookie=packet_cookie;end
                        4: begin frame_packets++;token[packet_cookie[1:0]]=packet_cookie;end
                    endcase
                    beat=0;
                end else beat=beat+1;
            end
        end
    end
    task wait_receipt(input [31:0] cookie,input bit applied);
        integer timeout,k;
        bit match;
        begin
            timeout=0;match=0;
            while(!match && timeout<400) begin
                tick(1);timeout++;match=1;
                for(k=0;k<16;k=k+1)
                    if((applied ? mailbox_applied[k] : mailbox_received[k])!=cookie) match=0;
            end
            check(match,applied ? "APPLIED receipt missing" : "RECEIVED receipt missing");
        end
    endtask
    task clear_mailbox;
        integer k;
        for(k=0;k<16;k=k+1) begin mailbox_received[k]=0;mailbox_applied[k]=0;end
    endtask
    task stop_wait(input [31:0] cookie);
        integer timeout;
        begin
            cmd(12'h130,cookie);timeout=0;
            while(stop_cookie!=cookie && timeout<400) begin tick(1);timeout++;end
            check(stop_cookie==cookie,"STOP receipt missing");
            tick(10);check(!valid && !dut.stop_pending && !dut.image_return_addr_valid,"STOP not quiescent");
        end
    endtask
    integer count_before,applied_before,image_before,frame_before,timeout;
    initial begin
        clear_mailbox();for(n=0;n<4;n=n+1) token[n]=0;
        tick(5);rstn=1;pix_rst=1;tick(8);
        cmd(12'h218,MAILBOX);check(!dut.image_return_addr_valid,"Mailbox accepted without DMA config");
        for(n=1;n<=4;n=n+1) cmd(12'h110,n*32'h01000000);
        cmd(12'h180,STOP_ADDR);
        cmd(12'h218,32'hffffffc0);check(!dut.image_return_addr_valid,"128-byte mailbox wrapped");
        cmd(12'h218,MAILBOX+1);check(!dut.image_return_addr_valid,"Unaligned mailbox accepted");
        cmd(12'h218,32'h01000040);check(!dut.image_return_addr_valid,"Mailbox overlaps image");
        cmd(12'h218,STOP_ADDR);check(!dut.image_return_addr_valid,"Mailbox overlaps STOP");
        cmd(12'h218,STOP_ADDR-64);check(!dut.image_return_addr_valid,"Mailbox second half overlaps STOP");
        cmd(12'h218,32'hffffff80);check(dut.image_return_addr_valid,"Valid high mailbox rejected");
        stop_wait(32'h12345678);
        submit(32'h1c1,32'h100);tick(40);check(ack_packets==0,"Unbound mailbox emitted ACK");
        pixel_frame();check(!busy,"Unbound legacy image control broken");
        cmd(12'h218,MAILBOX);check(dut.image_return_addr_valid,"Mailbox bind failed");
        cmd(12'h218,MAILBOX+128);check(dut.image_return_addr==MAILBOX,"Live mailbox rebind accepted");
        cmd(12'h180,MAILBOX+64);check(dut.status_addr==STOP_ADDR,"STOP region rebound into mailbox");
        submit(32'h1c2,1);wait_receipt(1,0);tick(30);
        check(applied_packets==0 && mailbox_applied[0]==0,"APPLIED before video frame ACK");
        check(dut.image_rx_word_mask==0,"Word mask not reset after commit");
        pixel_frame();wait_receipt(1,1);check(active[31:0]==32'h1c2,"Receipt/config mismatch");
        $display("PASS address validation, optional compatibility, RECEIVED before frame, APPLIED after frame");

        count_before=ack_packets;cmd(12'h200,32'h1c3);cmd(12'h214,32'h101);tick(35);
        pixel_frame();tick(20);check(ack_packets==count_before,"Partial config earned full receipt");
        check(active[31:0]==32'h1c3,"Partial legacy commit behavior changed");
        cmd(12'h200,32'h1c0);
        command_keep(12'h204,32'h00f38034,15,1);
        cmd(12'h208,32'h4100);cmd(12'h20c,32'h02030190);cmd(12'h210,32'h0080c040);
        check(dut.image_rx_word_mask==5'b11101,"Rejected header counted as received word");
        cmd(12'h214,32'h102);tick(30);pixel_frame();
        check(ack_packets==count_before,"Malformed header earned receipt");
        words(32'h1c0);command_keep(12'h214,32'h103,7,15);tick(25);
        check(ack_packets==count_before,"Malformed commit payload earned receipt");
        submit(32'h1c1,2);wait_receipt(2,0);pixel_frame();wait_receipt(2,1);
        $display("PASS incomplete/rejected writes cannot claim a full parameter receipt");

        cmd(12'h190,1);dut.u_hdmi_pcie_fifo.supply=0;video_frame();
        check(dut.frame_active && dut.buffer_state[dut.active_slot]==1,"Streaming reservation failed");
        ready=0;submit(32'h1c2,3);wait(valid && dut.packet_kind==3);tick(3);
        @(negedge clk);vs=1;tick(12);vs=0;tick(4);
        check(dut.buffer_state[dut.active_slot]==0,"VS during receipt leaked WRITING buffer");
        cmd(12'h130,32'h12345679);tick(15);
        check(dut.stop_pending && valid && stop_packets==1,"STOP truncated stalled receipt");
        ready=1;wait_receipt(3,0);
        timeout=0;while(stop_cookie!=32'h12345679 && timeout<300) begin tick(1);timeout++;end
        check(stop_cookie==32'h12345679,"STOP failed after receipt drain");
        count_before=ack_packets;pixel_frame();tick(50);
        check(!valid && ack_packets==count_before,"Mailbox wrote after STOP ACK");
        dut.u_hdmi_pcie_fifo.supply=1;
        $display("PASS receipt backpressure, VS cancellation, STOP drains and disables mailbox");

        cmd(12'h218,MAILBOX);clear_mailbox();submit(32'h1c3,4);wait_receipt(4,0);
        applied_before=applied_packets;
        @(negedge pix);pix_rst=0;image_ready=0;tick(20);
        check(applied_packets==applied_before,"Video reset manufactured APPLIED");
        @(negedge pix);pix_rst=1;image_ready=1;tick(30);
        check(applied_packets==applied_before,"Ready transition manufactured APPLIED");
        pixel_frame();wait_receipt(4,1);check(active[31:0]==32'h1c3,"Reset restore lost config/cookie");
        submit(32'h1c0,5);wait_receipt(5,0);
        submit(32'h1c1,6);wait_receipt(6,0);submit(32'h1c2,7);wait_receipt(7,0);
        pixel_frame();wait_receipt(5,1);pixel_frame();wait_receipt(7,1);
        check(!saw_applied_6 && active[31:0]==32'h1c2,"Coalesced cookie falsely reported APPLIED");
        $display("PASS video reset cannot fake APPLIED, queued snapshots keep matching cookies");

        // ACK traffic during real image packets must not advance the image count.
        cmd(12'h190,1);image_before=image_packets;frame_before=frame_packets;
        video_frame();wait(frame_packets==frame_before+1);tick(10);
        check(image_packets==image_before+2,"Original frame packet count changed");
        cmd(12'h170,token[0]);
        image_before=image_packets;frame_before=frame_packets;
        ready=0;video_frame();wait(valid && dut.packet_kind==0);
        submit(32'h1c1,8);ready=1;wait_receipt(8,0);pixel_frame();wait_receipt(8,1);
        timeout=0;while(frame_packets!=frame_before+1 && timeout<500) begin tick(1);timeout++;end
        check(frame_packets==frame_before+1 && image_packets==image_before+2,
              "Interleaved image ACK changed image DMA addressing/count");
        stop_wait(32'h12345680);
        cmd(12'h218,MAILBOX);random_backpressure=1;
        count_before=received_packets;applied_before=applied_packets;
        for(n=9;n<25;n=n+1) begin
            clear_mailbox();submit(32'h1c0 | (n&3),n);
            tick(25);pixel_frame();wait_receipt(n,0);wait_receipt(n,1);
        end
        random_backpressure=0;ready=1;tick(10);
        check(received_packets==count_before+16 && applied_packets==applied_before+16,
              "Random backpressure lost or duplicated a two-stage reply");
        check(ack_data_stalls>0,"Random run did not exercise receipt payload backpressure");
        stop_wait(32'h12345681);
        $display("PASS 16 serial requests with random receipt payload backpressure stalls=%0d",ack_data_stalls);
        check(beat==0,"Incomplete TX packet");
        $display("IMAGE ACK TESTS PASSED receipts=%0d applied=%0d image=%0d frame=%0d stop=%0d",
                 received_packets,applied_packets,image_packets,frame_packets,stop_packets);
        $finish;
    end
    initial begin #2000000;$fatal(1,"Global image ACK timeout");end
endmodule
