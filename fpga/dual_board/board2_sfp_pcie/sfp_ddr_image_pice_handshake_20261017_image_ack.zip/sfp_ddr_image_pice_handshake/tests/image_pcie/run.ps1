param([string]$Iverilog='iverilog',[string]$Vvp='vvp',[string]$OutputDirectory='')
$ErrorActionPreference='Stop'
$projectRoot=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
if(!$OutputDirectory){$OutputDirectory=Join-Path $PSScriptRoot '.out'}
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$rtl=@(Get-ChildItem -Path (Join-Path $projectRoot 'source/src/common/*.v'),(Join-Path $projectRoot 'source/src/img/*.v') | ForEach-Object FullName)
$rtl+=@((Join-Path $projectRoot 'source/source/pcie_dma_ctrl.v'),
    (Join-Path $projectRoot 'tests/fifo_model.v'))
foreach($name in @('control_cdc_tb','image_ack_tb','dma_image_concurrent_tb','tone_luma_tb','tone_pipeline_tb','image_serial_tb','post_ddr_integration_tb')){
    $sources=$rtl+@((Join-Path $PSScriptRoot "$name.sv"))
    if($name -eq 'post_ddr_integration_tb'){
        $sources+=@((Join-Path $projectRoot 'source/hdmi_ddr_pcie.v'),
            (Join-Path $projectRoot 'source/source/sync_generator.v'),
            (Join-Path $PSScriptRoot 'peripheral_witnesses.v'))
    }
    $outputPath=Join-Path $OutputDirectory "$name.vvp"
    & $Iverilog -g2012 -s $name -o $outputPath @sources
    if($LASTEXITCODE -ne 0){throw "$name compilation failed"}
    $result=& $Vvp $outputPath 2>&1
    $exitCode=$LASTEXITCODE
    $result | Tee-Object -FilePath (Join-Path $OutputDirectory "$name.log")
    if($exitCode -ne 0 -or "$result" -match 'FATAL|Error:' -or "$result" -notmatch 'PASS'){
        throw "$name simulation failed"
    }
}
