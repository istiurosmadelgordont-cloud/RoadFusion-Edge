param([string]$Gcc='gcc',[string]$OutputDirectory='')
$ErrorActionPreference='Stop'
if(!$OutputDirectory){$OutputDirectory=Join-Path $PSScriptRoot '.out'}
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
foreach($name in @('rc_reference_test','image_ack_reference_test')){
    $binary=Join-Path $OutputDirectory "$name.exe"
    & $Gcc -std=c99 -Wall -Wextra -Werror (Join-Path $PSScriptRoot "$name.c") -o $binary
    if($LASTEXITCODE -ne 0){throw "$name build failed"}
    & $binary
    if($LASTEXITCODE -ne 0){throw "$name tests failed"}
}
