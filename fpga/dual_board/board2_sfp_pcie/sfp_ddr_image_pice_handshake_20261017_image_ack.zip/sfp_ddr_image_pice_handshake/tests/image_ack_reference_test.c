#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "../rc/image_ack_reference.h"

struct mock {
    uint32_t words[2][16],stop[16];
    unsigned offset[80],bar_count,rb,wb,cleared;
    uint32_t value[80];
};
static uint32_t read_word(void *ctx,unsigned area,unsigned dw)
{ return ((struct mock *)ctx)->words[area][dw]; }
static uint32_t read_stop(void *ctx,unsigned slot,unsigned dw)
{ assert(slot==RF_STATUS_SLOT);return ((struct mock *)ctx)->stop[dw]; }
static void clear(void *ctx)
{ struct mock *m=ctx;memset(m->words,0,sizeof(m->words));m->cleared=1; }
static void clear_stop(void *ctx,unsigned slot)
{ assert(slot==RF_STATUS_SLOT);memset(((struct mock *)ctx)->stop,0,64); }
static void rb(void *ctx) { ((struct mock *)ctx)->rb++; }
static void wb(void *ctx) { ((struct mock *)ctx)->wb++; }
static void bar(void *ctx,unsigned offset,uint32_t value)
{
    struct mock *m=ctx;
    assert(m->bar_count<80);
    if(offset>=RF_IMG_WORD0 && offset<=RF_IMG_COMMIT) assert(m->cleared && m->wb);
    m->offset[m->bar_count]=offset;m->value[m->bar_count++]=value;
}
static void fill(struct mock *m,unsigned area,uint32_t cookie)
{ unsigned i;for(i=0;i<16;i++)m->words[area][i]=cookie; }
int main(void)
{
    const struct rf_hs_ops hs_ops={read_stop,clear_stop,rb,wb,bar};
    const struct rf_image_ack_ops ack_ops={read_word,clear};
    struct mock m;struct rf_hs s;struct rf_image_ack a;
    struct rf_image_config config=rf_image_default();
    const uint64_t addr[4]={0x1000000,0x2000000,0x3000000,0x4000000};
    uint32_t cookie=0;unsigned i,count_before;
    memset(&m,0,sizeof(m));memset(&s,0,sizeof(s));memset(&a,0,sizeof(a));
    assert(rf_hs_init(&s,&hs_ops,&m)==0);
    assert(rf_image_ack_bind(&a,&s,&ack_ops,&m,addr,0x8000000,0x9000000)==-1);
    s.configured=1;
    assert(rf_image_ack_bind(&a,&s,&ack_ops,&m,addr,0x8000000,0xffffffc0)==-1);
    assert(rf_image_ack_bind(&a,&s,&ack_ops,&m,addr,0x8000000,0x9000001)==-1);
    assert(rf_image_ack_bind(&a,&s,&ack_ops,&m,addr,0x8000000,addr[1])==-1);
    assert(rf_image_ack_bind(&a,&s,&ack_ops,&m,addr,0x8000000,0x8000000-64)==-1);
    assert(rf_image_ack_bind(&a,&s,&ack_ops,&m,addr,0x8000000,0x9000000)==0);
    assert(m.bar_count==1 && m.offset[0]==RF_IMG_ACK_ADDR);
    assert(rf_image_ack_bind(&a,&s,&ack_ops,&m,addr,0x8000000,0xa000000)==-1);
    assert(rf_image_submit_ack(&a,&s,&config,&cookie)==0 && cookie==1);
    assert(m.bar_count==7 && m.wb==1);
    for(i=0;i<5;i++) {
        assert(m.offset[i+1]==RF_IMG_WORD0+i*4);
        assert(m.value[i+1]==config.word[i]);
    }
    assert(m.offset[6]==RF_IMG_COMMIT && m.value[6]==cookie);
    assert(rf_image_poll_ack(&a,&s)==0);
    assert(rf_image_submit_ack(&a,&s,&config,&cookie)==-1);
    fill(&m,0,1);m.words[0][15]=0;
    assert(rf_image_poll_ack(&a,&s)==0); /* partial 64-byte receipt */
    m.words[0][15]=1;assert(rf_image_poll_ack(&a,&s)==RF_IMG_RECEIVED);
    fill(&m,1,1);m.words[1][7]=0;
    assert(rf_image_poll_ack(&a,&s)==RF_IMG_RECEIVED);
    m.words[1][7]=1;
    assert(rf_image_poll_ack(&a,&s)==(RF_IMG_RECEIVED|RF_IMG_APPLIED) && !a.pending);
    assert(rf_image_submit_ack(&a,&s,&config,&cookie)==0 && cookie==2);
    fill(&m,0,1);fill(&m,1,1);assert(rf_image_poll_ack(&a,&s)==0); /* stale cookie */
    fill(&m,1,2);assert(rf_image_poll_ack(&a,&s)==0); /* applied alone is insufficient */
    fill(&m,0,2);assert(rf_image_poll_ack(&a,&s)==3);
    assert(rf_image_submit_ack(&a,&s,&config,&cookie)==0 && cookie==3);
    assert(rf_hs_request_stop(&s,0x12345678)==0);
    assert(rf_image_poll_ack(&a,&s)==-1);
    assert(rf_image_ack_poll_stop(&a,&s)==0 && a.bound && a.pending);
    for(i=0;i<16;i++)m.stop[i]=0x12345678;
    assert(rf_image_ack_poll_stop(&a,&s)==1 && !a.bound && !a.pending);
    assert(rf_image_ack_bind(&a,&s,&ack_ops,&m,addr,0x8000000,0x9000000)==0);
    assert(rf_image_submit_ack(&a,&s,&config,&cookie)==0 && cookie==4);
    fill(&m,0,4);fill(&m,1,4);assert(rf_image_poll_ack(&a,&s)==3);
    a.last_cookie=UINT32_MAX;count_before=m.bar_count;
    assert(rf_image_submit_ack(&a,&s,&config,&cookie)==-1 && m.bar_count==count_before);
    puts("IMAGE ACK RC TESTS PASSED: ranges, ordered writes, partial/stale receipts, two stages, STOP, cookie exhaustion");
    return 0;
}
