> 2026-10-17：新增可选图像参数 RECEIVED/APPLIED 回传；寄存器 `0x218`、128字节独立DMA区、完整提交请求编号与STOP后重新登记规则见 [两阶段确认协议](IMAGE_PARAMETER_ACK.md)。旧接口不启用该协议时保持原行为。

# DDR后图像处理整合（2026-10-15）

目标工程为 `sfp_ddr_image_pice_handshake`（含image）。打开本目录原有 `hdmi_ddr_pice.pds`，顶层仍为 `hdmi_ddr_pcie`。

## 数据通路

```text
原SFP接收/解码 → DDR保存原始RGB565
 → 原DDR读FIFO（原de_o读使能不变）
 → 恢复视频流，VS/HS/DE延1拍对齐FIFO同步读响应
 → RGB888/VS/HS/DE统一入口寄存
 → DCP去雾 → RGB转YCbCr → Y双边降噪 → Gamma → CLAHE
 → 原暗光增强/高光压制 → 高光保护 → YCbCr转RGB
 → 公共输出寄存 ┬ HDMI RGB888/VS/HS/DE
                └ 原PCIe DMA RGB565/VS/DE
```

全部图像算法来自 `06_hdmi_loop/06_hdmi_loop/source/src`，未改变算法源码；其中 `legacy_tone_luma.v` 已经整合原暗光/高光曲线，不再串接旧 `video_enhance` 的第二组颜色转换。

暗光增强：`Y <= dark_threshold` 时增加 `(dark_threshold-Y)>>3`。
高光压制：`Y >= light_threshold` 时减少 `(Y-light_threshold)>>3`。
两者共同作用后饱和到0～255，Cb/Cr按对应像素延迟。原高光压制与soft-knee高光保护是两个独立开关。

原 `video_enhance.v/rgb2yuv.v/yuv2rgb.v` 保留文件及PDS来源，但不再例化。图像参数控制已经合入手写 `source/source/pcie_dma_ctrl.v`，与原DMA命令共用RX_HEADER/RX_PAYLOAD/RX_DROP解析状态机及 `command_value` 端序转换。顶层只例化一个 `pcie_dma_ctrl`，由它输出 `image_cfg_data/image_cfg_apply/image_cfg_busy`，并接收像素域 `image_cfg_ack/image_ready`。

原独立 `source/src/img/pcie_image_control.v` 及PDS来源已删除；五字暂存、快照提交、ACK跨域同步、待处理槽与视频复位恢复均在 `pcie_dma_ctrl` 内实现。旧暗光/高光寄存器输出继续保留，实际生效值以 `image_cfg_active` 为准。
SFP和PCIe的IP核、IP生成的.v/.vp文件、FIFO、DDR控制和原FDC保持不变。手写 `pcie_dma_ctrl.v` 只扩展图像参数接口和接收命令逻辑，原TX状态机、DMA四缓冲所有权、FIFO及其接线保持不变。DMA像素格式仍为RGB565，取公共RGB888的R[7:3]/G[7:2]/B[7:3]。

PDS中移除了原 `synthesize/hdmi_ddr_pcie_syn.fic` 的自动插核引用，原FIC文件保留。该配置插入两套旧FLA核，另占25.5块DRM，加入完整图像流水线后会达到158.5/134而无法映射。移除只影响抓取核，不改变数据/控制链路，所有源码调试标记保留。以后新增FLA时须重新规划采样宽度、深度和RAM预算。

默认分辨率1920×1080、行消隐280。核心固定延迟为 `2*(VIDEO_LENGTH+IMAGE_H_BLANK)+96`，默认4496拍，与所有开关状态无关；核心前后各1拍公共寄存。DDR同步读响应为1拍，因此读请求到公共输出计4499级流水（下游采样口径）。HDMI为高有效VS，核心为低有效VS，入口/出口各取反一次。HS使用两个2248拍等长行RAM延迟。
全关时走原RGB延迟旁路，RGB565扩展方式仍为低位补0，避免颜色转换往返改变原图。

## RC兼容控制

沿用BAR1逻辑32位数值与原有端序适配；每条命令使用对齐的1 DW MWr32，FirstBE=F/LastBE=0，现有IP格式为三DW头一拍、payload一拍。

| BAR1字节偏移 | 写值 | 效果 |
|---|---|---|
| 0x140 | 低8位阈值0～255 | 开启原高光压制并设置阈值，自动提交 |
| 0x150 | 低8位阈值0～255 | 开启原暗光增强并设置阈值，自动提交 |
| 0x160 | 任意 | 关闭上述两路并清阈值，自动提交；其他算法保持 |
| 0x200 | word0 | 暂存开关 |
| 0x204 | word1 | 暂存DCP参数 |
| 0x208 | word2 | 暂存降噪及原亮度阈值 |
| 0x20C | word3 | 暂存CLAHE参数 |
| 0x210 | word4 | 暂存CLAHE/高光参数 |
| 0x214 | 非零，通常写1 | 提交五个参数字的完整快照；写0无操作 |

旧命令可以继续通过原RC程序使用。需要两种曲线同一帧生效时，推荐设置五字配置后统一提交。
原DMA的0x110/130/170/180/190/1A0、帧尾和STOP语义不变。图像控制无需启动图像DMA即可工作；RC可在没有视频时提前下发，配置等待恢复后的帧边界生效。

## 五个参数字

| 字 | 位 | 功能 | 默认/范围 |
|---|---|---|---|
| word0 | 0/1/2/3 | DCP/Gamma/CLAHE/高光保护 | 各自0关1开，默认均关 |
| word0 | 4/5 | Y双边降噪/t双边滤波 | 各自0关1开，默认关 |
| word0 | 6/7/8 | 天空/防光晕/阴影保护 | 默认均1，随所属主算法起作用 |
| word0 | 10:9 | 保留 | 清0 |
| word0 | 11/12 | 原高光压制/原暗光增强 | 各自0关1开，默认关 |
| word1 | 7:0 | TX_MIN | 默认52，0钳为1 |
| word1 | 15:8 | SKY_TX_MIN | 默认128，小于TX_MIN则钳到TX_MIN |
| word1 | 23:16 | OMEGA | 默认243，0～255 |
| word2 | 8:0 | DENOISE_MIX | 默认256，最大256 |
| word2 | 14:9 | DENOISE_SIGMA | 默认32，支持16/32/48，其余按32 |
| word2 | 23:16 | 原暗光增强阈值 | 默认0，0～255 |
| word2 | 31:24 | 原高光压制阈值 | 默认0，0～255 |
| word3 | 15:0 | CLAHE_CLIP_LIMIT | 默认400，0钳为1 |
| word3 | 18:16 | CLAHE_STRENGTH | 默认3，最大4 |
| word3 | 25:19 | CLAHE_SHADOW_GAIN | 默认64，最大64 |
| word4 | 7:0 | CLAHE_BOOST_LIMIT | 默认64，0～255 |
| word4 | 15:8 | HIGHLIGHT_KNEE | 默认192，0～255 |
| word4 | 24:16 | HIGHLIGHT_SLOPE | 默认128，最大256 |

其余位清0。Gamma使用原LUT；分辨率、CAPABLE、CLAHE_DONOR_MODE、BILATERAL_GUIDE_ENABLE仍为编译参数。

| 配置示例 | word0 | word1 | word2 | word3 | word4 |
|---|---|---|---|---|---|
| 原图旁路 | 000001C0 | 00F38034 | 00004100 | 02030190 | 0080C040 |
| 仅原暗光，阈值96 | 000011C0 | 00F38034 | 00604100 | 02030190 | 0080C040 |
| 仅原高光，阈值192 | 000009C0 | 00F38034 | C0004100 | 02030190 | 0080C040 |
| 原暗光96+原高光192 | 000019C0 | 00F38034 | C0604100 | 02030190 | 0080C040 |
| DCP+Gamma+CLAHE+高光保护 | 000001CF | 00F38034 | 00004100 | 02030190 | 0080C040 |

## 提交、复位与联调

RC在同一驱动锁内按顺序写五个字，最后写0x214=1。每次提交复制完整快照；此后写暂存参数不会改变正在跨域的配置。配置总线保持到像素域在帧边界应用并回传ACK，ACK经两拍同步回PCIe域。没有帧同步时会等待。旧命令会基于当前暂存整包自动提交，因此五字配置写入过程中应保持同一驱动锁，避免与旧命令交错。

控制器保留一份在途快照和一份待处理快照。连续提交过快时，待处理槽保留最新整包，中间配置可能被合并；不会撕裂参数或丢失最后一次设定。若需要逐项观察，每次修改后至少等待3个完整视频帧；CLAHE也需要重新建立统计。这是调参接口，不提供每次请求必达的事务队列。

此实现维持原PCIe发送通路，没有新增状态DMA、TX仲裁或BAR读完成器。**不要用readl(BAR1)查询配置或flush写入**。`rc/image_control_reference.h` 的提交返回值仅表示调用了写回调，不代表已上板确认生效。使用现有驱动的有序MMIO/端序适配回调；该头文件不是Linux驱动。

控制器跟随原DMA的 `rstn`（同步后的PCIe核复位）；板复位或PCIe核复位后RC应重新发送配置。PLL失锁、DDR未初始化或fram_done撤销会复位像素链路；若PCIe控制器没有同时复位，它保留最近一次已提交完整快照，视频恢复后自动重送。恢复时先同步释放复位，再等待DDR恢复VS高电平开始完整帧。停止/启动图像DMA本身不清除图像参数。

FLA可观察：`image_cfg_active`（已钳位实际参数）、`image_cfg_pending/ack`、`image_cfg_busy`、`image_rst_n`、`ddr_stream_*`、`image_stage_*`、`image_output_*`。`cfg_busy`包括在途与待处理快照。原DMA导出的video_enhance_*不用于新流水线，不能代替实际参数观测。

## 验证入口

`tests/image_pcie/run.ps1 -Iverilog <iverilog.exe> -Vvp <vvp.exe>`运行合并后CDC控制、DMA传输期间调参、亮度算术、色度时序、整链串联和DDR后整合测试。`tests/run.ps1`继续运行原DMA握手回归。

外围见证模块仅用于RTL集成仿真，未替代厂商SFP/DDR/PCIe时序模型；最新合并验证见 `PCIE_CONTROL_MERGE_VALIDATION.md`，第一轮整合记录见 `IMAGE_INTEGRATION_VALIDATION.md`。需要在PDS重新综合、布局布线并检查148.5MHz像素域时序，旧bitstream不包含本次修改。
