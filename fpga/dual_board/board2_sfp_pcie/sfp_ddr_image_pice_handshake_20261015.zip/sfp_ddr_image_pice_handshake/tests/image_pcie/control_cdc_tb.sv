`timescale 1ns/1ps
module control_cdc_tb;
    localparam [159:0] RESET = 160'h0080c040020301900000410000f38034000001c0;
    reg clk=0,pix=0,rst_n=0;
    always #4 clk=~clk;
    always #7 pix=~pix;
    reg valid=0,last=0;
    wire rxready;
    reg [127:0] data=0;
    reg [3:0] keep=0;
    reg [7:0] user=0;
    reg frame_start=0;
    reg image_ready=1;
    wire [159:0] request,active,frame_config;
    wire apply,ack,pending,busy;
    reg [159:0] crossing_before,active_before;
    reg outstanding_before;
    integer transitions=0,hold_checks=0,bad;

    pcie_dma_ctrl #(.IMAGE_TLP_COUNT(2)) dut(
        .clk(clk),.pix_clk_out(pix),.rstn(rst_n),.axis_master_tvalid(valid),
        .axis_master_tready(rxready),.axis_master_tdata(data),
        .axis_master_tkeep(keep),.axis_master_tlast(last),
        .axis_master_tuser(user),.image_cfg_ack(ack),.image_ready(image_ready),
        .image_cfg_data(request),.image_cfg_apply(apply),.image_cfg_busy(busy),
        .ep_bus_num(8'd1),.ep_dev_num(5'd0),.AXIS_S_TREADY(1'b1),
        .hdmi_data_in(16'd0),.vs_in(1'b0),.de_in(1'b0));
    image_runtime_control video(
        .clk(pix),.rst_n(rst_n && image_ready),.frame_start(frame_start),
        .requested_config(request),.apply_toggle(apply),
        .frame_config(frame_config),.active_config(active),
        .pending(pending),.ack_toggle(ack));

    task tick(input integer count);
        repeat(count) @(negedge clk);
    endtask
    task cmd(input [11:0] addr,input [31:0] value);
        @(negedge clk);
        valid=1;last=0;keep=7;user=8'h10;data=0;
        data[31:24]=8'h40;data[9:0]=1;data[39:32]=8'h0f;data[75:64]=addr;
        @(negedge clk);
        last=1;keep=1;data={96'd0,value[7:0],value[15:8],value[23:16],value[31:24]};
        @(negedge clk);valid=0;last=0;
    endtask
    task boundary;
        repeat(16) @(negedge pix);
        frame_start=1;
        @(negedge pix);frame_start=0;
        tick(12);
    endtask
    task check(input bit condition,input string message);
        if(!condition) $fatal(1,"%s at %t",message,$time);
    endtask

    always @(posedge clk) if(rst_n) begin
        crossing_before=request;
        outstanding_before=apply!=dut.image_ack_sync;
        #1;
        if(outstanding_before) begin
            check(request===crossing_before,"Crossing packet changed before ACK");
            hold_checks++;
        end
    end
    always @(posedge pix) if(rst_n) begin
        active_before=active;
        #1;
        if(active!==active_before) begin
            check(frame_start,"Configuration changed during active frame");
            transitions++;
        end
    end

    initial begin
        tick(6);rst_n=1;tick(8);
        check(active===RESET,"Bad default config");
        cmd('h200,'h000001c2);
        cmd('h204,'h00e0a060);
        tick(30);boundary();
        check(active===RESET && !busy,"Shadow writes applied without commit");
        cmd('h214,1);tick(40);
        check(active===RESET && busy,"Commit must wait for a frame");
        // Edits after COMMIT must not alter its crossing snapshot.
        cmd('h200,'h000001c1);
        boundary();
        check(active[31:0]=='h1c2 && active[63:32]=='h00e0a060,"Torn or overwritten commit");
        check(!busy,"ACK failed to release source mailbox");

        // Several requests while there is no frame: first in flight, latest queued.
        cmd('h214,1);tick(20);
        cmd('h200,'h1c4);cmd('h214,1);
        cmd('h200,'h1c8);cmd('h214,1);
        tick(30);boundary();
        check(active[31:0]=='h1c1,"First in-flight snapshot was lost");
        boundary();
        check(active[31:0]=='h1c8 && !busy,"Latest pending snapshot was lost");

        cmd('h150,96);cmd('h140,192);
        boundary();boundary();
        check(active[12:11]==3 && active[95:80]=='hc060,"Legacy dark/light commands failed");
        check(active[3:0]==8,"Legacy command changed other switches");
        cmd('h160,0);boundary();
        check(active[12:11]==0 && active[95:80]==0 && active[3:0]==8,"Legacy clear failed");

        // Malformed BE, BAR, payload keep, multi-DW, and unaccepted traffic.
        for(bad=0;bad<7;bad=bad+1) begin
            @(negedge clk);
            valid=1;last=0;keep=7;user=8'h10;data=0;
            data[31:24]='h40;data[9:0]=1;data[39:32]='h0f;data[75:64]='h200;
            case(bad)
                0:data[39:32]=3;
                1:user=0;
                2:data[9:0]=2;
                3:keep=3;
                5:valid=0;
                6:keep=15;
            endcase
            @(negedge clk);last=1;keep=bad==4?0:1;data=0;
            @(negedge clk);valid=0;last=0;valid=0;
        end
        cmd('h214,0);tick(20);boundary();
        check(active[3:0]==8 && !busy,"Malformed traffic changed image config");
        cmd('h214,1);boundary();
        check(active[3:0]==8,"Malformed shadow write was accepted");

        // Clamp all fields through the real runtime controller.
        cmd('h200,'hffffffff);cmd('h204,0);cmd('h208,'hffffffff);
        cmd('h20c,'hffffffff);cmd('h210,'hffffffff);cmd('h214,1);
        boundary();
        check(active[31:0]=='h19ff && active[63:32]==257,"Mode/DCP sanitization failed");
        check(active[72:64]==256 && active[78:73]==32,"Denoise sanitization failed");
        check(active[114:112]==4 && active[121:115]==64 && active[152:144]==256,
              "CLAHE/highlight sanitization failed");

        // Reset with a pending packet; both handshake ends must start again.
        cmd('h150,127);tick(20);rst_n=0;tick(8);
        check(active===RESET,"Destination did not reset");
        rst_n=1;tick(8);check(!busy && request===RESET,"Mailbox did not reset");
        cmd('h150,80);boundary();
        check(active[12] && active[87:80]==80,"First commit after reset failed");
        image_ready=0;tick(12);
        cmd('h150,110);tick(20);
        check(active===RESET && busy,"Video reset did not hold new request");
        image_ready=1;boundary();
        check(active[12] && active[87:80]==110 && !busy,"No-video configuration was lost");
        image_ready=0;tick(12);image_ready=1;boundary();
        check(active[12] && active[87:80]==110 && !busy,"Video reset did not restore last commit");
        check(transitions>=10 && hold_checks>100,"Insufficient CDC coverage");
        $display("PASS PCIe image control CDC transitions=%0d stable_bus_checks=%0d",transitions,hold_checks);
        $finish;
    end
    initial begin #100000; $fatal(1,"CDC timeout"); end
endmodule
