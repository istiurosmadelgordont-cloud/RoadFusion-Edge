# 合并版PDS记录摘要

PDS 2022.2-SP6.4：Compile、ADS Synthesize、Device Map通过。
未运行Place & Route、布局布线后时序签核或位流生成。

映射资源：LUT 16198/42800，FF 20071/64200，APM 51.5/84，DRM 133/134。
未推导锁存器。旧FIC抓取核引用已在工程PDS中移除。

本摘要来自同次代码整合的本地PDS日志，并非上传阶段重新构建。
原SFP、PCIe相关IP生成文件没有为本次上传修改。
