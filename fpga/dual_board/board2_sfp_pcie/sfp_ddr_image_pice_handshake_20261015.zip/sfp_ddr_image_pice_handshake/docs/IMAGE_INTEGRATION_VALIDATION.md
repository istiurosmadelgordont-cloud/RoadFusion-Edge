> 本文保留第一轮整合的历史验证记录。随后已按要求把独立图像控制逻辑并入 `pcie_dma_ctrl.v`，并删除 `pcie_image_control.v`；最新修改范围与验证结果见 [控制合并验证](PCIE_CONTROL_MERGE_VALIDATION.md)。下方“DMA源码未修改”等表述仅描述第一轮状态。

# 图像整合验证记录（2026-10-15）

验证对象：`sfp_ddr_image_pice_handshake`，PGL50H-6 FBG484，顶层 `hdmi_ddr_pcie`。
图像算法来自指定 `06_hdmi_loop/06_hdmi_loop/source/src`，排除DVIO封装，算法文件逐字节保持一致。

## 功能仿真

使用本机已有 Icarus Verilog 10.1 / vvp，全部通过。

| 测试 | 结果与覆盖 |
|---|---|
| control_cdc_tb | 10次配置变化、464次跨域总线保持检查；五字暂存/提交、帧边界ACK、在途包隔离、最新请求合并、旧0x140/150/160命令、非法BE/BAR/长度/keep、未握手输入、参数钳位、PCIe复位、无视频提前下发、视频复位后自动恢复 |
| tone_luma_tb | 720899次算术检查，独立Y/阈值穷举与8×256×256组双曲线组合 |
| tone_pipeline_tb | 7168个有效像素，4567个处理变化像素；RGB/色度/同步对应、静态30拍与运行时144拍缩小尺寸延迟 |
| image_serial_tb | 12帧，46405次同步检查、46595次亮度/色度阶段检查；旁路768、仅DCP512、原亮度曲线1024、多项串联768个有效像素；11次帧间待提交检查 |
| post_ddr_integration_tb | 实际顶层+实际图像核心+实际DMA控制器，外围使用见证模块和同步DDR读响应模型；106151次输入对齐、105284次输出同步、110955次DDR原始写侧及HDMI/DMA共源检查；旁路4608、处理1536个像素，192行首尾完整，3次配置变化及3次复位恢复 |
| 原handshake_tb | 原源码不修改；4缓冲所有权、全部占满丢帧、乱序/陈旧/重复RELEASE、空FIFO、随机反压、VS/头及VS/TLAST碰撞、STOP、溢出与token耗尽；42帧完成、139个TLP |

运行入口：`tests/image_pcie/run.ps1` 与原 `tests/run.ps1`。串联测试中 `$isunknown` 改用等价归约异或检查，以适配已有Icarus 10.1；顶层测试的期望历史使用环形缓存，避免大数组逐拍移位。所有这些改动仅在testbench中。

`control_cdc_tb` 单独覆盖新版控制器的无视频及重送恢复；DDR后整合测试覆盖完整数据路径和原有复位/配置切换。外围见证模块不实现真实SFP、DDR PHY或PCIe PHY，不能替代板上联调。

## PDS实现检查

使用本机PDS 2022.2-SP6.4，在独立验证目录中引用本次源文件及原有IP：

- Compile：通过。
- ADS Synthesize：通过，未推导锁存器。
- Device Map：通过，日志明确输出 `Design 'hdmi_ddr_pcie' has been successfully mapped to architecture-specific objects.` 与 `Process "Device Map" done.`。

最终器件映射：

| 资源 | 使用 | 可用 |
|---|---:|---:|
| LUT | 16228 | 42800 |
| FF | 20082 | 64200 |
| APM | 51.5 | 84 |
| DRM（18K等效） | 133 | 134 |

初次带旧FIC插核映射时为158.5/134并失败。原因是原FIC的两套FLA另占25.5块DRM；本次PDS移除旧FIC工程引用后映射通过。原FIC文件和源码调试标记均保留，数据/控制链路不受影响。

PDS仍报告原设计的未约束外部端口等警告；没有改动原引脚、时钟约束及PCIe/SFP底层。最终验证未运行Place & Route或148.5MHz布局布线后时序签核，未生成/烧写新bitstream，未上板验证画质。器件RAM余量只有1块，后续FLA必须纳入预算。

## 修改范围

原功能RTL只改 `source/hdmi_ddr_pcie.v`；新增 `source/src/common`、`source/src/img` 下图像核心和PCIe参数控制器。PDS添加来源并取消旧FIC引用；新增测试、寄存器说明和RC回调参考，README/BUILD_STATUS加最新说明。

对原 `source`（除顶层）及 `ipcore` 共433个文件做SHA-256核对：全部保持不变，包括 `pcie_dma_ctrl.v`、DDR控制、各FIFO、SFP及PCIe IP/链路源码和原FDC。原DDR读使能、SFP写DDR路径、原PCIe发送路径及四缓冲协议未改。

RC参考头未集成到真实驱动；目标工程只提供原 `rc/handshake_reference.h`，本次新增 `rc/image_control_reference.h` 复用其有序BAR写回调。无需修改真实驱动即可继续使用旧暗光/高光命令；要启用新增算法，可将五字提交接口接入现有RC控制程序。
