# 图像控制合入PCIe DMA（2026-10-15）

按要求保留SFP/PCIe的IP核及IP生成的.v/.vp文件，把原独立 `pcie_image_control` 的全部逻辑移入手写 `source/source/pcie_dma_ctrl.v`。

## 当前结构

```text
PCIe IP接收AXIS
 → pcie_dma_ctrl 原RX解析状态机
       ├ 原地址登记、START/STOP、RELEASE命令
       └ 图像五字暂存、旧暗光/高光命令、整包提交
            → image_cfg_data / image_cfg_apply → image_processing_top
            ← image_cfg_ack / image_ready

处理后公共视频输出 → HDMI
                 → pcie_dma_ctrl 原FIFO/TX状态机 → PCIe IP发送AXIS
```

已经删除顶层的独立 `u_pcie_image_control` 例化、PDS中的对应来源和 `source/src/img/pcie_image_control.v` 文件。没有在DMA内部再次例化该模块，也没有保留第二套TLP接收解析器。

图像参数与原DMA命令共用 `RX_HEADER/RX_PAYLOAD/RX_DROP`、`rx_cmd_addr`、`command_value` 和 `endian32()`。原DMA命令的接收条件保持原样；增加 `image_rx_header_valid` 来保留图像接口对三DW头及单DW有效payload的严格检查。

寄存器地址、参数位定义、在途快照、最新待处理快照、像素域帧边界提交和视频恢复重送语义保持原整合版。新增模块端口为 `image_cfg_data/image_cfg_apply/image_cfg_busy/image_cfg_ack/image_ready`。

图像控制状态跟随DMA已有 `rstn` 复位。像素链路单独复位时，通过 `image_ready` 下降检测重新发送最近一次已提交配置。

## 不变范围

SHA-256核对472个其他源码/IP文件，全部不变；包括SFP/PCIe相关IP生成文件、SFP收发源码、DDR控制及FIFO、原FDC和全部图像算法源码。

原 `pcie_dma_ctrl` 从 `[H7]` TX状态机到文件末尾的FIFO例化，与合并前逐字相同；四缓冲所有权、包头/载荷、反压、START/STOP、RELEASE及视频格式保持原行为。未修改IP核驱动文件。

## 验证

- 合并后 `control_cdc_tb`：通过；10次配置变化、465次在途总线保持检查，覆盖新旧命令、非法格式、原子提交、参数钳位、复位、无视频等待和自动恢复。
- 原 `handshake_tb`：通过；42帧完成、139个TLP，原四缓冲、乱序/重复释放、随机反压、VS/STOP碰撞及溢出回归通过。
- 新增 `dma_image_concurrent_tb`：通过；在32帧带随机反压的真实DMA发送过程中穿插五字配置提交、旧暗光和高光命令，33次配置应用；原载荷/帧尾/缓冲所有权检查全部通过。
- 合并后完整DDR视频整合回归：通过；input=106151 sync=105284 rawwrites=110955 off=4608 processed=1536 changed=1536 DMA=110955 firstlast=192/192 configs=3 resets=3。检查DDR后像素/同步对齐、完整行首尾及HDMI/DMA共源。
- PDS 2022.2-SP6.4 Compile、ADS Synthesize、Device Map：通过；无锁存器。

最终器件映射：LUT 16198/42800，FF 20071/64200，APM 51.5/84，DRM 133/134。

全部图像算法沿用此前整合版本，亮度穷举与整链串联记录仍见 `IMAGE_INTEGRATION_VALIDATION.md`。未生成或烧写新bitstream，未执行布局布线后时序签核和板上验证。此前为RAM预算移除的旧FLA插核引用继续保持移除。

测试入口：`tests/image_pcie/run.ps1` 包含新增并行调参回归；`tests/run.ps1` 继续运行原DMA握手回归。
