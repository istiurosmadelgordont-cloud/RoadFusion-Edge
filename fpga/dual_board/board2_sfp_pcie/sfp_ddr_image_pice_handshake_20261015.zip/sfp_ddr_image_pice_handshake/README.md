# 板卡二：SFP、DDR后图像处理与PCIe四缓冲

当前版本：2026-10-15，来源 `sfp_ddr_image_pice_handshake`。本目录替换双板方案原板卡二；板卡一、ARM应用与以太网上位机沿用仓库现有版本。

用PDS 2022.2-SP6.4打开 [hdmi_ddr_pice.pds](hdmi_ddr_pice.pds)，顶层为 [hdmi_ddr_pcie](source/hdmi_ddr_pcie.v)，器件PGL50H / FBG484 / -6。

## 文档入口

- **[代码解说](docs/CODE_WALKTHROUGH.md)**：从顶层、SFP、DDR到图像流水线、PCIe命令和DMA状态机。
- **[RC控制PCIe指南](docs/RC_PCIE_CONTROL.md)**：BAR1寄存器、字节序、四缓冲、收帧/归还/停止、五字参数及场景示例。
- [图像整合说明](docs/PCIE_IMAGE_INTEGRATION.md)、[控制合并验证](docs/PCIE_CONTROL_MERGE_VALIDATION.md)。
- [四缓冲协议细节](docs/RC_HANDSHAKE_GUIDE.md)、[握手参考头](rc/handshake_reference.h)、[图像控制参考头](rc/image_control_reference.h)。
- [双板接线与板卡一映射](https://github.com/istiurosmadelgordont-cloud/RoadFusion-Edge/blob/main/fpga/dual_board/README.md)。

## 当前接线

```text
本板HDMI IN → SFP TX → 板卡一的一路输入
板卡一合成视频 → SFP RX → DDR原始RGB565
 → 恢复时序及对齐 → DCP → Y降噪 → Gamma → CLAHE
 → 原暗光增强/高光压制 → 高光保护 → 公共输出
                                      ├ HDMI RGB888
                                      └ PCIe RGB565四缓冲 → RC
```

图像参数已合入手写 `source/source/pcie_dma_ctrl.v`，与原DMA共用一套RX解析器；独立 `pcie_image_control.v` 已删除。SFP/PCIe的IP及生成文件按本地来源保存，没有为上传修改。

本版保留旧0x140/0x150/0x160暗光/高光命令，新增0x200~0x214五字整包提交；**没有旧20261011快照的0x220/0x224图像配置状态DMA接口**。STOP状态区仅用于DMA停止应答。参数作用于整帧合成图，四个缓冲不是四路独立视频。

主算法默认关闭，全关时保持原RGB旁路；辅助保护位随所属算法起作用。像素域帧边界提交、在途/最新待处理快照和视频恢复自动重送均保留。

## 验证与恢复

当前代码整合阶段通过控制CDC、原DMA、DMA期间调参、完整DDR视频回归，以及PDS Compile、综合和器件映射。映射资源LUT 16198/42800、FF 20071/64200、APM 51.5/84、DRM 133/134。

原FIC的两套FLA抓取核会使RAM超限，PDS已取消自动插核引用，源码调试标记保留。当前没有执行布局布线后时序签核或上板验收，**没有与本版对应的新生成位流**。本次上传排除了旧位流、构建缓存和历史impl.tcl操作脚本，恢复时从PDS重新构建。

运行 `tests/image_pcie/run.ps1` 和 `tests/run.ps1` 可进行RTL回归。实际RC需适配DMA分配、端序、MMIO写、内存屏障及消费者完成事件；参考头不是已安装的驱动，现有HS2应用与旧驱动的ABI仍须核对。

PDS设计输入共214个，上传前均已核对存在。来源复制与SHA-256见 [ORIGINAL_COPY_MANIFEST.csv](ORIGINAL_COPY_MANIFEST.csv)，完整文件哈希见 [SOURCE_MANIFEST.csv](SOURCE_MANIFEST.csv)，上传检查见 [SNAPSHOT_CHECKS.json](SNAPSHOT_CHECKS.json)，同次RTL测试日志见 [验证目录](docs/verification/20261015)。

`README.original.md`、`BUILD_STATUS.md`、`archive/` 和早期说明保留来源历史；最新结构和接口以本页及两份新指南为准。旧版可从Git历史恢复，勿混用两版控制协议或位流。

第三方IP声明保持原样，沿用 [私有工程权利通知](https://github.com/istiurosmadelgordont-cloud/RoadFusion-Edge/blob/main/fpga/dual_board/DISCLAIMER.md)。
