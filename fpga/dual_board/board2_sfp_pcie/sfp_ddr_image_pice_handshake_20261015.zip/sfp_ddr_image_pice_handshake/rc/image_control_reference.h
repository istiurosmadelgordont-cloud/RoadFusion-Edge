#ifndef ROADFUSION_IMAGE_CONTROL_REFERENCE_H
#define ROADFUSION_IMAGE_CONTROL_REFERENCE_H
/* Image BAR writes use the same ordered/endian-correct adapter as frame DMA.
 * Hold the existing driver lock across all five writes and COMMIT.
 * This is a C99 integration reference, not an installed PCIe/Linux driver.
 */
#include "handshake_reference.h"

#define RF_IMG_WORD0 0x200u
#define RF_IMG_COMMIT 0x214u
#define RF_IMG_DCP (UINT32_C(1)<<0)
#define RF_IMG_GAMMA (UINT32_C(1)<<1)
#define RF_IMG_CLAHE (UINT32_C(1)<<2)
#define RF_IMG_HIGHLIGHT (UINT32_C(1)<<3)
#define RF_IMG_DENOISE (UINT32_C(1)<<4)
#define RF_IMG_T_FILTER (UINT32_C(1)<<5)
#define RF_IMG_LIGHTDOWN (UINT32_C(1)<<11)
#define RF_IMG_DARKUP (UINT32_C(1)<<12)

struct rf_image_config {
    uint32_t word[5];
};

static inline struct rf_image_config rf_image_default(void)
{
    struct rf_image_config config={{UINT32_C(0x000001c0),
        UINT32_C(0x00f38034),UINT32_C(0x00004100),
        UINT32_C(0x02030190),UINT32_C(0x0080c040)}};
    return config;
}

/* Writes are posted: return 0 means submitted, not confirmed on hardware.
 * Hardware applies whole snapshots at a video frame boundary. While busy,
 * a single pending slot retains the latest COMMIT (intermediate ones coalesce).
 */
static inline int rf_image_submit(const struct rf_hs *s,
                                  const struct rf_image_config *config)
{
    unsigned i;
    if(!s || !s->ops || !s->ops->bar_write32 || !config) return -1;
    for(i=0;i<5;i++)
        s->ops->bar_write32(s->ctx,RF_IMG_WORD0+i*4u,config->word[i]);
    s->ops->bar_write32(s->ctx,RF_IMG_COMMIT,1);
    return 0;
}

/* Configure both legacy curves atomically through the full packet interface. */
static inline void rf_image_set_tone(struct rf_image_config *config,
                                     unsigned dark_enable,uint8_t dark_threshold,
                                     unsigned light_enable,uint8_t light_threshold)
{
    config->word[0] &= ~(RF_IMG_DARKUP|RF_IMG_LIGHTDOWN);
    if(dark_enable) config->word[0] |= RF_IMG_DARKUP;
    if(light_enable) config->word[0] |= RF_IMG_LIGHTDOWN;
    config->word[2] = (config->word[2]&UINT32_C(0x0000ffff)) |
        ((uint32_t)dark_threshold<<16) | ((uint32_t)light_threshold<<24);
}

#endif
