> 2026-10-17回传探针更新：FIC标识`IMAGE_ACK_RX_APPLIED_TX_20261017`，Core1/TP0为244位、TP1为245位，新增参数接收/生效cookie、接收掩码、回传地址使能及两类回包发送完成事件。仅改桌面工程；未上传、未启动PDS编译或烧录。见[探针说明](docs/IMAGE_PCIE_FIC.md)。

> 2026-10-17两阶段回传更新：新增可选 `0x218` 图像确认区地址；ARM 完整提交五字参数后分别收到 RECEIVED 与 APPLIED 两笔确认，带同一请求编号。原图像四缓冲和 STOP 协议保留，PCIe/SFP IP及生成文件不变。见 [ARM接口说明](docs/IMAGE_PARAMETER_ACK.md) 和 `rc/image_ack_reference.h`。本次通过RTL仿真与C99测试，未运行PDS位流编译、未下载；历史资源/时序结果不代表新版本。

> 2026-10-17参数探针更新：当前FIC为 `debug/image_pcie_debug.fic`，已加入完整接收参数 `image_shadow_config[159:0]` 与生效参数 `image_cfg_active[159:0]`。每核两个Trigger Port；本次未启动编译或生成位流。见 [参数接收与生效探针说明](docs/IMAGE_PCIE_FIC.md)。

> 2026-10-16 FIC更新：已加入 [debug/image_pcie_debug.fic](debug/image_pcie_debug.fic)，像素/PCIe两组分别133/172位，均256点；插核后DRM为126/134，器件映射通过。配置及使用见 [FIC说明](docs/IMAGE_PCIE_FIC.md)。DMA方式与上位机接口不变。

> 2026-10-16更新：行缓存分银行降低DRM，Device Map占用由133/134降为121.5/134；补充处理后图像进入PCIe DMA的Debugger探针。DMA方式、寄存器、四缓冲协议及上位机接口不变。调试信号、时钟和验证结果见 [DRM优化及图像入口调试](docs/DRM_REDUCTION_AND_PCIE_IMAGE_DEBUG.md)。资源统计未插入FLA采样核。

> 2026-10-15控制合并更新：图像参数控制已直接合入手写 `source/source/pcie_dma_ctrl.v`，删除独立 `pcie_image_control` 模块。SFP/PCIe的IP核及IP生成文件不变；原DMA发送与四缓冲协议不变。见 [当前接口说明](docs/PCIE_IMAGE_INTEGRATION.md) 和 [合并验证](docs/PCIE_CONTROL_MERGE_VALIDATION.md)。

> 2026-10-15更新：本工程已整合DDR后的完整图像流水线，HDMI/PCIe共用处理结果，支持原暗光/高光命令及五字PCIe配置。当前接线、寄存器及复位说明见 [PCIe图像整合说明](docs/PCIE_IMAGE_INTEGRATION.md)，本次验证见 [验证记录](docs/IMAGE_INTEGRATION_VALIDATION.md)。下方保留2026-09-19四缓冲握手的历史记录。

# 四缓冲握手版验证记录

日期：2026-09-19。功能源码：`source/source/pcie_dma_ctrl.v`，`PCIE_HS_20260919`。

## 已完成的验证

- Icarus Verilog 10.1：短帧控制器回归通过，42 个完成帧、139 个 TLP（包括被取消帧留下的完整 TLP 和 STOP 通知）。
- 32 帧固定种子随机背压，逐个图像 Payload DW 核对内容与顺序。
- 空闲分配、四块占满跳帧、乱序归还、错误/旧/重复 token、WRITING 槽拒绝归还、FIFO empty 等待、full 取消。
- 定向检查 VS 与 Header 握手同拍、VS 与 TLAST 同拍、STOP 与 TLAST 同拍；测试内断言确认这些同拍条件确实发生。
- STOP 在 Header 背压和帧尾途中到达时，已呈现 TLP 仍排完，随后回写正确 cookie。
- 序号耗尽时拒绝分配，不自然回绕。
- 完整 1080p 配置：64,800 个图像包 + 1 个帧尾 + 1 个 STOP ACK，合计 64,802 个 TLP；检查像素 Payload 顺序、尾地址、token、归还。
- RC 参考 C 代码使用 GCC 的 `-std=c99 -Wall -Wextra -Werror` 编译，模拟回调测试通过；覆盖地址溢出/重叠、半写入标记、重复完成、清零/屏障/MMIO 顺序、持有者未退出时拒绝重启。
- PDS 2022.2-SP6.4 完整工程 Compile 与 Synthesize 通过。验证在单独工程副本运行，交付包不含旧 bitstream/构建数据库。
- 当前桌面原工程 source 与起始快照逐文件比对一致；本次功能差异只在 PCIe 控制器。

## 结果摘要

```text
ALL TESTS PASSED image_packets=2 completions=42 packets=139
FULL FRAME TEST PASSED image_packets=64800 completions=1 packets=64802
RC REFERENCE TESTS PASSED: ranges, partial/stale marker, ownership, barriers, STOP/restart
Process "Compile" done.
Process "Synthesize" done.
```

## 工具警告和验证边界

Icarus 10.1 对原有带 synthesis 注释的标量 ANSI 端口输出 inherits dimensions 提示，以及数组 @* 敏感列表提示。仿真没有连接位宽错误；PDS 能完成分析和综合。

PDS 仍有厂商 IP 的常量/零次重复展开提示、constant probe loop 提示和未约束 I/O 时序警告。本记录不把综合成功等同于时序签核。

未做布局布线、真实 FIFO 时序/CDC 仿真、ARM 内核驱动编译、真实 PCIe DMA 字节序及一致性测试、DRM/RGA/NPU 联调、板级吞吐和长期压力测试。RC 参考代码的回调测试不能替代 Linux DMA API 与显示完成事件的板级验证。

已有的 DDR 页避让和增强算法/参数 CDC 问题继续保留，详见代码说明。本次只保证所测试控制器场景的缓冲所有权与 TLP 发送行为。
