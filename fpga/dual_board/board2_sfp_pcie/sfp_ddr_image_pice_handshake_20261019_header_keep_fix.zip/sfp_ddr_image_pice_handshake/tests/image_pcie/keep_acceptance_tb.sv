`timescale 1ns/1ps
// Diagnostic only: these are hypothetical IP output patterns, not board captures.
module keep_acceptance_tb #(parameter HEADER_FIXED=1);
    reg clk=0, rstn=0, valid=0, last=0;
    reg [127:0] data=0;
    reg [3:0] keep=0;
    reg [7:0] user=0;
    wire ready;
    always #5 clk=~clk;
    pcie_dma_ctrl #(.IMAGE_TLP_COUNT(2)) dut(
        .clk(clk),.pix_clk_out(clk),.rstn(rstn),
        .axis_master_tvalid(valid),.axis_master_tready(ready),
        .axis_master_tdata(data),.axis_master_tkeep(keep),
        .axis_master_tlast(last),.axis_master_tuser(user),
        .image_ready(1'b1),.image_cfg_ack(1'b0),
        .image_cfg_data(),.image_cfg_apply(),.image_cfg_busy(),
        .ep_bus_num(8'd1),.ep_dev_num(5'd0),.AXIS_S_TREADY(1'b1),
        .hdmi_data_in(16'd0),.vs_in(1'b0),.de_in(1'b0));
    task tick(input integer n); repeat(n) @(negedge clk); endtask
    task cmd(input [11:0] addr,input [31:0] value,
             input [3:0] hk,input [3:0] pk);
        @(negedge clk);valid=1;last=0;keep=hk;user=8'h10;data=0;
        data[31:24]=8'h40;data[9:0]=1;data[39:32]=8'h0f;data[75:64]=addr;
        @(negedge clk);last=1;keep=pk;
        data={96'd0,value[7:0],value[15:8],value[23:16],value[31:24]};
        @(negedge clk);valid=0;last=0;tick(5);
    endtask
    task scenario(input [3:0] hk,input [3:0] pk);
        rstn=0;tick(4);rstn=1;tick(8);
        cmd('h110,'h01000000,hk,pk);cmd('h110,'h02000000,hk,pk);
        cmd('h110,'h03000000,hk,pk);cmd('h110,'h04000000,hk,pk);
        cmd('h180,'h08000000,hk,pk);
        if(!dut.rc_cfg_ep_flag || !dut.status_addr_valid) $fatal(1,"Video setup failed");
        cmd('h218,'h09000000,hk,pk);
        cmd('h200,'h000011c0,hk,pk);cmd('h214,1,hk,pk);
        $display("header_keep=%h payload_keep=%h video_setup=%b mailbox_valid=%b shadow_WORD0=%h",
            hk,pk,dut.rc_cfg_ep_flag,dut.image_return_addr_valid,dut.image_shadow_config[31:0]);
        if((hk==7 || HEADER_FIXED) && pk==1) begin
            if(!dut.image_return_addr_valid || dut.image_shadow_config[31:0]!='h11c0)
                $fatal(1,"Expected image acceptance");
        end else begin
            if(dut.image_return_addr_valid || dut.image_shadow_config[31:0]!='h1c0)
                $fatal(1,"Expected strict keep rejection");
        end
        cmd('h190,1,hk,pk);
        if(!dut.running) $fatal(1,"START failed");
    endtask
    initial begin
        scenario(7,1);scenario(15,1);scenario(7,15);scenario(15,15);
        $display("PASS: HEADER_FIXED=%0d; current/candidate acceptance checked without hardware access.",HEADER_FIXED);
        $finish;
    end
endmodule
