> 本次发布分为主工程和PCIe仿真库两个ZIP。完整还原请把两个ZIP都解压到同一父目录，合并同名`sfp_ddr_image_pice_handshake`文件夹；SOURCE_MANIFEST.csv校验两包合并后的完整工程。

> 2026-10-19 最新源码快照：已修复 Logos PCIe IP 的3DW包头 `tkeep=1111` 被图像命令过滤的问题。图像写入仍要求单DW数据拍 `tkeep=0001`，视频DMA原有解析条件不变。参数接收、生效和回传通过9项离线回归；此发布未运行PDS位流构建或硬件下载，不附带位流。需要自行重建匹配位流。当前FIC为 `IMAGE_ACK_RX_APPLIED_TX_20261017`，Core0端口133/161位，Core1端口244/245位，均256点。下方较早记录保留为历史说明。

> 2026-10-17回传探针更新：FIC标识`IMAGE_ACK_RX_APPLIED_TX_20261017`，Core1/TP0为244位、TP1为245位，新增参数接收/生效cookie、接收掩码、回传地址使能及两类回包发送完成事件。仅改桌面工程；未上传、未启动PDS编译或烧录。见[探针说明](docs/IMAGE_PCIE_FIC.md)。

> 2026-10-17两阶段回传更新：新增可选 `0x218` 图像确认区地址；ARM 完整提交五字参数后分别收到 RECEIVED 与 APPLIED 两笔确认，带同一请求编号。原图像四缓冲和 STOP 协议保留，PCIe/SFP IP及生成文件不变。见 [ARM接口说明](docs/IMAGE_PARAMETER_ACK.md) 和 `rc/image_ack_reference.h`。本次通过RTL仿真与C99测试，未运行PDS位流编译、未下载；历史资源/时序结果不代表新版本。

> 2026-10-17参数探针更新：当前FIC为 `debug/image_pcie_debug.fic`，已加入完整接收参数 `image_shadow_config[159:0]` 与生效参数 `image_cfg_active[159:0]`。每核两个Trigger Port；本次未启动编译或生成位流。见 [参数接收与生效探针说明](docs/IMAGE_PCIE_FIC.md)。

> 2026-10-16 FIC更新：已加入 [debug/image_pcie_debug.fic](debug/image_pcie_debug.fic)，像素/PCIe两组分别133/172位，均256点；插核后DRM为126/134，器件映射通过。配置及使用见 [FIC说明](docs/IMAGE_PCIE_FIC.md)。DMA方式与上位机接口不变。

> 2026-10-16更新：行缓存分银行降低DRM，Device Map占用由133/134降为121.5/134；补充处理后图像进入PCIe DMA的Debugger探针。DMA方式、寄存器、四缓冲协议及上位机接口不变。调试信号、时钟和验证结果见 [DRM优化及图像入口调试](docs/DRM_REDUCTION_AND_PCIE_IMAGE_DEBUG.md)。资源统计未插入FLA采样核。

> 2026-10-15控制合并更新：图像参数控制已直接合入手写 `source/source/pcie_dma_ctrl.v`，删除独立 `pcie_image_control` 模块。SFP/PCIe的IP核及IP生成文件不变；原DMA发送与四缓冲协议不变。见 [当前接口说明](docs/PCIE_IMAGE_INTEGRATION.md) 和 [合并验证](docs/PCIE_CONTROL_MERGE_VALIDATION.md)。

> 2026-10-15更新：本工程已整合DDR后的完整图像流水线，HDMI/PCIe共用处理结果，支持原暗光/高光命令及五字PCIe配置。当前接线、寄存器及复位说明见 [PCIe图像整合说明](docs/PCIE_IMAGE_INTEGRATION.md)，本次验证见 [验证记录](docs/IMAGE_INTEGRATION_VALIDATION.md)。下方保留2026-09-19四缓冲握手的历史记录。

# HDMI → DDR → 图像增强 → PCIe：四缓冲握手版

本版在 PGL50H 工程上加入 RC 四缓冲所有权握手，标记 `PCIE_HS_20260919`。已占用的帧缓冲不会被固定轮转覆盖；RC 用完一帧后，写回该帧 token 才允许 FPGA 重用。无空闲槽时跳过整帧。

## 打开工程

使用 PDS 2022.2-SP6.4 打开本目录 `hdmi_ddr_pice.pds`，顶层仍为 `source/hdmi_ddr_pcie.v`。DDR、PCIe、FIFO、PLL IP 已包含在工程内，相对路径继承此前整合版。归档名称中的 20260916 是任务起始日期，完成日期为 2026-09-19。

## 文件入口

- [代码说明与改动记录](docs/CODE_NOTES.md)：H1～H11 改动位置及状态机解释。
- [RC 配合操作指南](docs/RC_HANDSHAKE_GUIDE.md)：寄存器、token、缓存同步、启动、归还、停止。
- [已注释的 PCIe 控制器](source/source/pcie_dma_ctrl.v)：本次唯一功能 RTL 修改。
- [RC 协议参考代码](rc/handshake_reference.h)：通过回调适配 MMIO 与 DMA，不是完整 PCI 驱动。
- [验证记录](BUILD_STATUS.md)：控制器仿真、C 参考测试、PDS 编译/综合与验证边界。
- [逐行 RTL 差异](docs/pcie_dma_ctrl_changes.patch)：与 archive 中原控制器比较。
- `archive/pcie_dma_ctrl.before_handshake.v`：改动前版本；该目录不参加当前工程编译。
- `SOURCE_MANIFEST.csv`：当前源码包文件哈希；archive 下 before_handshake 清单仅供历史对照。

## 上位机必须适配

旧版上位机不能直接使用新协议。默认仍为 1080p RGB565、64 字节图像 Payload，但需要：

1. 登记四个图像 DMA 地址和独立 64 字节状态区。
2. 写 START 后等待完整帧。
3. 校验帧尾的 32 位 token，处理/显示全部结束后清标记并 RELEASE。
4. 结束时发送 STOP(cookie)，收到独立状态区的匹配 ACK 后，再等待显示消费者退出并释放 DMA 内存。

`0x130` 的语义已变成 STOP，`0x170` 归还，`0x180` 状态地址，`0x190` 启动，`0x1A0` 清配置。详细步骤和字节序约定以 RC 指南为准。

## 复跑验证

在 Icarus Verilog 和 GCC 可执行文件已在 PATH 的环境：

```powershell
./tests/run.ps1
./tests/run.ps1 -ImagePackets 64800
./tests/run_rc.ps1
```

也可通过 `-Iverilog`、`-Vvp`、`-Gcc` 指定路径。短帧用例覆盖竞态；64800 用例单独检查完整一帧、帧尾及停止。仿真使用 FIFO 行为替身，不是厂商 FIFO 或板级仿真。

## 当前边界

已完成 PDS Compile/Synthesize；未重新布局布线、签核时序或上板验证。IP/未约束 I/O 等工程警告仍需处理。DDR 页避让、增强 RGB 饱和高位及增强参数 CDC 是此前已有问题，本次未修复。握手不改变 PCIe 链路带宽，也未加入 RGA/DRM 显示驱动。

厂商 IP 的版权和授权声明保持原样，使用及再分发仍须遵守对应授权。
