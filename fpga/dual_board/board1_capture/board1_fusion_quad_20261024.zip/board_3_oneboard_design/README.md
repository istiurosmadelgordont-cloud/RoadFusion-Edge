# 板卡一：四路采集、三路融合与按键切换（2026-10-24）

本版替换原 2026-09-27 板卡一快照。使用 **PDS 2022.2-SP6.4**，器件 **PGL50H / FBG484 / -6**，工程入口 `3_ddr_test.pds`，顶层 `test_ddr`（`source/ddr_test_top.v`）。

## 工程入口

当前目录打开 `3_ddr_test.pds`。现成调试位流为 `generate_bitstream/test_ddr_mode_switch_20261024.sbit`，
配套 FIC 为 `generate_bitstream/test_ddr_mode_switch_20261024.fic`；文件大小和 SHA256 见 `SOURCE_MANIFEST.csv`。

上电默认三路融合。**KEY2 / L15 / 3.3V / LVCMOS33 / 低电平按下**，每按一次在融合与四宫格间切换；KEY1 保留原复位功能。
按键直接使用用户已跑通的 `Key_anti_shake.v`，文件字节未改。外层 `video_mode_key.v` 将消抖电平下降沿转换为一次模式翻转；50MHz 下 MCNT=999999，约 20ms。长按、松开不连续切换。

| DDR 通道 | 输入 | 融合用途 | 四宫格位置 |
|---|---|---|---|
| 0 | HDMI | 左 | 左上 |
| 1 | 以太网1 | 中 | 右上 |
| 2 | 以太网0 | 右 | 左下 |
| 3 | SFP（板卡二回传输入） | 不参与 | 右下 |

每路源图为 960×540。融合输出 1920×540，显示在 1920×1080 上半区，下半区黑色；维持原 128 像素过渡，未启用窄羽化测试版本。四宫格铺满 1920×1080。HDMI 与 SFP 编码器取同一套输出画面。
当前 OV5640 模块仍保留，但未接入这四路。

## 本次增加的实现

新增 `source/fusion/quad_frame_renderer.v` 读取已锁定的四路源页，按象限生成完整结果帧。新增 `video_mode_key.v` 接入原消抖模块，顶层新增 `mode_key_n`，FDC/PCF 将 KEY2 绑定到 L15。

`panorama_output_top.v`、`fusion_ddr_pipeline.v`、`fusion_frame_writer.v`、`fusion_frame_reader.v` 增加模式选择、四宫格取样及像素打包/拆包。融合使用 RGB888/32bit，四宫格使用 RGB565/16bit，两种结果均为 1,036,800 个 32bit 字，共用原两个 4MiB 结果槽（字地址 0x1000000 / 0x1100000）。

按键先更新请求，当前渲染完成后再生成新模式的结果。完整结果帧生成后，缓冲与像素格式在垂直消隐期共同切换；按下到换画面存在渲染等待时间。
融合锁定前三路，四宫格锁定全部四路；第四路尚无有效帧时继续显示上一完整结果。页锁保证单路帧内一致，不保证四路独立视频具有同一曝光时刻。

保留已在旧融合版上板验证的显示读补水策略：FIFO 低于等于 96 字时优先读显示，补到 192 字；连续突发减少空隙。HDMI 名义时序为 150MHz、2200×1125，约 60.606Hz；新融合图生成速率由渲染决定，未生成新图时重复上一结果。

LUT 是针对当前三路测试视角离线估计的映射，并非 NVIDIA 官方标定，也不通用于所有片段。更换安装位姿、镜头、分辨率或裁剪需重新生成相应 LUT。

## 验证与已知限制

- 原消抖及外层切换单元测试通过：抖动、长按、松开、再次按下。
- 四宫格取样测试逐像素检查 2,073,600 像素，通过跨行/跨突发、通道与源页选择、输出反压和读延迟测试。
- 100MHz DDR / 150MHz 视频集成仿真完成“融合→四宫格→融合”：9 帧融合、9 帧四宫格、2 帧返回融合，6 次渲染，2 次按键翻转，欠读 0。叠加后台采集写竞争，DDR 读返回延迟 24～31 周期并含随机间隔。
- PDS 综合、映射、布局布线及新 bit 生成已完成；实际三个 FLA 核的宽度、触发端口和深度已核对。
- **物理时序未收敛，当前是上板调试版**：DDR Slow Setup −3.606ns，最差 DDR Hold −0.172ns；SFP 输入缩放像素路径 Slow Setup −2.107ns。名义 60.606Hz 不代表已通过物理时序签核。最终报告在包内 `report_timing/test_ddr.rtr`。
- 新按键/四宫格集成 bit 尚未下载或完成板级验收。此前用户确认的上半区完整显示、零欠读属于旧融合读修复版，不能替代本次新 bit 的上板结果。

仿真在工程根目录运行：

```tcl
do sim/panorama/run_key_unit.do
do sim/panorama/run_quad_unit.do
do sim/panorama/run_mode_switch.do
```

Mode 仿真第四路采用彩色测试图；旧结果图片和编译缓存不打包。测试台及参考向量随工程提供，日志在 `docs/verification`。ModelSim 安装不同机器时需调整本地 `modelsim.ini` 中的库路径。

重建时从 Compile 开始，使用包内全部 RTL/IP/LUT 和 FDC/PCF，重新生成对应 bit/FIC。不要使用打开着的旧 PDS 工程窗口覆盖新源文件列表。FIC 内的原构建机器路径是来源记录，重新综合后的调试配置以本机生成结果为准。

## 与双板 / ARM 的关系

以太网0仍为 192.168.1.10 / A0-B1-C2-D3-E4-E4，以太网1仍为 192.168.1.11 / A0-B1-C2-D3-E1-E1，默认 UDP 1234；发送分辨率设为 960×540。完整接线见[双板系统说明](https://github.com/istiurosmadelgordont-cloud/RoadFusion-Edge/blob/main/fpga/dual_board/README.md)。
现有 ARM 按象限解析四路画面时，应切换到四宫格并核对新通道顺序；融合模式需由应用按融合画面处理。本次只替换板卡一，不修改板卡二、ARM 程序和上位机。

旧版源码可在 Git 历史中恢复。第三方 IP 和例程声明保留在工程包内，权利与许可见[系统免责声明](https://github.com/istiurosmadelgordont-cloud/RoadFusion-Edge/blob/main/fpga/dual_board/DISCLAIMER.md)。

