// Shared HDMI/SFP parallel video, with two-cycle synchronous framebuffer read alignment.
// Mode 0: four quadrants. Mode 1: 1920x540 panorama at y=0..539, black below.
// mode_toggle is a synchronous one-cycle event. A physical key requires debounce/CDC.
module fusion_video_window(
    input                   clk,
    input                   rst_n,
    input                   mode_toggle,
    input                   panorama_ready,
    input                   vs,
    input                   hs,
    input                   de,
    input       [11 : 0]    pixel_x,
    input       [11 : 0]    pixel_y,
    output                  read_enable,
    output                  read_panorama,
    output      [1 : 0]     read_channel,
    output      [20 : 0]    read_index,
    input       [23 : 0]    read_rgb,
    output reg              mode_active,
    output reg              hdmi_vs,
    output reg              hdmi_hs,
    output reg              hdmi_de,
    output reg  [23 : 0]    hdmi_rgb,
    output                  sfp_vs,
    output                  sfp_de,
    output      [15 : 0]    sfp_rgb565
);

    reg                     requested_mode;
    reg                     vs_d;
    reg                     vs_s0;
    reg                     hs_s0;
    reg                     de_s0;
    reg                     use_rgb_s0;
    wire        [11 : 0]    local_x;
    wire        [11 : 0]    local_y;
    wire                    use_rgb;

    assign local_x       = pixel_x >= 960 ? pixel_x - 12'd960 : pixel_x;
    assign local_y       = pixel_y >= 540 ? pixel_y - 12'd540 : pixel_y;
    assign use_rgb       = de && (!mode_active || (panorama_ready && pixel_y < 540));
    assign read_enable   = use_rgb;
    assign read_panorama = mode_active;
    assign read_channel  = {pixel_y >= 540, pixel_x >= 960};
    assign read_index    = mode_active ? pixel_y * 21'd1920 + pixel_x : local_y * 21'd960 + local_x;
    assign sfp_vs        = hdmi_vs;
    assign sfp_de        = hdmi_de;
    assign sfp_rgb565    = {hdmi_rgb[23 : 19], hdmi_rgb[15 : 10], hdmi_rgb[7 : 3]};

    always@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            requested_mode <= 0;
            mode_active    <= 0;
            vs_d           <= 0;
            vs_s0          <= 0;
            hs_s0          <= 0;
            de_s0          <= 0;
            use_rgb_s0     <= 0;
            hdmi_vs        <= 0;
            hdmi_hs        <= 0;
            hdmi_de        <= 0;
            hdmi_rgb       <= 0;
        end
        else begin
            vs_d       <= vs;
            vs_s0      <= vs;
            hs_s0      <= hs;
            de_s0      <= de;
            use_rgb_s0 <= use_rgb;
            hdmi_vs    <= vs_s0;
            hdmi_hs    <= hs_s0;
            hdmi_de    <= de_s0;
            hdmi_rgb   <= use_rgb_s0 ? read_rgb : 24'd0;
            if(mode_toggle)begin
                requested_mode <= ~requested_mode;
            end
            if(vs && !vs_d)begin
                mode_active <= requested_mode ^ mode_toggle;
            end
        end
    end

endmodule
