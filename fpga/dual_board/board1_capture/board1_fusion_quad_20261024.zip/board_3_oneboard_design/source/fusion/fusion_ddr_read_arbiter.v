// Two readers share a fixed eight-beat, non-backpressured Pango DDR read port.
// Ownership is locked from address selection through the accepted RLAST beat.
module fusion_ddr_read_arbiter#(
    parameter   DISPLAY_PRIORITY             =   0,
    parameter   DISPLAY_URGENT_ENABLE        =   0
)(
    input                   clk,
    input                   rst_n,
    input                   legacy_urgent,
    input                   legacy_arvalid,
    output                  legacy_arready,
    input       [27 : 0]    legacy_araddr,
    output                  legacy_rvalid,
    output                  legacy_rlast,
    output      [255 : 0]   legacy_rdata,
    input                   fusion_arvalid,
    output                  fusion_arready,
    input       [27 : 0]    fusion_araddr,
    output                  fusion_rvalid,
    output                  fusion_rlast,
    output      [255 : 0]   fusion_rdata,
    output                  arvalid,
    input                   arready,
    output      [27 : 0]    araddr,
    input                   rvalid,
    input                   rlast,
    input       [255 : 0]   rdata
);

    localparam  IDLE                         =   2'd0;
    localparam  ADDRESS                      =   2'd1;
    localparam  DATA                         =   2'd2;
    reg         [1 : 0]     state;
    reg                     owner;
    reg                     last_owner;
    reg         [27 : 0]    address;

    assign arvalid        = state == ADDRESS;
    assign araddr         = address;
    assign legacy_arready = state == ADDRESS && !owner && arready;
    assign fusion_arready = state == ADDRESS && owner && arready;
    assign legacy_rvalid  = state == DATA && !owner && rvalid;
    assign fusion_rvalid  = state == DATA && owner && rvalid;
    assign legacy_rlast   = legacy_rvalid && rlast;
    assign fusion_rlast   = fusion_rvalid && rlast;
    assign legacy_rdata   = rdata;
    assign fusion_rdata   = rdata;

    always@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            state      <= IDLE;
            owner      <= 0;
            last_owner <= 1;
            address    <= 0;
        end
        else begin
            case(state)
                IDLE:begin
                    // Keep the port reserved across display request gaps when FIFO is low.
                    // The active burst always completes; capture writes use a separate arbiter.
                    if(!(DISPLAY_URGENT_ENABLE && legacy_urgent) && fusion_arvalid &&
                       (!legacy_arvalid || (!DISPLAY_PRIORITY && !last_owner)))begin
                        owner   <= 1'b1;
                        address <= fusion_araddr;
                        state   <= ADDRESS;
                    end
                    else if(legacy_arvalid)begin
                        owner   <= 1'b0;
                        address <= legacy_araddr;
                        state   <= ADDRESS;
                    end
                end
                ADDRESS:begin
                    if(arready)begin
                        state <= DATA;
                    end
                end
                DATA:begin
                    if(rvalid && rlast)begin
                        last_owner <= owner;
                        state      <= IDLE;
                    end
                end
                default:begin
                    state <= IDLE;
                end
            endcase
        end
    end

endmodule
