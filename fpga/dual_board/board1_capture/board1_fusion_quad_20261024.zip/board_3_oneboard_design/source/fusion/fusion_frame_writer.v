// Pack RGB888 as 00RRGGBB, sixty-four pixels per fixed DDR burst.
// WREADY and WLAST are returned by the Pango controller; there is no WVALID port.
module fusion_frame_writer#(
    parameter   FRAME_PIXELS                 =   1036800,
    parameter   BUFFER0                      =   28'h1000000,
    parameter   BUFFER1                      =   28'h1100000,
    parameter   MODE_SWITCH_ENABLE           =   0
)(
    input                   clk,
    input                   rst_n,
    input                   start,
    input                   buffer_select,
    input                   render_quad,
    input                   pixel_valid,
    output                  pixel_ready,
    input       [23 : 0]    pixel_rgb,
    output                  busy,
    output reg              done,
    output                  awvalid,
    input                   awready,
    output      [27 : 0]    awaddr,
    output      [255 : 0]   wdata,
    input                   wready,
    input                   wlast,
    output reg  [31 : 0]    errors
);
    localparam  IDLE                         =   3'd0;
    localparam  COLLECT                      =   3'd1;
    localparam  ADDRESS                      =   3'd2;
    localparam  DATA                         =   3'd3;
    localparam  FAILED                       =   3'd4;
    reg         [2 : 0]     state;
    reg         [6 : 0]     count;
    reg                     frame_quad;
    wire        [15 : 0]    quad_pixel;
    reg         [2 : 0]     beat;
    reg         [20 : 0]    offset;
    reg         [27 : 0]    base;
    reg         [255 : 0]   burst[0 : 7];

    assign quad_pixel  = {pixel_rgb[23 : 19], pixel_rgb[15 : 10], pixel_rgb[7 : 3]};
    assign pixel_ready = state == COLLECT;
    assign busy        = state != IDLE;
    assign awvalid     = state == ADDRESS;
    assign awaddr      = base + offset;
    assign wdata       = burst[beat];

    always@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            state  <= IDLE;
            count  <= 0;
            beat   <= 0;
            offset <= 0;
            base   <= BUFFER0;
            frame_quad <= 0;
            done   <= 0;
            errors <= 0;
        end
        else begin
            done <= 0;
            case(state)
                IDLE:begin
                    if(start)begin
                        base   <= buffer_select ? BUFFER1 : BUFFER0;
                        frame_quad <= MODE_SWITCH_ENABLE && render_quad;
                        offset <= 0;
                        count  <= 0;
                        state  <= COLLECT;
                    end
                end
                COLLECT:begin
                    if(pixel_valid)begin
                        if(frame_quad)begin
                            burst[count[6 : 4]][count[3 : 0] * 16 +: 16] <= quad_pixel;
                        end
                        else begin
                            burst[count[5 : 3]][count[2 : 0] * 32 +: 32] <= {8'd0, pixel_rgb};
                        end
                        if(count == (frame_quad ? 7'd127 : 7'd63))begin
                            count <= 0;
                            beat  <= 0;
                            state <= ADDRESS;
                        end
                        else begin
                            count <= count + 1'b1;
                        end
                    end
                end
                ADDRESS:begin
                    if(awready)begin
                        state <= DATA;
                    end
                end
                DATA:begin
                    if(wready)begin
                        if(wlast != (beat == 7))begin
                            errors <= errors + 1'b1;
                            state  <= FAILED;
                        end
                        else if(beat == 7)begin
                            if(offset == FRAME_PIXELS - 64)begin
                                done  <= 1;
                                state <= IDLE;
                            end
                            else begin
                                offset <= offset + 21'd64;
                                state  <= COLLECT;
                            end
                        end
                        else begin
                            beat <= beat + 1'b1;
                        end
                    end
                end
                FAILED:begin
                    state <= FAILED;
                end
                default:begin
                    state <= IDLE;
                end
            endcase
        end
    end
endmodule
