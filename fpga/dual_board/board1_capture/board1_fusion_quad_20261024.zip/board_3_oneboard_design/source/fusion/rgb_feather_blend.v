module rgb_feather_blend(
    input                   clk,
    input                   rst_n,
    input                   in_valid,
    input       [23 : 0]    left_rgb,
    input       [23 : 0]    center_rgb,
    input       [23 : 0]    right_rgb,
    input       [8 : 0]     weight_left,
    input       [8 : 0]     weight_center,
    input       [8 : 0]     weight_right,
    output reg              out_valid,
    output reg  [23 : 0]    out_rgb,
    output reg  [23 : 0]    hard_rgb
);

    reg                     valid_s0;
    reg         [23 : 0]    hard_s0;
    reg         [16 : 0]    left_product[0 : 2];
    reg         [16 : 0]    center_product[0 : 2];
    reg         [16 : 0]    right_product[0 : 2];
    integer                 channel;

    always@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            valid_s0 <= 1'b0;
            out_valid <= 1'b0;
            hard_s0  <= 0;
            out_rgb  <= 0;
            hard_rgb <= 0;
            for(channel = 0; channel < 3; channel = channel + 1)begin
                left_product[channel]   <= 0;
                center_product[channel] <= 0;
                right_product[channel]  <= 0;
            end
        end
        else begin
            valid_s0  <= in_valid;
            out_valid <= valid_s0;
            if(in_valid)begin
                hard_s0 <= center_rgb;
                if(weight_left > weight_center && weight_left >= weight_right)begin
                    hard_s0 <= left_rgb;
                end
                else if(weight_right > weight_center && weight_right > weight_left)begin
                    hard_s0 <= right_rgb;
                end
                for(channel = 0; channel < 3; channel = channel + 1)begin
                    left_product[channel]   <= left_rgb[channel * 8 +: 8] * weight_left;
                    center_product[channel] <= center_rgb[channel * 8 +: 8] * weight_center;
                    right_product[channel]  <= right_rgb[channel * 8 +: 8] * weight_right;
                end
            end
            if(valid_s0)begin
                hard_rgb <= hard_s0;
                for(channel = 0; channel < 3; channel = channel + 1)begin
                    out_rgb[channel * 8 +: 8] <= (left_product[channel] + center_product[channel] +
                                                  right_product[channel] + 19'd128) >> 8;
                end
            end
        end
    end

endmodule
