// Dual-clock, synchronous dual-port RAM FIFO with a registered read-side head.
// Pointers cross as registered Gray code; reset releases synchronously per domain.
module fusion_async_fifo#(
    parameter   ADDRESS_BITS                 =   8
)(
    input                   reset_n,
    input                   wr_clk,
    input                   wr_valid,
    output                  wr_ready,
    input       [255 : 0]   wr_data,
    output      [ADDRESS_BITS : 0] wr_level,
    input                   rd_clk,
    output                  rd_valid,
    input                   rd_ready,
    output reg  [255 : 0]   rd_data
);
    localparam  DEPTH                        =   1 << ADDRESS_BITS;
    (* syn_ramstyle = "block_ram" *) reg [255 : 0] memory[0 : DEPTH - 1];
    reg         [ADDRESS_BITS : 0] wbin;
    reg         [ADDRESS_BITS : 0] wgray;
    reg         [ADDRESS_BITS : 0] rbin;
    reg         [ADDRESS_BITS : 0] rgray;
    (* syn_preserve = 1 *) reg [ADDRESS_BITS : 0] rgray_s0;
    (* syn_preserve = 1 *) reg [ADDRESS_BITS : 0] rgray_s1;
    (* syn_preserve = 1 *) reg [ADDRESS_BITS : 0] wgray_s0;
    (* syn_preserve = 1 *) reg [ADDRESS_BITS : 0] wgray_s1;
    reg         [1 : 0]     wr_reset;
    reg         [1 : 0]     rd_reset;
    reg                     head_valid;
    wire                    wr_run;
    wire                    rd_run;
    wire                    full;
    wire                    empty;
    wire                    push;
    wire                    fetch;
    wire        [ADDRESS_BITS : 0] wnext;
    wire        [ADDRESS_BITS : 0] rnext;

    function [ADDRESS_BITS : 0] gray_to_binary;
        input [ADDRESS_BITS : 0] gray;
        integer b;
        begin
            gray_to_binary[ADDRESS_BITS] = gray[ADDRESS_BITS];
            for(b = ADDRESS_BITS - 1; b >= 0; b = b - 1)begin
                gray_to_binary[b] = gray_to_binary[b + 1] ^ gray[b];
            end
        end
    endfunction

    assign wr_run   = wr_reset[1];
    assign rd_run   = rd_reset[1];
    assign full     = wgray == {~rgray_s1[ADDRESS_BITS : ADDRESS_BITS - 1], rgray_s1[ADDRESS_BITS - 2 : 0]};
    assign empty    = rgray == wgray_s1;
    assign wr_ready = wr_run && !full;
    assign rd_valid = rd_run && head_valid;
    assign push     = wr_valid && wr_ready;
    assign fetch    = rd_run && (!head_valid || rd_ready) && !empty;
    assign wnext    = wbin + push;
    assign rnext    = rbin + fetch;
    assign wr_level = wbin - gray_to_binary(rgray_s1);

    always@(posedge wr_clk or negedge reset_n)begin
        if(!reset_n)begin
            wr_reset <= 0;
            wbin     <= 0;
            wgray    <= 0;
            rgray_s0 <= 0;
            rgray_s1 <= 0;
        end
        else begin
            wr_reset <= {wr_reset[0], 1'b1};
            rgray_s0 <= rgray;
            rgray_s1 <= rgray_s0;
            if(wr_run)begin
                wbin  <= wnext;
                wgray <= (wnext >> 1) ^ wnext;
            end
        end
    end

    always@(posedge wr_clk)begin
        if(push)begin
            memory[wbin[ADDRESS_BITS - 1 : 0]] <= wr_data;
        end
    end

    always@(posedge rd_clk)begin
        if(fetch)begin
            rd_data <= memory[rbin[ADDRESS_BITS - 1 : 0]];
        end
    end

    always@(posedge rd_clk or negedge reset_n)begin
        if(!reset_n)begin
            rd_reset   <= 0;
            rbin       <= 0;
            rgray      <= 0;
            wgray_s0   <= 0;
            wgray_s1   <= 0;
            head_valid <= 0;
        end
        else begin
            rd_reset <= {rd_reset[0], 1'b1};
            wgray_s0 <= wgray;
            wgray_s1 <= wgray_s0;
            if(rd_run)begin
                rbin  <= rnext;
                rgray <= (rnext >> 1) ^ rnext;
                if(!head_valid || rd_ready)begin
                    head_valid <= !empty;
                end
            end
        end
    end
endmodule
