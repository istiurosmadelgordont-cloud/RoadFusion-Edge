// Reuse the user's proven active-low debounce block without changing its RTL.
// A falling edge of debounced Key_out toggles the requested mode once per press.
module video_mode_key#(
    parameter   MCNT                         =   999999
)(
    input                   clk,
    input                   rst_n,
    input                   key_n,
    output reg              requested_quad
);
    (* syn_preserve = 1 *) reg [1 : 0] reset_sync;
    wire                    control_rst_n;
    wire                    debounced_key;
    reg                     debounced_d;

    assign control_rst_n = reset_sync[1];

    always@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            reset_sync <= 0;
        end
        else begin
            reset_sync <= {reset_sync[0], 1'b1};
        end
    end

    key_anti_shake#(
        .MCNT                (MCNT                   )
    )u_debounce(
        .Reset_n             (control_rst_n          ),
        .Clk                 (clk                    ),
        .Key_in              (key_n                  ),
        .Key_out             (debounced_key          )
    );

    always@(posedge clk or negedge control_rst_n)begin
        if(!control_rst_n)begin
            debounced_d   <= 1'b1;
            requested_quad <= 1'b0;
        end
        else begin
            debounced_d <= debounced_key;
            if(debounced_d && !debounced_key)begin
                requested_quad <= ~requested_quad;
            end
        end
    end
endmodule
