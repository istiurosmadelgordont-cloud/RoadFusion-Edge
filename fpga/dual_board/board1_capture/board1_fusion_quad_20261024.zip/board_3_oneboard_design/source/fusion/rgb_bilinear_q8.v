// Four neighbours -> RGB888. Q0.8 fractions; complementary weights need 9 bits.
// Keep horizontal precision and round only after the vertical accumulation.
module rgb_bilinear_q8(
    input                   clk,
    input                   rst_n,
    input                   in_valid,
    input       [23 : 0]    p00,
    input       [23 : 0]    p10,
    input       [23 : 0]    p01,
    input       [23 : 0]    p11,
    input       [7 : 0]     fraction_x,
    input       [7 : 0]     fraction_y,
    output reg              out_valid,
    output reg  [23 : 0]    out_rgb
);

    reg                     valid_s0;
    reg         [7 : 0]     fy_s0;
    reg         [16 : 0]    top_sum[0 : 2];
    reg         [16 : 0]    bottom_sum[0 : 2];
    integer                 channel;

    always@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            valid_s0 <= 1'b0;
            out_valid <= 1'b0;
            fy_s0    <= 0;
            out_rgb  <= 0;
            for(channel = 0; channel < 3; channel = channel + 1)begin
                top_sum[channel]    <= 0;
                bottom_sum[channel] <= 0;
            end
        end
        else begin
            valid_s0  <= in_valid;
            out_valid <= valid_s0;
            if(in_valid)begin
                fy_s0 <= fraction_y;
                for(channel = 0; channel < 3; channel = channel + 1)begin
                    top_sum[channel] <= p00[channel * 8 +: 8] * (9'd256 - {1'b0, fraction_x}) +
                                        p10[channel * 8 +: 8] * fraction_x;
                    bottom_sum[channel] <= p01[channel * 8 +: 8] * (9'd256 - {1'b0, fraction_x}) +
                                           p11[channel * 8 +: 8] * fraction_x;
                end
            end
            if(valid_s0)begin
                for(channel = 0; channel < 3; channel = channel + 1)begin
                    out_rgb[channel * 8 +: 8] <= (top_sum[channel] * (9'd256 - {1'b0, fy_s0}) +
                                                  bottom_sum[channel] * fy_s0 + 26'd32768) >> 16;
                end
            end
        end
    end

endmodule
