module key_anti_shake(
    Reset_n,
    Clk,
    Key_in,
    Key_out
  
    );
    input Reset_n;
    input Clk;
    input Key_in;
    output reg Key_out;
    localparam IDLE=4'b0001,
               D_FILTER=4'b0010,
               MODERATE=4'b0100,
               P_FILTER=4'b1000;
    reg [3:0]cur_state;
    reg [3:0]next_state;           
   always@(posedge Clk or negedge Reset_n)begin
     if(!Reset_n)
        cur_state<=IDLE;
        
      else
        cur_state<=next_state;
		end
      reg [2:0]Key_sync_reg;
      always@(posedge Clk)
       Key_sync_reg<={Key_sync_reg[1:0],Key_in};
       wire p_key=(Key_sync_reg[2:1]==2'b01);
       wire n_key=(Key_sync_reg[2:1]==2'b10);
     parameter MCNT=999999;
     reg [19:0]div_cnt1;       
     always@(posedge Clk or negedge Reset_n)begin
     if(!Reset_n)
         div_cnt1<=0;
         else begin
         if(cur_state==D_FILTER)begin
            if(div_cnt1==MCNT )
                div_cnt1<=0;
                else
                    div_cnt1<=div_cnt1+1'd1;
             end
          else
                div_cnt1<=0;  
				end
                
         end  
       reg [19:0]div_cnt2; 
     always@(posedge Clk or negedge Reset_n)begin
     if(!Reset_n)
         div_cnt2<=0;
         else
         if(cur_state==P_FILTER)begin
            if(div_cnt2==MCNT )
                div_cnt2<=0;
                else
                    div_cnt2<=div_cnt2+1'd1;
             end
          else
                div_cnt2<=0;  
                
         end 
    reg Key_p_flag;
    
    always@(posedge Clk or negedge Reset_n)begin
     if(!Reset_n)begin
        Key_p_flag<=0;
        end
      else begin 
	  if( next_state==MODERATE&&div_cnt1==MCNT)
            Key_p_flag<=1;
                else
                 Key_p_flag<=0;
				 end
       end          
     reg Key_n_flag;
      always@(posedge Clk or negedge Reset_n)begin
     if(!Reset_n)begin
        Key_n_flag<=0;
        end
      else begin
	  if( next_state==IDLE&&div_cnt2==MCNT)
            Key_n_flag<=1;
                else
                 Key_n_flag<=0;
            end 
		end		 
    always@(*)begin
    case(cur_state)
     IDLE: next_state=(n_key)?D_FILTER:IDLE;
     D_FILTER: begin if(p_key)begin
                         next_state=IDLE;
                         end
                         else begin
                         if(div_cnt1==MCNT)
                          next_state=MODERATE;
                         else
                          next_state=D_FILTER;
                         end 
                         end           
      MODERATE: next_state=(p_key)? P_FILTER:MODERATE;
      P_FILTER: begin if(n_key)begin
                         next_state=MODERATE;
                         end
                         else begin 
                         if(div_cnt2==MCNT)
                             next_state=IDLE; 
                          else
                             next_state=P_FILTER;
                         end 
                         end 
     default: next_state=IDLE;                                                            
     endcase  
     end
  always@(posedge Clk or negedge Reset_n)begin
     if(!Reset_n)
     Key_out<=1;
     else begin 
	 case(cur_state) 
     IDLE: Key_out<=1;
     D_FILTER:Key_out<=1;
     MODERATE:Key_out<=0;
     P_FILTER:Key_out<=0;
     default:Key_out<=1;
     endcase
	 end
     end
endmodule
