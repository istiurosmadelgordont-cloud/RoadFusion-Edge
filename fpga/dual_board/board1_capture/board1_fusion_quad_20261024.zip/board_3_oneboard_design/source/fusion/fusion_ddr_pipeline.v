// Simulation-first DDR read-side subsystem; source frame pages are latched at start.
// Source writers must retain these pages until done before this can be connected live.
module fusion_ddr_pipeline#(
    parameter   DISPLAY_PRIORITY             =   0,
    parameter   DISPLAY_URGENT_ENABLE        =   0,
    parameter   LEFT_CHANNEL                 =   0,
    parameter   CENTER_CHANNEL               =   1,
    parameter   RIGHT_CHANNEL                =   2,
    parameter   QUAD_RENDER_ENABLE           =   0
)(
    input                   clk,
    input                   rst_n,
    input                   start,
    input                   quad_select,
    input                   quad_arvalid,
    output                  quad_arready,
    input       [27 : 0]    quad_araddr,
    output                  quad_rvalid,
    output                  quad_rlast,
    output      [255 : 0]   quad_rdata,
    input       [7 : 0]     frame_pages,
    output                  busy,
    output                  done,
    input                   out_ready,
    output                  out_valid,
    output      [23 : 0]    out_rgb,
    output      [10 : 0]    out_x,
    output      [9 : 0]     out_y,
    output                  out_sof,
    output                  out_eol,
    output                  out_eof,
    input                   legacy_urgent,
    input                   legacy_arvalid,
    output                  legacy_arready,
    input       [27 : 0]    legacy_araddr,
    output                  legacy_rvalid,
    output                  legacy_rlast,
    output      [255 : 0]   legacy_rdata,
    output                  arvalid,
    input                   arready,
    output      [27 : 0]    araddr,
    input                   rvalid,
    input                   rlast,
    input       [255 : 0]   rdata,
    output      [31 : 0]    burst_count,
    output      [31 : 0]    protocol_errors,
    output      [31 : 0]    coverage_errors,
    output      [31 : 0]    fallback_count
);

    reg         [7 : 0]     active_pages;
    wire                    accept_start;
    wire                    req_valid;
    wire                    req_ready;
    wire        [107 : 0]   req_uv;
    wire        [2 : 0]     req_mask;
    wire                    rsp_valid;
    wire                    rsp_ready;
    wire        [287 : 0]   rsp_pixels;
    wire                    fusion_arvalid;
    wire                    fusion_arready;
    wire        [27 : 0]    fusion_araddr;
    wire                    fusion_rvalid;
    wire                    fusion_rlast;
    wire        [255 : 0]   fusion_rdata;

    wire                    sampler_arvalid;
    wire                    sampler_arready;
    wire        [27 : 0]    sampler_araddr;
    wire                    sampler_rvalid;
    wire                    sampler_rlast;
    wire                    use_quad;

    assign accept_start    = start && !busy;
    assign use_quad        = QUAD_RENDER_ENABLE && quad_select;
    assign fusion_arvalid  = use_quad ? quad_arvalid : sampler_arvalid;
    assign fusion_araddr   = use_quad ? quad_araddr : sampler_araddr;
    assign quad_arready    = use_quad && fusion_arready;
    assign quad_rvalid     = use_quad && fusion_rvalid;
    assign quad_rlast      = use_quad && fusion_rlast;
    assign quad_rdata      = fusion_rdata;
    assign sampler_arready = !use_quad && fusion_arready;
    assign sampler_rvalid  = !use_quad && fusion_rvalid;
    assign sampler_rlast   = !use_quad && fusion_rlast;

    always@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            active_pages <= 0;
        end
        else if(accept_start)begin
            active_pages <= frame_pages;
        end
    end

    grid_fusion_top u_grid(
        .clk                    (clk                    ),
        .rst_n                  (rst_n                  ),
        .start                  (accept_start           ),
        .busy                   (busy                   ),
        .done                   (done                   ),
        .mem_req_valid          (req_valid              ),
        .mem_req_ready          (req_ready              ),
        .mem_req_uv             (req_uv                 ),
        .mem_req_mask           (req_mask               ),
        .mem_rsp_valid          (rsp_valid              ),
        .mem_rsp_ready          (rsp_ready              ),
        .mem_rsp_pixels         (rsp_pixels             ),
        .out_valid              (out_valid              ),
        .out_ready              (out_ready              ),
        .out_rgb                (out_rgb                ),
        .out_hard_rgb           (                       ),
        .out_x                  (out_x                  ),
        .out_y                  (out_y                  ),
        .out_sof                (out_sof                ),
        .out_eol                (out_eol                ),
        .out_eof                (out_eof                ),
        .out_weights            (                       ),
        .coverage_error_count   (coverage_errors        ),
        .validity_fallback_count(fallback_count         )
    );

    fusion_ddr_sampler#(
        .LEFT_CHANNEL           (LEFT_CHANNEL           ),
        .CENTER_CHANNEL         (CENTER_CHANNEL         ),
        .RIGHT_CHANNEL          (RIGHT_CHANNEL          )
    )u_sampler(
        .clk                    (clk                    ),
        .rst_n                  (rst_n                  ),
        .flush                  (accept_start           ),
        .frame_pages            (active_pages           ),
        .req_valid              (req_valid              ),
        .req_ready              (req_ready              ),
        .req_uv                 (req_uv                 ),
        .req_mask               (req_mask               ),
        .rsp_valid              (rsp_valid              ),
        .rsp_ready              (rsp_ready              ),
        .rsp_pixels             (rsp_pixels             ),
        .arvalid                (sampler_arvalid        ),
        .arready                (sampler_arready        ),
        .araddr                 (sampler_araddr         ),
        .rvalid                 (sampler_rvalid         ),
        .rlast                  (sampler_rlast          ),
        .rdata                  (fusion_rdata           ),
        .burst_count            (burst_count            ),
        .protocol_errors        (protocol_errors        )
    );

    fusion_ddr_read_arbiter#(
        .DISPLAY_PRIORITY       (DISPLAY_PRIORITY           ),
        .DISPLAY_URGENT_ENABLE  (DISPLAY_URGENT_ENABLE      )
    )u_read_arbiter(
        .clk                    (clk                    ),
        .rst_n                  (rst_n                  ),
        .legacy_urgent          (legacy_urgent          ),
        .legacy_arvalid         (legacy_arvalid         ),
        .legacy_arready         (legacy_arready         ),
        .legacy_araddr          (legacy_araddr          ),
        .legacy_rvalid          (legacy_rvalid          ),
        .legacy_rlast           (legacy_rlast           ),
        .legacy_rdata           (legacy_rdata           ),
        .fusion_arvalid         (fusion_arvalid         ),
        .fusion_arready         (fusion_arready         ),
        .fusion_araddr          (fusion_araddr          ),
        .fusion_rvalid          (fusion_rvalid          ),
        .fusion_rlast           (fusion_rlast           ),
        .fusion_rdata           (fusion_rdata           ),
        .arvalid                (arvalid                ),
        .arready                (arready                ),
        .araddr                 (araddr                 ),
        .rvalid                 (rvalid                 ),
        .rlast                  (rlast                  ),
        .rdata                  (rdata                  )
    );

endmodule
