// Two fixed seams; ramp width is 128 pixels, hence Q8 ramp weights use shifts.
// Default seams 640/1280, feather interval +/-64. At most two cameras overlap.
module fixed_seam_weights#(
    parameter   LEFT_SEAM                    =   640,
    parameter   RIGHT_SEAM                   =   1280
)(
    input       [10 : 0]    pixel_x,
    input       [2 : 0]     camera_valid,
    output reg  [8 : 0]     weight_left,
    output reg  [8 : 0]     weight_center,
    output reg  [8 : 0]     weight_right,
    output reg              coverage_error,
    output reg              validity_fallback
);

    reg         [8 : 0]     ramp;
    reg         [9 : 0]     total;

    always@(*)begin
        weight_left   = 9'd0;
        weight_center = 9'd0;
        weight_right  = 9'd0;
        ramp          = 9'd0;
        total         = 10'd0;
        coverage_error = 1'b0;
        validity_fallback = 1'b0;
        if(pixel_x < LEFT_SEAM - 64)begin
            weight_left = 9'd256;
        end
        else if(pixel_x < LEFT_SEAM + 64)begin
            ramp          = (pixel_x - (LEFT_SEAM - 64)) << 1;
            weight_left   = 9'd256 - ramp;
            weight_center = ramp;
        end
        else if(pixel_x < RIGHT_SEAM - 64)begin
            weight_center = 9'd256;
        end
        else if(pixel_x < RIGHT_SEAM + 64)begin
            ramp          = (pixel_x - (RIGHT_SEAM - 64)) << 1;
            weight_center = 9'd256 - ramp;
            weight_right  = ramp;
        end
        else begin
            weight_right = 9'd256;
        end

        if(!camera_valid[0])begin
            validity_fallback = validity_fallback || (weight_left != 0);
            weight_left = 0;
        end
        if(!camera_valid[1])begin
            validity_fallback = validity_fallback || (weight_center != 0);
            weight_center = 0;
        end
        if(!camera_valid[2])begin
            validity_fallback = validity_fallback || (weight_right != 0);
            weight_right = 0;
        end
        total = {1'b0, weight_left} + {1'b0, weight_center} + {1'b0, weight_right};
        if(total != 256)begin
            validity_fallback = 1'b1;
            if(weight_left != 0)begin
                weight_left = 256;
            end
            else if(weight_center != 0)begin
                weight_center = 256;
            end
            else if(weight_right != 0)begin
                weight_right = 256;
            end
            else if(camera_valid[1])begin
                weight_center = 256;
            end
            else if(camera_valid[0])begin
                weight_left = 256;
            end
            else if(camera_valid[2])begin
                weight_right = 256;
            end
            else begin
                coverage_error = 1'b1;
            end
        end
    end

endmodule
