// Synthesizable algorithm core. Frame storage is outside this module.
// Mapping, memory sampling and RGB arithmetic overlap through bounded queues.
// No source-frame arrays, dense LUT, per-pixel weight ROM, or Python image output here.
module grid_fusion_top#(
    parameter   LEFT_FILE0                   =   "fusion_maps/grid16_bram/left_b0.hex",
    parameter   LEFT_FILE1                   =   "fusion_maps/grid16_bram/left_b1.hex",
    parameter   LEFT_FILE2                   =   "fusion_maps/grid16_bram/left_b2.hex",
    parameter   LEFT_FILE3                   =   "fusion_maps/grid16_bram/left_b3.hex",
    parameter   CENTER_FILE0                 =   "fusion_maps/grid16_bram/center_b0.hex",
    parameter   CENTER_FILE1                 =   "fusion_maps/grid16_bram/center_b1.hex",
    parameter   CENTER_FILE2                 =   "fusion_maps/grid16_bram/center_b2.hex",
    parameter   CENTER_FILE3                 =   "fusion_maps/grid16_bram/center_b3.hex",
    parameter   RIGHT_FILE0                  =   "fusion_maps/grid16_bram/right_b0.hex",
    parameter   RIGHT_FILE1                  =   "fusion_maps/grid16_bram/right_b1.hex",
    parameter   RIGHT_FILE2                  =   "fusion_maps/grid16_bram/right_b2.hex",
    parameter   RIGHT_FILE3                  =   "fusion_maps/grid16_bram/right_b3.hex",
    parameter   LEFT_SEAM                    =   640,
    parameter   RIGHT_SEAM                   =   1280
)(
    input                   clk,
    input                   rst_n,
    input                   start,
    output reg              busy,
    output reg              done,
    output                  mem_req_valid,
    input                   mem_req_ready,
    output      [107 : 0]   mem_req_uv,
    output      [2 : 0]     mem_req_mask,
    input                   mem_rsp_valid,
    output                  mem_rsp_ready,
    input       [287 : 0]   mem_rsp_pixels,
    output                  out_valid,
    input                   out_ready,
    output      [23 : 0]    out_rgb,
    output      [23 : 0]    out_hard_rgb,
    output      [10 : 0]    out_x,
    output      [9 : 0]     out_y,
    output                  out_sof,
    output                  out_eol,
    output                  out_eof,
    output      [26 : 0]    out_weights,
    output reg  [31 : 0]    coverage_error_count,
    output reg  [31 : 0]    validity_fallback_count
);

    reg         [10 : 0]    render_x;
    reg         [9 : 0]     render_y;
    reg                     issue_finished;
    wire                    map_issue;
    wire        [2 : 0]     map_valid;
    wire        [2 : 0]     coordinate_valid;
    wire        [107 : 0]   mapped_uv;
    reg         [20 : 0]    map_xy[0 : 2];
    reg         [158 : 0]   map_queue[0 : 15];
    reg         [3 : 0]     map_write;
    reg         [3 : 0]     map_read;
    reg         [4 : 0]     map_reserved;
    reg         [4 : 0]     map_count;
    wire        [8 : 0]     next_weight_left;
    wire        [8 : 0]     next_weight_center;
    wire        [8 : 0]     next_weight_right;
    wire                    coverage_error;
    wire                    validity_fallback;
    wire                    map_push;
    wire                    request_fire;
    reg                     awaiting_response;
    reg         [107 : 0]   active_uv;
    reg         [26 : 0]    active_weights;
    reg         [20 : 0]    active_xy;
    reg         [26 : 0]    sample_weights[0 : 1];
    reg         [20 : 0]    sample_xy[0 : 1];
    reg         [26 : 0]    blend_weights[0 : 1];
    reg         [20 : 0]    blend_xy[0 : 1];
    wire                    sample_fire;
    wire        [2 : 0]     rgb_valid;
    wire        [71 : 0]    sampled_rgb;
    wire                    blend_fire;
    wire                    blend_valid;
    wire        [23 : 0]    blended_rgb;
    wire        [23 : 0]    hard_rgb;
    reg         [95 : 0]    output_queue[0 : 15];
    reg         [3 : 0]     output_write;
    reg         [3 : 0]     output_read;
    reg         [4 : 0]     output_count;
    reg         [4 : 0]     result_reserved;
    wire                    output_fire;
    integer                 stage;

    // Reserved entries include every item still inside a fixed-latency pipeline.
    assign map_issue     = busy && !issue_finished && map_reserved < 16;
    assign map_push      = &map_valid;
    assign mem_req_valid = busy && map_count != 0 && !awaiting_response && result_reserved < 16;
    assign mem_req_uv    = map_queue[map_read][107 : 0];
    assign mem_req_mask  = map_queue[map_read][110 : 108];
    assign request_fire  = mem_req_valid && mem_req_ready;
    assign mem_rsp_ready = awaiting_response;
    assign sample_fire   = mem_rsp_valid && mem_rsp_ready;
    assign blend_fire    = &rgb_valid;
    assign out_valid     = output_count != 0;
    assign out_rgb       = output_queue[output_read][23 : 0];
    assign out_hard_rgb  = output_queue[output_read][47 : 24];
    assign out_x         = output_queue[output_read][58 : 48];
    assign out_y         = output_queue[output_read][68 : 59];
    assign out_weights   = output_queue[output_read][95 : 69];
    assign out_sof       = out_valid && out_x == 0 && out_y == 0;
    assign out_eol       = out_valid && out_x == 1919;
    assign out_eof       = out_valid && out_x == 1919 && out_y == 539;
    assign output_fire   = out_valid && out_ready;

    grid_coordinate_interp#(
        .FILE_0              (LEFT_FILE0             ),
        .FILE_1              (LEFT_FILE1             ),
        .FILE_2              (LEFT_FILE2             ),
        .FILE_3              (LEFT_FILE3             )
    )u_map_left(
        .clk                 (clk                    ),
        .rst_n               (rst_n                  ),
        .in_valid            (map_issue              ),
        .in_x                (render_x               ),
        .in_y                (render_y               ),
        .out_valid           (map_valid[0]           ),
        .coordinate_valid    (coordinate_valid[0]    ),
        .source_u            (mapped_uv[0 +: 18]     ),
        .source_v            (mapped_uv[18 +: 18]    )
    );

    rgb_bilinear_q8 u_sample_left(
        .clk                 (clk                    ),
        .rst_n               (rst_n                  ),
        .in_valid            (sample_fire            ),
        .p00                 (mem_rsp_pixels[0 +: 24]),
        .p10                 (mem_rsp_pixels[24 +: 24]),
        .p01                 (mem_rsp_pixels[48 +: 24]),
        .p11                 (mem_rsp_pixels[72 +: 24]),
        .fraction_x          (active_uv[0 +: 8]     ),
        .fraction_y          (active_uv[18 +: 8]    ),
        .out_valid           (rgb_valid[0]           ),
        .out_rgb             (sampled_rgb[0 +: 24]   )
    );

    grid_coordinate_interp#(
        .FILE_0              (CENTER_FILE0           ),
        .FILE_1              (CENTER_FILE1           ),
        .FILE_2              (CENTER_FILE2           ),
        .FILE_3              (CENTER_FILE3           )
    )u_map_center(
        .clk                 (clk                    ),
        .rst_n               (rst_n                  ),
        .in_valid            (map_issue              ),
        .in_x                (render_x               ),
        .in_y                (render_y               ),
        .out_valid           (map_valid[1]           ),
        .coordinate_valid    (coordinate_valid[1]    ),
        .source_u            (mapped_uv[36 +: 18]    ),
        .source_v            (mapped_uv[54 +: 18]    )
    );

    rgb_bilinear_q8 u_sample_center(
        .clk                 (clk                    ),
        .rst_n               (rst_n                  ),
        .in_valid            (sample_fire            ),
        .p00                 (mem_rsp_pixels[96 +: 24]),
        .p10                 (mem_rsp_pixels[120 +: 24]),
        .p01                 (mem_rsp_pixels[144 +: 24]),
        .p11                 (mem_rsp_pixels[168 +: 24]),
        .fraction_x          (active_uv[36 +: 8]    ),
        .fraction_y          (active_uv[54 +: 8]    ),
        .out_valid           (rgb_valid[1]           ),
        .out_rgb             (sampled_rgb[24 +: 24]  )
    );

    grid_coordinate_interp#(
        .FILE_0              (RIGHT_FILE0            ),
        .FILE_1              (RIGHT_FILE1            ),
        .FILE_2              (RIGHT_FILE2            ),
        .FILE_3              (RIGHT_FILE3            )
    )u_map_right(
        .clk                 (clk                    ),
        .rst_n               (rst_n                  ),
        .in_valid            (map_issue              ),
        .in_x                (render_x               ),
        .in_y                (render_y               ),
        .out_valid           (map_valid[2]           ),
        .coordinate_valid    (coordinate_valid[2]    ),
        .source_u            (mapped_uv[72 +: 18]    ),
        .source_v            (mapped_uv[90 +: 18]    )
    );

    rgb_bilinear_q8 u_sample_right(
        .clk                 (clk                    ),
        .rst_n               (rst_n                  ),
        .in_valid            (sample_fire            ),
        .p00                 (mem_rsp_pixels[192 +: 24]),
        .p10                 (mem_rsp_pixels[216 +: 24]),
        .p01                 (mem_rsp_pixels[240 +: 24]),
        .p11                 (mem_rsp_pixels[264 +: 24]),
        .fraction_x          (active_uv[72 +: 8]    ),
        .fraction_y          (active_uv[90 +: 8]    ),
        .out_valid           (rgb_valid[2]           ),
        .out_rgb             (sampled_rgb[48 +: 24]  )
    );

    fixed_seam_weights#(
        .LEFT_SEAM          (LEFT_SEAM              ),
        .RIGHT_SEAM         (RIGHT_SEAM             )
    )u_weights(
        .pixel_x            (map_xy[2][10 : 0]      ),
        .camera_valid       (coordinate_valid       ),
        .weight_left        (next_weight_left       ),
        .weight_center      (next_weight_center     ),
        .weight_right       (next_weight_right      ),
        .coverage_error     (coverage_error         ),
        .validity_fallback  (validity_fallback      )
    );

    rgb_feather_blend u_blend(
        .clk                (clk                    ),
        .rst_n              (rst_n                  ),
        .in_valid           (blend_fire             ),
        .left_rgb           (sampled_rgb[23 : 0]    ),
        .center_rgb         (sampled_rgb[47 : 24]   ),
        .right_rgb          (sampled_rgb[71 : 48]   ),
        .weight_left        (sample_weights[1][8 : 0]),
        .weight_center      (sample_weights[1][17 : 9]),
        .weight_right       (sample_weights[1][26 : 18]),
        .out_valid          (blend_valid            ),
        .out_rgb            (blended_rgb            ),
        .hard_rgb           (hard_rgb               )
    );

    // Data RAMs are not reset; counts and pointers qualify every read.
    always@(posedge clk)begin
        if(map_push)begin
            map_queue[map_write] <= {map_xy[2], next_weight_right, next_weight_center,
                                     next_weight_left, next_weight_right != 0,
                                     next_weight_center != 0, next_weight_left != 0, mapped_uv};
        end
        if(blend_valid)begin
            output_queue[output_write] <= {blend_weights[1], blend_xy[1], hard_rgb, blended_rgb};
        end
    end

    always@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            busy                    <= 1'b0;
            done                    <= 1'b0;
            render_x                <= 0;
            render_y                <= 0;
            issue_finished          <= 1'b0;
            map_write               <= 0;
            map_read                <= 0;
            map_reserved            <= 0;
            map_count               <= 0;
            awaiting_response       <= 1'b0;
            active_uv               <= 0;
            active_weights          <= 0;
            active_xy               <= 0;
            output_write            <= 0;
            output_read             <= 0;
            output_count            <= 0;
            result_reserved         <= 0;
            coverage_error_count    <= 0;
            validity_fallback_count <= 0;
            for(stage = 0; stage < 3; stage = stage + 1)begin
                map_xy[stage] <= 0;
            end
            for(stage = 0; stage < 2; stage = stage + 1)begin
                sample_weights[stage] <= 0;
                sample_xy[stage]      <= 0;
                blend_weights[stage]  <= 0;
                blend_xy[stage]       <= 0;
            end
        end
        else begin
            done <= 1'b0;
            map_xy[0] <= {render_y, render_x};
            map_xy[1] <= map_xy[0];
            map_xy[2] <= map_xy[1];
            sample_weights[0] <= active_weights;
            sample_weights[1] <= sample_weights[0];
            sample_xy[0]      <= active_xy;
            sample_xy[1]      <= sample_xy[0];
            blend_weights[0]  <= sample_weights[1];
            blend_weights[1]  <= blend_weights[0];
            blend_xy[0]       <= sample_xy[1];
            blend_xy[1]       <= blend_xy[0];

            case({map_issue, request_fire})
                2'b10: map_reserved <= map_reserved + 1'b1;
                2'b01: map_reserved <= map_reserved - 1'b1;
                default:begin end
            endcase
            case({map_push, request_fire})
                2'b10: map_count <= map_count + 1'b1;
                2'b01: map_count <= map_count - 1'b1;
                default:begin end
            endcase
            case({request_fire, output_fire})
                2'b10: result_reserved <= result_reserved + 1'b1;
                2'b01: result_reserved <= result_reserved - 1'b1;
                default:begin end
            endcase
            case({blend_valid, output_fire})
                2'b10: output_count <= output_count + 1'b1;
                2'b01: output_count <= output_count - 1'b1;
                default:begin end
            endcase

            if(map_issue)begin
                if(render_x == 1919)begin
                    render_x <= 0;
                    if(render_y == 539)begin
                        issue_finished <= 1'b1;
                    end
                    else begin
                        render_y <= render_y + 1'b1;
                    end
                end
                else begin
                    render_x <= render_x + 1'b1;
                end
            end
            if(map_push)begin
                map_write <= map_write + 1'b1;
                if(coverage_error)begin
                    coverage_error_count <= coverage_error_count + 1'b1;
                end
                if(validity_fallback)begin
                    validity_fallback_count <= validity_fallback_count + 1'b1;
                end
            end
            if(request_fire)begin
                active_uv         <= mem_req_uv;
                active_weights    <= map_queue[map_read][137 : 111];
                active_xy         <= map_queue[map_read][158 : 138];
                map_read          <= map_read + 1'b1;
                awaiting_response <= 1'b1;
            end
            if(sample_fire)begin
                awaiting_response <= 1'b0;
            end
            if(blend_valid)begin
                output_write <= output_write + 1'b1;
            end
            if(output_fire)begin
                output_read <= output_read + 1'b1;
                if(out_eof)begin
                    busy <= 1'b0;
                    done <= 1'b1;
                end
            end
            if(start && !busy)begin
                busy                    <= 1'b1;
                render_x                <= 0;
                render_y                <= 0;
                issue_finished          <= 1'b0;
                map_write               <= 0;
                map_read                <= 0;
                map_reserved            <= 0;
                map_count               <= 0;
                awaiting_response       <= 1'b0;
                output_write            <= 0;
                output_read             <= 0;
                output_count            <= 0;
                result_reserved         <= 0;
                coverage_error_count    <= 0;
                validity_fallback_count <= 0;
            end
        end
    end

endmodule
