// One synchronous BRAM bank. No frame image or per-pixel weight table is stored here.
module grid_node_rom#(
    parameter   DEPTH                        =   1098,
    parameter   INIT_FILE                    =   ""
)(
    input                   clk,
    input                   rd_en,
    input       [10 : 0]    rd_addr,
    output reg  [35 : 0]    rd_data
);

    (* syn_ramstyle = "block_ram" *) reg [35 : 0] memory[0 : DEPTH - 1];

    initial begin
        $readmemh(INIT_FILE, memory);
    end

    always@(posedge clk)begin
        if(rd_en)begin
            rd_data <= memory[rd_addr];
        end
    end

endmodule
