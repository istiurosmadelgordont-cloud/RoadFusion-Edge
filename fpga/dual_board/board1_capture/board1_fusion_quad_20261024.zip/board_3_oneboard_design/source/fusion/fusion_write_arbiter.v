// Burst ownership remains fixed from AW selection through controller WLAST.
module fusion_write_arbiter#(
    parameter   [3 : 0]     CAPTURE_AXI_LEN          =   4'd8,
    parameter   [3 : 0]     RESULT_AXI_LEN           =   4'd7
)(
    input                   clk,
    input                   rst_n,
    input                   capture_awvalid,
    output                  capture_awready,
    input       [27 : 0]    capture_awaddr,
    input       [255 : 0]   capture_wdata,
    input       [31 : 0]    capture_wstrb,
    output                  capture_wready,
    output                  capture_wlast,
    input                   result_awvalid,
    output                  result_awready,
    input       [27 : 0]    result_awaddr,
    input       [255 : 0]   result_wdata,
    output                  result_wready,
    output                  result_wlast,
    output      [3 : 0]     awlen,
    output                  awvalid,
    input                   awready,
    output      [27 : 0]    awaddr,
    output      [255 : 0]   wdata,
    output      [31 : 0]    wstrb,
    input                   wready,
    input                   wlast
);
    reg         [1 : 0]     state;
    reg                     owner;
    reg                     last_owner;
    reg         [27 : 0]    address;

    // Preserve the legacy capture encoding; only new result writes use LEN=7.
    // owner is held constant from AW selection through WLAST.
    assign awlen           = owner ? RESULT_AXI_LEN : CAPTURE_AXI_LEN;
    assign awvalid         = state == 1;
    assign awaddr          = address;
    assign capture_awready = state == 1 && !owner && awready;
    assign result_awready  = state == 1 && owner && awready;
    assign capture_wready  = state == 2 && !owner && wready;
    assign result_wready   = state == 2 && owner && wready;
    assign capture_wlast   = state == 2 && !owner && wlast;
    assign result_wlast    = state == 2 && owner && wlast;
    assign wdata           = owner ? result_wdata : capture_wdata;
    assign wstrb           = owner ? 32'hffffffff : capture_wstrb;

    always@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            state      <= 0;
            owner      <= 0;
            last_owner <= 1;
            address    <= 0;
        end
        else begin
            case(state)
                0:begin
                    if(result_awvalid && (!capture_awvalid || !last_owner))begin
                        owner   <= 1;
                        address <= result_awaddr;
                        state   <= 1;
                    end
                    else if(capture_awvalid)begin
                        owner   <= 0;
                        address <= capture_awaddr;
                        state   <= 1;
                    end
                end
                1:begin
                    if(awready)begin
                        state <= 2;
                    end
                end
                2:begin
                    if(wready && wlast)begin
                        state      <= 0;
                        last_owner <= owner;
                    end
                end
                default:begin
                    state <= 0;
                end
            endcase
        end
    end
endmodule
