// Uniform 16x16 control grid, padded to x=1920 and y=544.
// Each node: bits35:18 v Q10.8, bits17:0 u Q10.8; all-ones is invalid.
// Parity banking permits four different corner nodes to be read on one clock.
module grid_coordinate_interp#(
    parameter   FILE_0                       =   "",
    parameter   FILE_1                       =   "",
    parameter   FILE_2                       =   "",
    parameter   FILE_3                       =   ""
)(
    input                   clk,
    input                   rst_n,
    input                   in_valid,
    input       [10 : 0]    in_x,
    input       [9 : 0]     in_y,
    output reg              out_valid,
    output reg              coordinate_valid,
    output reg  [17 : 0]    source_u,
    output reg  [17 : 0]    source_v
);

    wire        [6 : 0]     col;
    wire        [5 : 0]     row;
    wire        [10 : 0]    addr00;
    wire        [10 : 0]    addr10;
    wire        [10 : 0]    addr01;
    wire        [10 : 0]    addr11;
    reg         [10 : 0]    addr0;
    reg         [10 : 0]    addr1;
    reg         [10 : 0]    addr2;
    reg         [10 : 0]    addr3;
    wire        [35 : 0]    bank0;
    wire        [35 : 0]    bank1;
    wire        [35 : 0]    bank2;
    wire        [35 : 0]    bank3;
    reg         [35 : 0]    node00;
    reg         [35 : 0]    node10;
    reg         [35 : 0]    node01;
    reg         [35 : 0]    node11;
    reg                     valid_s0;
    reg                     valid_s1;
    reg                     corners_s1;
    reg         [1 : 0]     parity_s0;
    reg         [4 : 0]     fx_s0;
    reg         [4 : 0]     fy_s0;
    reg         [4 : 0]     fy_s1;
    reg         [22 : 0]    u_top;
    reg         [22 : 0]    u_bottom;
    reg         [22 : 0]    v_top;
    reg         [22 : 0]    v_bottom;
    wire        [27 : 0]    u_sum;
    wire        [27 : 0]    v_sum;

    // Five-bit coefficient, implemented with shifts/adds instead of an APM.
    function [27 : 0] scale_fraction;
        input   [22 : 0] value;
        input   [4 : 0]  fraction;
        reg     [27 : 0] extended_value;
        integer          bit_index;
        begin
            extended_value = {5'd0, value};
            scale_fraction = 28'd0;
            for(bit_index = 0; bit_index < 5; bit_index = bit_index + 1)begin
                if(fraction[bit_index])begin
                    scale_fraction = scale_fraction + (extended_value << bit_index);
                end
            end
        end
    endfunction

    assign col    = in_x[10 : 4];
    assign row    = in_y[9 : 4];
    assign addr00 = (row >> 1) * 61 + (col >> 1);
    assign addr10 = (row >> 1) * 61 + ((col + 7'd1) >> 1);
    assign addr01 = ((row + 6'd1) >> 1) * 61 + (col >> 1);
    assign addr11 = ((row + 6'd1) >> 1) * 61 + ((col + 7'd1) >> 1);

    always@(*)begin
        case({row[0], col[0]})
            2'd0:begin
                addr0 = addr00;
                addr1 = addr10;
                addr2 = addr01;
                addr3 = addr11;
            end
            2'd1:begin
                addr0 = addr10;
                addr1 = addr00;
                addr2 = addr11;
                addr3 = addr01;
            end
            2'd2:begin
                addr0 = addr01;
                addr1 = addr11;
                addr2 = addr00;
                addr3 = addr10;
            end
            default:begin
                addr0 = addr11;
                addr1 = addr01;
                addr2 = addr10;
                addr3 = addr00;
            end
        endcase
    end

    grid_node_rom#(
        .INIT_FILE          (FILE_0                 )
    )u_bank0(
        .clk                (clk                    ),
        .rd_en              (in_valid               ),
        .rd_addr            (addr0                  ),
        .rd_data            (bank0                  )
    );

    grid_node_rom#(
        .INIT_FILE          (FILE_1                 )
    )u_bank1(
        .clk                (clk                    ),
        .rd_en              (in_valid               ),
        .rd_addr            (addr1                  ),
        .rd_data            (bank1                  )
    );

    grid_node_rom#(
        .INIT_FILE          (FILE_2                 )
    )u_bank2(
        .clk                (clk                    ),
        .rd_en              (in_valid               ),
        .rd_addr            (addr2                  ),
        .rd_data            (bank2                  )
    );

    grid_node_rom#(
        .INIT_FILE          (FILE_3                 )
    )u_bank3(
        .clk                (clk                    ),
        .rd_en              (in_valid               ),
        .rd_addr            (addr3                  ),
        .rd_data            (bank3                  )
    );

    always@(*)begin
        case(parity_s0)
            2'd0:begin
                node00 = bank0;
                node10 = bank1;
                node01 = bank2;
                node11 = bank3;
            end
            2'd1:begin
                node00 = bank1;
                node10 = bank0;
                node01 = bank3;
                node11 = bank2;
            end
            2'd2:begin
                node00 = bank2;
                node10 = bank3;
                node01 = bank0;
                node11 = bank1;
            end
            default:begin
                node00 = bank3;
                node10 = bank2;
                node01 = bank1;
                node11 = bank0;
            end
        endcase
    end

    assign u_sum = scale_fraction(u_top, 5'd16 - fy_s1) + scale_fraction(u_bottom, fy_s1) + 28'd128;
    assign v_sum = scale_fraction(v_top, 5'd16 - fy_s1) + scale_fraction(v_bottom, fy_s1) + 28'd128;

    always@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            valid_s0        <= 1'b0;
            valid_s1        <= 1'b0;
            out_valid       <= 1'b0;
            coordinate_valid <= 1'b0;
            corners_s1      <= 1'b0;
            parity_s0       <= 0;
            fx_s0           <= 0;
            fy_s0           <= 0;
            fy_s1           <= 0;
            u_top           <= 0;
            u_bottom        <= 0;
            v_top           <= 0;
            v_bottom        <= 0;
            source_u        <= 0;
            source_v        <= 0;
        end
        else begin
            valid_s0  <= in_valid;
            valid_s1  <= valid_s0;
            out_valid <= valid_s1;
            if(in_valid)begin
                parity_s0 <= {row[0], col[0]};
                fx_s0     <= {1'b0, in_x[3 : 0]};
                fy_s0     <= {1'b0, in_y[3 : 0]};
            end
            if(valid_s0)begin
                u_top      <= scale_fraction({5'd0, node00[17 : 0]}, 5'd16 - fx_s0) +
                               scale_fraction({5'd0, node10[17 : 0]}, fx_s0);
                u_bottom   <= scale_fraction({5'd0, node01[17 : 0]}, 5'd16 - fx_s0) +
                               scale_fraction({5'd0, node11[17 : 0]}, fx_s0);
                v_top      <= scale_fraction({5'd0, node00[35 : 18]}, 5'd16 - fx_s0) +
                               scale_fraction({5'd0, node10[35 : 18]}, fx_s0);
                v_bottom   <= scale_fraction({5'd0, node01[35 : 18]}, 5'd16 - fx_s0) +
                               scale_fraction({5'd0, node11[35 : 18]}, fx_s0);
                fy_s1      <= fy_s0;
                corners_s1 <= (node00[17 : 0] <= 245504 && node00[35 : 18] <= 137984) &&
                              (node10[17 : 0] <= 245504 && node10[35 : 18] <= 137984) &&
                              (node01[17 : 0] <= 245504 && node01[35 : 18] <= 137984) &&
                              (node11[17 : 0] <= 245504 && node11[35 : 18] <= 137984);
            end
            if(valid_s1)begin
                source_u <= u_sum[25 : 8];
                source_v <= v_sum[25 : 8];
                coordinate_valid <= corners_s1 && (u_sum >> 8) <= 28'd245504 &&
                                                     (v_sum >> 8) <= 28'd137984;
            end
        end
    end

endmodule
