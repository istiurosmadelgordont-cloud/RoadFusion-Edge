`timescale 1ns/1ps
module mode_key_tb;
    reg clk = 0;
    reg rst_n = 0;
    reg key_n = 1;
    wire requested_quad;
    reg previous = 0;
    integer changes = 0;
    reg test_passed = 0;
    always #10 clk = ~clk;
    video_mode_key#(.MCNT(31))dut(
        .clk (clk),
        .rst_n (rst_n),
        .key_n (key_n),
        .requested_quad (requested_quad)
    );
    always@(negedge clk)begin
        if(rst_n && requested_quad != previous) changes = changes + 1;
        previous = requested_quad;
    end
    task bounce;
        input integer final_level;
        begin
            for(integer j = 0; j < 5; j = j + 1)begin
                @(negedge clk); key_n = ~key_n;
                repeat(3) @(negedge clk);
            end
            key_n = final_level;
        end
    endtask
    initial begin
        repeat(8) @(negedge clk);
        rst_n = 1;
        repeat(12) @(negedge clk);
        bounce(0);
        repeat(600) @(negedge clk);
        if(!requested_quad || changes != 1) $fatal(1, "Bounce/long hold caused wrong toggle count");
        bounce(1);
        repeat(100) @(negedge clk);
        if(changes != 1) $fatal(1, "Release toggled mode");
        bounce(0);
        repeat(100) @(negedge clk);
        if(requested_quad || changes != 2) $fatal(1, "Second press did not return to fusion");
        test_passed = 1;
        $display("PASS key wrapper: original debounce, bounce, held key, release, one toggle per press");
        $finish;
    end
endmodule
