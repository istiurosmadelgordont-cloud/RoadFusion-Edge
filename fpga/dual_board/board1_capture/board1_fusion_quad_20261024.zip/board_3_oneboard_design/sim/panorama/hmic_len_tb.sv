`timescale 1ns/1ps
// HMIC interface contract: every accepted ARLEN requests ARLEN+1 data beats.
// Demonstrate the original failure, then verify the corrected encoding.
module hmic_len_tb;
    reg                     clk = 0;
    reg                     rst_n = 0;
    reg                     start = 0;
    reg         [3 : 0]     arlen = 8;
    wire                    busy;
    wire                    out_valid;
    wire                    arvalid;
    wire                    arready;
    wire        [27 : 0]    araddr;
    reg                     rvalid = 0;
    reg                     rlast = 0;
    wire        [31 : 0]    errors;
    wire        [31 : 0]    coverage;
    reg                     pending = 0;
    reg         [3 : 0]     length = 0;
    integer                 beat = 0;
    integer                 cycles = 0;
    integer                 pixel_count = 0;
    reg                     test_passed = 0;

    always #2.5 clk = ~clk;
    assign arready = !pending && !rvalid;

    fusion_ddr_pipeline dut(
        .clk              (clk),
        .rst_n            (rst_n),
        .start            (start),
        .frame_pages      (8'he4),
        .busy             (busy),
        .done             (),
        .out_ready        (1'b1),
        .out_valid        (out_valid),
        .out_rgb          (),
        .out_x            (),
        .out_y            (),
        .out_sof          (),
        .out_eol          (),
        .out_eof          (),
        .legacy_urgent    (1'b0),
        .legacy_arvalid   (1'b0),
        .legacy_arready   (),
        .legacy_araddr    (28'd0),
        .legacy_rvalid    (),
        .legacy_rlast     (),
        .legacy_rdata     (),
        .arvalid          (arvalid),
        .arready          (arready),
        .araddr           (araddr),
        .rvalid           (rvalid),
        .rlast            (rlast),
        .rdata            (256'd0),
        .burst_count      (),
        .protocol_errors  (errors),
        .coverage_errors  (coverage),
        .fallback_count   ()
    );

    always@(posedge clk)begin
        if(!rst_n)begin
            rvalid <= 0;
            rlast <= 0;
            pending <= 0;
            beat <= 0;
            pixel_count <= 0;
        end
        else begin
            cycles = cycles + 1;
            rvalid <= 0;
            rlast <= 0;
            if(arvalid && arready)begin
                pending <= 1;
                length <= arlen;
                beat <= 0;
            end
            if(pending)begin
                rvalid <= 1;
                rlast <= beat == length;
                if(beat == length) pending <= 0;
                else beat <= beat + 1;
            end
            if(out_valid) pixel_count <= pixel_count + 1;
            if(cycles > 20000) $fatal(1, "HMIC length test timeout");
        end
    end

    task automatic reset_and_start;
        begin
            @(negedge clk);
            rst_n = 0;
            start = 0;
            repeat(5) @(negedge clk);
            rst_n = 1;
            @(negedge clk);
            start = 1;
            @(negedge clk);
            start = 0;
        end
    endtask

    initial begin
        #0.1 rst_n = 1;
        #0.1 rst_n = 0;
        reset_and_start();
        wait(errors != 0);
        @(negedge clk);
        if(errors != 1 || dut.u_sampler.beat != 7 || pixel_count != 0)
            $fatal(1, "Old LEN failure was not reproduced correctly");
        repeat(25) @(negedge clk);
        if(errors != 1 || pixel_count != 0 || !busy)
            $fatal(1, "Sampler did not retain the original failed first-frame state");
        $display("REPRODUCED original: ARLEN=8 returns9beats; sampler_errors=1 at expected_beat=7; output_pixels=0");
        arlen = 7;
        reset_and_start();
        wait(pixel_count >= 128);
        @(negedge clk);
        if(errors != 0 || coverage != 0) $fatal(1, "Corrected length still fails");
        test_passed = 1;
        $display("PASS HMIC LEN encoding: ARLEN=7 returns8beats; sampler_errors=0 output_pixels=%0d", pixel_count);
        $finish;
    end
endmodule
