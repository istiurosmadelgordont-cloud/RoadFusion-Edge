onerror {quit -code 1 -force}
onbreak {}
do sim/panorama/run_page_lock.do
quit -code 0 -force
