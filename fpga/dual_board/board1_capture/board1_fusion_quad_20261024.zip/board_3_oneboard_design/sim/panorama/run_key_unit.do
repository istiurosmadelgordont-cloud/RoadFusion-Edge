catch {quit -sim}
if {![file isdirectory sim/panorama/work_units]} {vlib sim/panorama/work_units}
vmap -modelsimini sim/panorama/modelsim.ini work_units sim/panorama/work_units
vlog -modelsimini sim/panorama/modelsim.ini -sv -work work_units -timescale 1ns/1ps source/fusion/Key_anti_shake.v source/fusion/video_mode_key.v sim/panorama/mode_key_tb.sv
vsim -modelsimini sim/panorama/modelsim.ini -voptargs=+acc -onfinish stop work_units.mode_key_tb
run -all
if {[examine -radix unsigned sim:/mode_key_tb/test_passed] != 1} {error "Unit test failed"}

