catch {quit -sim}
vlog -sv -work work_panorama sim/panorama/grid_pipeline_stall_tb.sv
vsim -modelsimini sim/panorama/modelsim.ini -voptargs=+acc -onfinish stop work_panorama.grid_pipeline_stall_tb
run -all
if {[examine -radix unsigned sim:/grid_pipeline_stall_tb/test_passed] != 1} {error "Grid pipeline stall test failed"}
puts "PASS: two full frames with memory delays, output backpressure and queue wraparound"
