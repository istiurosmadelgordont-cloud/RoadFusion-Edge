onerror {quit -code 1 -force}
onbreak {}
do sim/panorama/run_panorama.do
quit -code 0 -force
