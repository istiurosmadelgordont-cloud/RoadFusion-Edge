`timescale 1ns/1ps
// Behavioral DDR memory only; all result writes and video reads use the RTL masters.
module panorama_ddr_model#(
    parameter READ_BASE_DELAY = 0
)(
    input                   clk,
    input                   rst_n,
    input       [3 : 0]     load_valid,
    input       [95 : 0]    load_rgb,
    output                  loaded,
    input       [3 : 0]     lock_valid,
    input       [7 : 0]     lock_pages,
    input       [3 : 0]     awlen,
    input       [3 : 0]     arlen,
    input                   awvalid,
    output                  awready,
    input       [27 : 0]    awaddr,
    input       [255 : 0]   wdata,
    input       [31 : 0]    wstrb,
    output                  wready,
    output                  wlast,
    input                   arvalid,
    output                  arready,
    input       [27 : 0]    araddr,
    output reg              rvalid = 0,
    output reg              rlast = 0,
    output reg  [255 : 0]   rdata
);
    reg         [15 : 0]    source_pixels[0 : 2073599];
    reg         [31 : 0]    result_pixels[0 : 2073599];
    integer                 count[0 : 3];
    reg         [31 : 0]    random_bits = 32'h93ab72f1;
    reg                     write_pending = 0;
    reg                     read_pending = 0;
    reg         [27 : 0]    write_address;
    reg         [27 : 0]    read_address;
    integer                 write_beat = 0;
    reg         [3 : 0]     write_len = 0;
    reg         [3 : 0]     read_len = 0;
    integer                 read_beat = 0;
    integer                 read_delay = 0;
    reg         [23 : 0]    rgb;
    integer                 c;
    integer                 offset;
    integer                 bank;

    assign loaded = count[0] == 518400 && count[1] == 518400 && count[2] == 518400 && count[3] == 518400;
    assign awready = loaded && !write_pending && random_bits[2 : 0] != 0;
    assign wready = write_pending && random_bits[1 : 0] != 0;
    assign wlast  = wready && write_beat == write_len;
    assign arready = loaded && !read_pending && !rvalid && random_bits[4 : 2] != 0;

    function [255 : 0] read_beat_value;
        input [27 : 0] address;
        integer c;
        integer page;
        integer index;
        integer j;
        reg [15 : 0] raw;
        begin
            read_beat_value = 0;
            if(address[27 : 24] == 1)begin
                index = address[19 : 0];
                if(address[23 : 21] != 0 || index + 7 >= 1036800)
                    $fatal(1, "Invalid result DDR read address %h", address);
                for(j = 0; j < 8; j = j + 1)
                    read_beat_value[j * 32 +: 32] = result_pixels[address[20] * 1036800 + index + j];
            end
            else begin
                c = address[23 : 22];
                page = address[21 : 20];
                index = address[19 : 0] * 2;
                if(address[27 : 24] != 0 || index + 15 >= 518400)
                    $fatal(1, "Invalid source DDR read address %h", address);
                for(j = 0; j < 16; j = j + 1)begin
                    raw = source_pixels[c * 518400 + index + j];
                    if(page != c) raw = raw ^ 16'hffff;
                    read_beat_value[j * 16 +: 16] = raw;
                end
            end
        end
    endfunction

    initial begin
        for(c = 0; c < 4; c = c + 1) count[c] = 0;
    end

    always@(posedge clk)begin
        if(rst_n)begin
            for(c = 0; c < 4; c = c + 1)begin
                if(load_valid[c])begin
                    rgb = load_rgb[c * 24 +: 24];
                    source_pixels[c * 518400 + count[c]] <= {rgb[23 : 19], rgb[15 : 10], rgb[7 : 3]};
                    count[c] <= count[c] + 1;
                end
            end
            random_bits <= {random_bits[30 : 0], random_bits[31] ^ random_bits[21] ^ random_bits[1] ^ random_bits[0]};
            rvalid <= 0;
            rlast <= 0;
            if(awvalid && awready)begin
                if(awaddr[5 : 0] != 0) $fatal(1, "Unaligned write burst");
                write_pending <= 1;
                write_address <= awaddr;
                write_beat <= 0;
                write_len <= awlen;
                if(awaddr[27 : 24] == 0 && lock_valid[awaddr[23 : 22]] &&
                   awaddr[21 : 20] == lock_pages[awaddr[23 : 22] * 2 +: 2])
                    $fatal(1, "Attempt to overwrite a locked source page");
            end
            if(wready)begin
                if(wstrb != 32'hffffffff) $fatal(1, "Wrong write strobe");
                if(write_address[27 : 24] == 1)begin
                    offset = write_address[19 : 0] + write_beat * 8;
                    bank = write_address[20];
                    if(offset + 7 >= 1036800) $fatal(1, "Result DDR write overrun");
                    for(integer j = 0; j < 8; j = j + 1)
                        result_pixels[bank * 1036800 + offset + j] <= wdata[j * 32 +: 32];
                end
                // Background source writes target unused channel 3 only.
                else if(write_address[23 : 22] != 3)
                    $fatal(1, "Unexpected background capture channel");
                if(wlast) write_pending <= 0;
                else write_beat <= write_beat + 1;
            end
            if(arvalid && arready)begin
                if(araddr[5 : 0] != 0) $fatal(1, "Unaligned read burst");
                read_pending <= 1;
                read_address <= araddr;
                read_beat <= 0;
                read_len <= arlen;
                read_delay <= READ_BASE_DELAY + random_bits[7 : 5];
            end
            if(read_pending)begin
                if(read_delay > 0) read_delay <= read_delay - 1;
                else if(random_bits[1 : 0] != 0)begin
                    rvalid <= 1;
                    rlast <= read_beat == read_len;
                    rdata <= read_beat_value(read_address + read_beat * 8);
                    if(read_beat == read_len) read_pending <= 0;
                    else read_beat <= read_beat + 1;
                end
            end
        end
    end
endmodule
