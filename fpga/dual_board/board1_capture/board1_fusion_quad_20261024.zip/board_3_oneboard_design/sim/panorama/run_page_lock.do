catch {quit -sim}
if {![file exists source/axi_m.v]} {error "cd to board_3_oneboard_design first"}
if {![file isdirectory sim/panorama/work_page]} {vlib sim/panorama/work_page}
vmap -modelsimini sim/panorama/modelsim.ini work_page sim/panorama/work_page
vlog -work work_page -timescale 1ns/1ps source/axi_m.v
vlog -sv -work work_page sim/panorama/page_lock_tb.sv
vsim -modelsimini sim/panorama/modelsim.ini -voptargs=+acc -onfinish stop work_page.page_lock_tb
run -all
if {[examine -radix unsigned sim:/page_lock_tb/test_passed] != 1} {error "Source page ownership test failed"}
