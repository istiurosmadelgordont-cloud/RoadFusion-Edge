# 显示读欠读修正（2026-10-23）

## RTL

- fusion_frame_reader：FIFO写侧水位<=96个256位字时请求紧急补数，达到192字后释放；每字8像素，低水位约有768像素/5.12us余量。水位跨域同步存在延迟，不能当作精确剩余像素数。
- fusion_ddr_read_arbiter：启用DISPLAY_URGENT_ENABLE时，紧急补数期间不再发起新的融合取样突发，显示请求短暂空档也保留读口。已经接收的突发完整返回，不中途切换归属。
- 显示每完成一个8拍突发，在FIFO有空间、还有剩余像素、且没有待处理VS请求时直接请求下一突发。
- 融合、采集写入、页锁和完整帧发布协议保持原有接口逻辑；原有欠读置frame_bad保护保留。
- HDMI时钟及2200×1125时序不变：150MHz时约60.606Hz；1920×540全景在1080p有效区上半部，下半部黑色。此改动不代表每秒生成60张新的融合图。
- 不增加FIFO/BRAM容量。外部顶层端口不变。独立pipeline测试将新增legacy_urgent输入接0；默认DISPLAY_URGENT_ENABLE=0保留其旧仲裁模式。

## 仿真

ModelSim压力测试使用DDR100MHz、像素150MHz；读首拍延迟26..31拍，另加入每64拍中8拍采集写占用导致的等待；融合侧持续请求读取。它是行为模型，不是厂商DDR物理时序模型。

同一测试条件下旧版在y=1复现欠读；新版连续3帧共3,110,400个全景像素逐点一致，0欠读、0协议错误，并检查下半区为黑、地址顺序、AR等待稳定、跨帧切换缓冲及融合持续推进。

从board_3_oneboard_design目录，在ModelSim中运行：

```tcl
do sim/panorama/run_reader_stress.do
```

完整BMP回归run_panorama.do也改成实际DDR100MHz，背景采集写请求从每4096拍改成每128拍，保留原图、反色图、换帧和逐像素检查。

Debugger低水位预设删除无计数器核不支持的-cnt_type参数；触发字段、端口宽度不变。

## 上板检查

需重新综合、实现和生成bit后再下载，旧bit不包含本次RTL。
CORE2检查frame_bad和underrun_count是否还在增长，以及上半部是否完整显示540行；下半部黑色属于预期。
既有DDR逻辑时序未收敛问题需以本次实现报告为准，行为仿真不能替代时序和上板验证。

## 本次构建

bit：`C:\Users\hero\Desktop\pds_prj\hdmi ethernet ov5640 sfp ddr fusion hdmi\board_3_oneboard_design\generate_bitstream\test_ddr_display_refill_20261023.sbit`

配套FIC：`C:\Users\hero\Desktop\pds_prj\hdmi ethernet ov5640 sfp ddr fusion hdmi\board_3_oneboard_design\generate_bitstream\test_ddr_display_refill_20261023.fic`

DDR域Slow Setup WNS=-4.353 ns；Fast Hold WHS=-0.262 ns。时序仍未收敛，作为调试版本上板验证。
已核对插入核CORE0/1/2的宽度283/83/98及深度512/2048/512；CORE1三端口59/9/15位。
