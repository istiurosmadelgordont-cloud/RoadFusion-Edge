`timescale 1ns/1ps
module grid_pipeline_stall_tb;
    reg                     clk = 0;
    reg                     rst_n = 0;
    reg                     start = 0;
    wire                    busy;
    wire                    done;
    wire                    req_valid;
    wire                    req_ready;
    wire        [107 : 0]   req_uv;
    wire        [2 : 0]     req_mask;
    reg                     rsp_valid = 0;
    wire                    rsp_ready;
    reg         [287 : 0]   rsp_pixels = 0;
    wire                    out_valid;
    wire                    out_ready;
    wire        [23 : 0]    out_rgb;
    wire        [23 : 0]    out_hard;
    wire        [10 : 0]    out_x;
    wire        [9 : 0]     out_y;
    wire        [26 : 0]    weights;
    wire        [31 : 0]    coverage;
    wire        [31 : 0]    fallback;
    reg                     memory_busy = 0;
    integer                 delay_count = 0;
    integer                 requests = 0;
    integer                 outputs = 0;
    integer                 cycles = 0;
    integer                 frames = 0;
    reg         [23 : 0]    pending_color;
    reg         [23 : 0]    expected_color;
    reg                     stalled = 0;
    reg         [95 : 0]    stalled_payload;
    reg                     test_passed = 0;

    always #2.5 clk = ~clk;
    assign req_ready = !memory_busy && !rsp_valid && cycles % 11 != 0;
    assign out_ready = cycles % 4096 >= 180 && cycles % 7 != 0;

    function [23 : 0] color_for;
        input integer index;
        begin
            color_for = (index * 24'hb519d3) ^ 24'h347ac1;
        end
    endfunction

    grid_fusion_top dut(
        .clk                     (clk             ),
        .rst_n                   (rst_n           ),
        .start                   (start           ),
        .busy                    (busy            ),
        .done                    (done            ),
        .mem_req_valid           (req_valid       ),
        .mem_req_ready           (req_ready       ),
        .mem_req_uv              (req_uv          ),
        .mem_req_mask            (req_mask        ),
        .mem_rsp_valid           (rsp_valid       ),
        .mem_rsp_ready           (rsp_ready       ),
        .mem_rsp_pixels          (rsp_pixels      ),
        .out_valid               (out_valid       ),
        .out_ready               (out_ready       ),
        .out_rgb                 (out_rgb         ),
        .out_hard_rgb            (out_hard        ),
        .out_x                   (out_x           ),
        .out_y                   (out_y           ),
        .out_sof                 (                ),
        .out_eol                 (                ),
        .out_eof                 (                ),
        .out_weights             (weights         ),
        .coverage_error_count    (coverage        ),
        .validity_fallback_count (fallback        )
    );

    initial begin
        #0.1 rst_n = 1;
        #0.1 rst_n = 0;
        repeat(5) @(negedge clk);
        rst_n = 1;
        for(integer frame = 0; frame < 2; frame = frame + 1)begin
            @(negedge clk);
            requests = 0;
            outputs = 0;
            start = 1;
            @(negedge clk);
            start = 0;
            wait(done);
            @(negedge clk);
            if(outputs != 1036800 || requests != 1036800 || coverage != 0)
                $fatal(1, "Pipeline frame length or coverage failure");
            frames = frames + 1;
        end
        test_passed = 1;
        $display("PASS grid pipeline: frames=%0d pixels_per_frame=%0d cycles=%0d", frames, outputs, cycles);
        $finish;
    end

    always@(posedge clk)begin
        if(rst_n)begin
            cycles = cycles + 1;
            if(req_valid && req_ready)begin
                memory_busy <= 1;
                delay_count <= requests % 5;
                pending_color <= color_for(requests);
                requests = requests + 1;
            end
            if(memory_busy)begin
                if(delay_count == 0)begin
                    memory_busy <= 0;
                    rsp_valid <= 1;
                    rsp_pixels <= {12{pending_color}};
                end
                else delay_count <= delay_count - 1;
            end
            if(rsp_valid && rsp_ready)begin
                rsp_valid <= 0;
            end
            if(stalled && (!out_valid || {weights, out_y, out_x, out_hard, out_rgb} !== stalled_payload))
                $fatal(1, "Output changed during backpressure");
            stalled = out_valid && !out_ready;
            stalled_payload = {weights, out_y, out_x, out_hard, out_rgb};
            if(out_valid && out_ready)begin
                expected_color = color_for(outputs);
                if(out_x != outputs % 1920 || out_y != outputs / 1920 ||
                   out_rgb !== expected_color || out_hard !== expected_color ||
                   ({2'd0, weights[8 : 0]} + {2'd0, weights[17 : 9]} +
                    {2'd0, weights[26 : 18]}) != 256)
                    $fatal(1, "Pipeline metadata or pixel mismatch index=%0d xy=%0d,%0d rgb=%h expected=%h",
                           outputs, out_x, out_y, out_rgb, expected_color);
                outputs = outputs + 1;
            end
            if(dut.map_count > 16 || dut.map_reserved > 16 || dut.output_count > 16 ||
               dut.result_reserved > 16) $fatal(1, "Queue credit overflow");
            if(cycles > 25000000) $fatal(1, "Pipeline timeout");
        end
    end
endmodule
