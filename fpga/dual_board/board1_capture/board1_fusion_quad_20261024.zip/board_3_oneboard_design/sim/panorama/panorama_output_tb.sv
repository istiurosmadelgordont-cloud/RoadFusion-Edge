`timescale 1ns/1ps
module panorama_output_tb;
    reg                     clk = 0;
    reg                     pixel_clk = 0;
    reg                     rst_n = 0;
    reg         [3 : 0]     load_enable = 0;
    wire        [3 : 0]     load_valid;
    wire        [95 : 0]    load_rgb;
    wire                    loaded;
    reg         [7 : 0]     source_pages = 8'he4;
    wire        [3 : 0]     lock_valid;
    wire        [7 : 0]     lock_pages;
    reg         [3 : 0]     lock_granted = 0;
    reg                     capture_awvalid = 0;
    wire                    capture_awready;
    wire        [27 : 0]    capture_awaddr;
    wire        [255 : 0]   capture_wdata;
    wire                    capture_wready;
    wire                    capture_wlast;
    reg                     capture_busy = 0;
    reg         [3 : 0]     capture_beat = 0;
    integer                 capture_bursts = 0;
    wire        [3 : 0]     awlen;
    wire                    awvalid;
    wire                    awready;
    wire        [27 : 0]    awaddr;
    wire        [255 : 0]   wdata;
    wire        [31 : 0]    wstrb;
    wire                    wready;
    wire                    wlast;
    wire                    arvalid;
    wire                    arready;
    wire        [27 : 0]    araddr;
    wire                    rvalid;
    wire                    rlast;
    wire        [255 : 0]   rdata;
    wire                    vs;
    wire                    hs;
    wire                    de;
    wire        [11 : 0]    x;
    wire        [11 : 0]    y;
    wire                    video_vs;
    wire                    video_hs;
    wire                    video_de;
    wire        [23 : 0]    video_rgb;
    wire        [31 : 0]    rendered_frames;
    wire        [31 : 0]    underruns;
    wire        [31 : 0]    errors;
    reg         [23 : 0]    expected[0 : 2073599];
    integer                 render_phase = 0;
    integer                 write_pixels = 0;
    integer                 result_bursts = 0;
    integer                 versions[0 : 1];
    reg                     model_write_owner;
    reg         [27 : 0]    model_write_address;
    integer                 model_write_beat;
    integer                 cycles = 0;
    integer                 render_start_cycle = 0;
    integer                 previous_commit_cycle = 0;
    integer                 good_normal_frames = 0;
    integer                 good_inverse_frames = 0;
    integer                 black_frames = 0;
    integer                 panel_frame = -1;
    integer                 panel_count = 0;
    integer                 panel_phase;
    reg                     panel_show;
    reg                     panel_bank;
    reg                     panel_started = 0;
    reg                     output_vs_d = 0;
    reg                     expected_vs;
    reg                     expected_hs;
    reg                     expected_de;
    reg         [11 : 0]    expected_x;
    reg         [11 : 0]    expected_y;
    reg         [23 : 0]    target_pixel;
    reg                     normal_write = 0;
    reg                     inverse_write = 0;
    reg         [23 : 0]    image_pixel;
    reg                     test_passed = 0;
    reg                     pixel_check_enable = 0;

    always #5 clk = ~clk;
    always #(10.0 / 3.0) pixel_clk = ~pixel_clk;
    assign capture_awaddr = 28'h0c00000 + (capture_bursts % 1000) * 64;
    assign capture_wdata = {8{32'h6a72c991}};

    bmp_rgb_pack#(
        .INPUT_ARG ("LEFT"),
        .PIC_PATH ("sim/fusion/input/left.bmp")
    )u_load0(
        .clk (clk),
        .rst_n (rst_n),
        .enable (load_enable[0]),
        .valid (load_valid[0]),
        .rgb (load_rgb[0 +: 24])
    );

    bmp_rgb_pack#(
        .INPUT_ARG ("CENTER"),
        .PIC_PATH ("sim/fusion/input/center.bmp")
    )u_load1(
        .clk (clk),
        .rst_n (rst_n),
        .enable (load_enable[1]),
        .valid (load_valid[1]),
        .rgb (load_rgb[24 +: 24])
    );

    bmp_rgb_pack#(
        .INPUT_ARG ("RIGHT"),
        .PIC_PATH ("sim/fusion/input/right.bmp")
    )u_load2(
        .clk (clk),
        .rst_n (rst_n),
        .enable (load_enable[2]),
        .valid (load_valid[2]),
        .rgb (load_rgb[48 +: 24])
    );

    bmp_rgb_pack#(
        .INPUT_ARG ("FOURTH"),
        .PIC_PATH ("sim/fusion/input/fourth.bmp")
    )u_load3(
        .clk (clk),
        .rst_n (rst_n),
        .enable (load_enable[3]),
        .valid (load_valid[3]),
        .rgb (load_rgb[72 +: 24])
    );

    panorama_output_top dut(
        .clk                     (clk                           ),
        .rst_n                   (rst_n                         ),
        .source_valid            ({4{loaded}}                   ),
        .source_pages            (source_pages                  ),
        .lock_granted            (lock_granted                  ),
        .lock_valid              (lock_valid                    ),
        .lock_pages              (lock_pages                    ),
        .capture_awvalid         (capture_awvalid               ),
        .capture_awready         (capture_awready               ),
        .capture_awaddr          (capture_awaddr                ),
        .capture_wdata           (capture_wdata                 ),
        .capture_wstrb           (32'hffffffff                  ),
        .capture_wready          (capture_wready                ),
        .capture_wlast           (capture_wlast                 ),
        .awlen                   (awlen                         ),
        .awvalid                 (awvalid                       ),
        .awready                 (awready                       ),
        .awaddr                  (awaddr                        ),
        .wdata                   (wdata                         ),
        .wstrb                   (wstrb                         ),
        .wready                  (wready                        ),
        .wlast                   (wlast                         ),
        .arvalid                 (arvalid                       ),
        .arready                 (arready                       ),
        .araddr                  (araddr                        ),
        .rvalid                  (rvalid                        ),
        .rlast                   (rlast                         ),
        .rdata                   (rdata                         ),
        .pixel_clk               (pixel_clk                     ),
        .vs                      (vs                            ),
        .hs                      (hs                            ),
        .de                      (de                            ),
        .pixel_y                 (y                             ),
        .video_vs                (video_vs                      ),
        .video_hs                (video_hs                      ),
        .video_de                (video_de                      ),
        .video_rgb               (video_rgb                     ),
        .rendered_frames         (rendered_frames               ),
        .underrun_count          (underruns                     ),
        .error_count             (errors                        )
    );

    panorama_ddr_model u_ddr(
        .clk                     (clk                           ),
        .rst_n                   (rst_n                         ),
        .load_valid              (load_valid                    ),
        .load_rgb                (load_rgb                      ),
        .loaded                  (loaded                        ),
        .lock_valid              (lock_valid                    ),
        .lock_pages              (lock_pages                    ),
        .awlen                   (awlen                         ),
        .arlen                   (4'd7                         ),
        .awvalid                 (awvalid                       ),
        .awready                 (awready                       ),
        .awaddr                  (awaddr                        ),
        .wdata                   (wdata                         ),
        .wstrb                   (wstrb                         ),
        .wready                  (wready                        ),
        .wlast                   (wlast                         ),
        .arvalid                 (arvalid                       ),
        .arready                 (arready                       ),
        .araddr                  (araddr                        ),
        .rvalid                  (rvalid                        ),
        .rlast                   (rlast                         ),
        .rdata                   (rdata                         )
    );

    sync_generator u_sync(
        .clk                     (pixel_clk                     ),
        .rstn                    (rst_n                         ),
        .vs_out                  (vs                            ),
        .hs_out                  (hs                            ),
        .de_out                  (de                            ),
        .de_re                   (                              ),
        .x_act                   (x                             ),
        .y_act                   (y                             )
    );

    panorama_bmp_writer#(
        .HEIGHT                  (1080                          ),
        .OUTPUT_ARG              ("NORMAL_OUTPUT"               ),
        .PIC_PATH                ("sim/panorama/results/normal_upper.bmp")
    )u_normal(
        .clk                     (pixel_clk                     ),
        .valid                   (normal_write                  ),
        .rgb                     (image_pixel                   )
    );

    panorama_bmp_writer#(
        .HEIGHT                  (1080                          ),
        .OUTPUT_ARG              ("INVERSE_OUTPUT"              ),
        .PIC_PATH                ("sim/panorama/results/changed_upper.bmp")
    )u_inverse(
        .clk                     (pixel_clk                     ),
        .valid                   (inverse_write                 ),
        .rgb                     (image_pixel                   )
    );

    initial begin
        versions[0] = -1;
        versions[1] = -1;
        $readmemh("sim/panorama/reference/fusion_rgb.hex", expected, 0, 1036799);
        $readmemh("sim/panorama/reference/complement_rgb.hex", expected, 1036800, 2073599);
        #0.1 rst_n = 1;
        #0.1 rst_n = 0;
        repeat(10) @(negedge clk);
        rst_n = 1;
        for(integer c = 0; c < 4; c = c + 1)begin
            load_enable[c] = 1;
            repeat(11) @(negedge clk);
        end
        wait(rendered_frames >= 1);
        @(negedge clk);
        source_pages = 8'h1b;
        wait(good_inverse_frames >= 2 && good_normal_frames >= 1);
        if(errors != 0 || underruns != 0 || capture_bursts < 100 || !u_normal.image_saved || !u_inverse.image_saved)
            $fatal(1, "Output path did not complete cleanly");
        test_passed = 1;
        $display("PASS panorama DDR output: renders=%0d normal_frames=%0d changed_frames=%0d black_startup=%0d capture_bursts=%0d cycles=%0d",
                 rendered_frames, good_normal_frames, good_inverse_frames, black_frames, capture_bursts, cycles);
        $finish;
    end

    always@(posedge clk)begin
        if(rst_n)begin
            cycles = cycles + 1;
            lock_granted <= lock_valid;
            if(loaded && !capture_busy && !capture_awvalid && cycles % 128 == 0)
                capture_awvalid <= 1;
            if(capture_awvalid && capture_awready)begin
                capture_awvalid <= 0;
                capture_busy <= 1;
                capture_beat <= 0;
            end
            if(capture_wready)begin
                if(capture_wlast != (capture_beat == 8)) $fatal(1, "Capture WLAST misrouting");
                if(capture_wlast)begin
                    capture_busy <= 0;
                    capture_bursts = capture_bursts + 1;
                end
                else capture_beat <= capture_beat + 1;
            end
            if(dut.render_start)begin
                render_start_cycle = cycles;
                render_phase = dut.lock_pages == 8'he4 ? 0 : 1;
                write_pixels = 0;
                result_bursts = 0;
            end
            if(awvalid && awready)begin
                model_write_owner = awaddr[27 : 24] == 1;
                if(awlen != (model_write_owner ? 7 : 8))
                    $fatal(1, "Legacy capture/result AWLEN selection mismatch");
                model_write_address = awaddr;
                model_write_beat = 0;
                if(model_write_owner)begin
                    if(dut.display_valid && awaddr[20] == dut.display_buffer)
                        $fatal(1, "Renderer overwrote the displayed DDR buffer");
                    if(awaddr[19 : 0] != result_bursts * 64)
                        $fatal(1, "Result write address order mismatch");
                    result_bursts = result_bursts + 1;
                end
            end
            if(wready)begin
                if(wlast != (model_write_beat == (model_write_owner ? 7 : 8))) $fatal(1, "Controller WLAST mismatch");
                if(model_write_owner)begin
                    for(integer j = 0; j < 8; j = j + 1)begin
                        if(wdata[j * 32 +: 32] !== {8'd0, expected[render_phase * 1036800 + write_pixels]})
                            $fatal(1, "DDR result write mismatch render=%0d pixel=%0d", render_phase, write_pixels);
                        write_pixels = write_pixels + 1;
                    end
                end
                model_write_beat = model_write_beat + 1;
            end
            if(dut.u_writer.done)begin
                if(write_pixels != 1036800 || result_bursts != 16200)
                    $fatal(1, "Premature result publication");
                versions[dut.render_buffer] = render_phase;
                $display("RENDER_TIMING cycles=%0d ms=%0f compute_fps=%0f commit_interval_cycles=%0d bursts=%0d",
                         cycles - render_start_cycle, (cycles - render_start_cycle) / 100000.0,
                         100000000.0 / (cycles - render_start_cycle), cycles - previous_commit_cycle,
                         dut.u_pipeline.u_sampler.burst_count);
                previous_commit_cycle = cycles;
                $display("RESULT_COMMIT render=%0d bank=%0d cycles=%0d", render_phase, dut.render_buffer, cycles);
            end
            if(errors != 0) $fatal(1, "DDR protocol failure %0d", errors);
            if(cycles % 10000000 == 0)
                $display("PROGRESS cycles=%0d renders=%0d writer_pixels=%0d panel=%0d underruns=%0d", cycles, rendered_frames, write_pixels, panel_frame, underruns);
            if(cycles > 110000000) $fatal(1, "Panorama output timeout");
        end
    end

    always@(posedge pixel_clk)begin
        pixel_check_enable <= rst_n && dut.u_reader.pixel_reset_n;
        expected_vs <= vs;
        expected_hs <= hs;
        expected_de <= de;
        expected_x  <= x;
        expected_y  <= y;
        #0.1;
        normal_write <= 0;
        inverse_write <= 0;
        if(pixel_check_enable)begin
            if(video_vs !== expected_vs || video_hs !== expected_hs || video_de !== expected_de)
                $fatal(1, "Video sync alignment mismatch");
            if(video_vs && !output_vs_d)begin
                if(panel_started)begin
                    if(panel_count != 2073600) $fatal(1, "Bad panel frame size %0d", panel_count);
                    if(panel_show)begin
                        if(panel_phase == 0) good_normal_frames = good_normal_frames + 1;
                        else good_inverse_frames = good_inverse_frames + 1;
                    end
                    else black_frames = black_frames + 1;
                end
                panel_started = 1;
                panel_frame = panel_frame + 1;
                panel_count = 0;
            end
            output_vs_d = video_vs;
            if(video_de)begin
                if(panel_count == 0)begin
                    panel_show = dut.u_reader.frame_show;
                    panel_bank = dut.display_buffer;
                    panel_phase = versions[panel_bank];
                    if(panel_show && panel_phase < 0) $fatal(1, "Displayed incomplete DDR result buffer");
                end
                if(dut.display_buffer != panel_bank && panel_show)
                    $fatal(1, "Display buffer changed during active video");
                target_pixel = 0;
                if(panel_show && expected_y < 540)
                    target_pixel = expected[panel_phase * 1036800 + expected_y * 1920 + expected_x];
                if(video_rgb !== target_pixel)
                    $fatal(1, "Video pixel mismatch frame=%0d phase=%0d xy=%0d,%0d got=%h expected=%h", panel_frame, panel_phase, expected_x, expected_y, video_rgb, target_pixel);
                if(panel_show && panel_phase == 0 && good_normal_frames == 0) normal_write <= 1;
                if(panel_show && panel_phase == 1 && good_inverse_frames == 0) inverse_write <= 1;
                image_pixel <= video_rgb;
                panel_count = panel_count + 1;
            end
        end
    end
endmodule
