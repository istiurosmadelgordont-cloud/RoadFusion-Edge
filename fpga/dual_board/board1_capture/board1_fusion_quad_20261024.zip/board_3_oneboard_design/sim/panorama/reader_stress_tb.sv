`timescale 1ns/1ps
// Behavioral controller: delayed read returns and periodic capture-write occupancy.
// This tests arbitration/pixel integrity; it is not a vendor DDR timing model.
module reader_stress_tb;
    parameter FIXED = 1;
    reg clk = 0;
    reg pixel_clk = 0;
    reg rst_n = 0;
    reg published_buffer = 0;
    wire display_valid;
    wire display_buffer;
    wire urgent;
    wire display_arvalid;
    wire display_arready;
    wire [27:0] display_araddr;
    wire display_rvalid;
    wire display_rlast;
    wire [255:0] display_rdata;
    wire fusion_arready;
    reg [27:0] fusion_address = 0;
    wire fusion_rvalid;
    wire fusion_rlast;
    wire [255:0] fusion_rdata;
    wire arvalid;
    wire arready;
    wire [27:0] araddr;
    reg rvalid = 0;
    reg rlast = 0;
    reg [255:0] rdata = 0;
    wire vs;
    wire hs;
    wire de;
    wire [11:0] x;
    wire [11:0] y;
    wire video_vs;
    wire video_hs;
    wire video_de;
    wire [23:0] video_rgb;
    wire [31:0] protocol_errors;
    wire [31:0] underruns;
    reg busy = 0;
    reg [27:0] address;
    integer delay_left = 0;
    integer beat = 0;
    integer cycles = 0;
    integer reads = 0;
    integer fusion_beats = 0;
    integer display_bursts = 0;
    integer capture_write_beats = 0;
    integer next_offset = 0;
    integer frames = 0;
    integer pixels = 0;
    integer checked_pixels = 0;
    integer bank_changes = 0;
    reg last_bank = 0;
    reg vs_previous = 0;
    reg expected_vs;
    reg expected_hs;
    reg expected_de;
    reg [11:0] expected_x;
    reg [11:0] expected_y;
    reg stalled = 0;
    reg [27:0] stalled_address;
    reg test_passed = 0;

    always #5 clk = ~clk;
    always #(10.0 / 3.0) pixel_clk = ~pixel_clk;

    // Eight capture-write cycles per 64 DDR clocks; writes continue during refill.
    wire capture_busy = (cycles % 64) < 8;
    assign arready = !busy && !rvalid && cycles % 7 != 0;

    function [23:0] pixel_value(input integer index, input bit bank);
        pixel_value = (index ^ (bank ? 24'hc35a19 : 24'h197ac3));
    endfunction

    fusion_frame_reader reader(
        .clk (clk),
        .rst_n (rst_n),
        .published_valid (1'b1),
        .published_buffer (published_buffer),
        .display_valid (display_valid),
        .display_buffer (display_buffer),
        .read_urgent (urgent),
        .arvalid (display_arvalid),
        .arready (display_arready),
        .araddr (display_araddr),
        .rvalid (display_rvalid),
        .rlast (display_rlast),
        .rdata (display_rdata),
        .pixel_clk (pixel_clk),
        .vs (vs),
        .hs (hs),
        .de (de),
        .pixel_y (y),
        .video_vs (video_vs),
        .video_hs (video_hs),
        .video_de (video_de),
        .video_rgb (video_rgb),
        .protocol_errors (protocol_errors),
        .underrun_count (underruns)
    );

    fusion_ddr_read_arbiter#(
        .DISPLAY_PRIORITY (1),
        .DISPLAY_URGENT_ENABLE (FIXED)
    )arbiter(
        .clk (clk),
        .rst_n (rst_n),
        .legacy_urgent (urgent),
        .legacy_arvalid (display_arvalid),
        .legacy_arready (display_arready),
        .legacy_araddr (display_araddr),
        .legacy_rvalid (display_rvalid),
        .legacy_rlast (display_rlast),
        .legacy_rdata (display_rdata),
        .fusion_arvalid (1'b1),
        .fusion_arready (fusion_arready),
        .fusion_araddr (fusion_address),
        .fusion_rvalid (fusion_rvalid),
        .fusion_rlast (fusion_rlast),
        .fusion_rdata (fusion_rdata),
        .arvalid (arvalid),
        .arready (arready),
        .araddr (araddr),
        .rvalid (rvalid),
        .rlast (rlast),
        .rdata (rdata)
    );

    sync_generator timing(
        .clk (pixel_clk),
        .rstn (rst_n),
        .vs_out (vs),
        .hs_out (hs),
        .de_out (de),
        .de_re (),
        .x_act (x),
        .y_act (y)
    );

    initial begin
        #100 rst_n = 1;
        #70000000 $fatal(1, "Stress timeout");
    end

    always@(negedge reader.fifo_release) next_offset = 0;

    always@(posedge clk)begin
        if(rst_n)begin
            cycles = cycles + 1;
            if(capture_busy) capture_write_beats = capture_write_beats + 1;
            if(stalled && (!arvalid || araddr !== stalled_address))
                $fatal(1, "AR changed under backpressure");
            stalled = arvalid && !arready;
            stalled_address = araddr;
            if(fusion_arready) fusion_address <= fusion_address + 64;
            if(fusion_rvalid)begin
                fusion_beats = fusion_beats + 1;
                if(fusion_rlast != (fusion_beats % 8 == 0))
                    $fatal(1, "Fusion response ownership/length error");
            end
            if(display_arvalid && display_arready)begin
                if(display_araddr !== (display_buffer ? 28'h1100000 : 28'h1000000) + next_offset)
                    $fatal(1, "Display address sequence error");
                next_offset = next_offset + 64;
                if(next_offset > 1036800) $fatal(1, "Read past frame end");
                display_bursts = display_bursts + 1;
            end
            rvalid <= 0;
            rlast <= 0;
            if(arvalid && arready)begin
                busy <= 1;
                address <= araddr;
                beat <= 0;
                // 26..31 cycles, plus capture-write occupancy at return time.
                delay_left <= 26 + reads % 6;
                reads = reads + 1;
            end
            if(busy)begin
                if(delay_left != 0) delay_left <= delay_left - 1;
                else if(!capture_busy || beat != 0)begin
                    rvalid <= 1;
                    rlast <= beat == 7;
                    for(integer lane = 0; lane < 8; lane = lane + 1)
                        rdata[lane * 32 +: 32] <= {8'b0,
                            pixel_value(address[19:0] + beat * 8 + lane, address[20])};
                    if(beat == 7) busy <= 0;
                    else beat <= beat + 1;
                end
            end
            if(protocol_errors != 0) $fatal(1, "Reader protocol error");
            if(!FIXED && underruns != 0)begin
                $display("PASS baseline reproduces underrun: cycles=%0d y=%0d display_bursts=%0d", cycles, y, display_bursts);
                test_passed = 1;
                $finish;
            end
        end
    end

    always@(posedge pixel_clk)begin
        expected_vs = vs;
        expected_hs = hs;
        expected_de = de;
        expected_x = x;
        expected_y = y;
        #0.1;
        if(rst_n && display_valid)begin
            if(video_vs !== expected_vs || video_hs !== expected_hs || video_de !== expected_de)
                $fatal(1, "HDMI timing changed");
            if(video_de)begin
                if(expected_y < 540)begin
                    if(FIXED && video_rgb !== pixel_value(expected_y * 1920 + expected_x, display_buffer))
                        $fatal(1, "Pixel mismatch x=%0d y=%0d got=%h expected=%h underruns=%0d",
                            expected_x, expected_y, video_rgb,
                            pixel_value(expected_y * 1920 + expected_x, display_buffer), underruns);
                    pixels = pixels + 1;
                    checked_pixels = checked_pixels + 1;
                end
                else if(video_rgb !== 0) $fatal(1, "Lower HDMI half must be black");
            end
            if(video_vs && !vs_previous && pixels != 0)begin
                if(pixels != 1036800) $fatal(1, "Incomplete panorama frame");
                frames = frames + 1;
                pixels = 0;
                if(display_buffer != last_bank) bank_changes = bank_changes + 1;
                last_bank = display_buffer;
                published_buffer = ~published_buffer;
                $display("FRAME %0d bank=%0d fusion_beats=%0d underruns=%0d", frames, display_buffer, fusion_beats, underruns);
                if(frames == 3)begin
                    if(underruns != 0 || fusion_beats < 1024 || bank_changes < 1 || capture_write_beats < 1024)
                        $fatal(1, "No progress or underrun");
                    $display("PASS fixed: 3 frames, pixels=%0d fusion_beats=%0d display_bursts=%0d capture_write_slots=%0d underruns=%0d",
                        checked_pixels, fusion_beats, display_bursts, capture_write_beats, underruns);
                    test_passed = 1;
                    $finish;
                end
            end
            vs_previous = video_vs;
        end
    end
endmodule
