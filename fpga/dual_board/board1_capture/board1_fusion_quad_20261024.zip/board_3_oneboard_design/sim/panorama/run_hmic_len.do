catch {quit -sim}
vlog -sv -work work_panorama sim/panorama/hmic_len_tb.sv
vsim -modelsimini sim/panorama/modelsim.ini -voptargs=+acc -onfinish stop work_panorama.hmic_len_tb
run -all
if {[examine -radix unsigned sim:/hmic_len_tb/test_passed] != 1} {error "HMIC length encoding test failed"}
puts "PASS: reproduced old LEN=8 failure and verified LEN=7 recovery"
