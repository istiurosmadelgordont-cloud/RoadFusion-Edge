catch {quit -sim}
vlog -sv -work work_panorama sim/panorama/sampler_boundary_tb.sv
vsim -modelsimini sim/panorama/modelsim.ini -voptargs=+acc -onfinish stop work_panorama.sampler_boundary_tb
run -all
if {[examine -radix unsigned sim:/sampler_boundary_tb/test_passed] != 1} {error "Sampler boundary test failed"}
puts "PASS: 240 boundary/mask/page cases and malformed burst handling"
