# 官方例程、HMIC 1.4手册与融合黑屏分析

日期：2026-10-22。目标仍为当前`board_3_oneboard_design/3_ddr_test.pds`、顶层`test_ddr`。
官方例程仅用于只读对照，本轮没有修改官方例程、原四路采集模块或DDR IP生成源码。

## 1. 板上现象与能确认的范围

用户最新抓图按独立位核对后为：

- `fusion_source_valid=0xF`：四路都曾发布过完整源帧。
- `fusion_rendered_frames=0`：第一幅全景尚未完整写回。
- `fusion_error_count[0]=1`、`[1]=0`。
- `sampler_errors[0]=1`；`writer_errors[0]=0`、`reader_errors[0]=0`、`coverage_errors=0`。
- 输出同步仍运行，RGB为0。

取样器的错误条件为：在有效读数据拍上，`RLAST`与`beat==7`不一致。
错误后进入FAILED，不再发后续取样，因此不能形成第一幅结果，显示端继续黑屏。
Debugger父总线曾把实际低位1显示成`0x80000000`；分析优先使用独立位，不将其解释为21亿次错误。

## 2. 用户指定的1.4版手册

实际阅读文件：

`C:/pango/PDS_2022.2-SP6.4/ip/system_ip/ipsxb_hmic_s/ipsxb_hmic_eval/ipsxb_hmic_s-1.4/UG022003_Logos_HMIC_S_IP.pdf`

第31/54页，图2-17/图2-18后的说明均规定：实际传输拍数为LEN值加1。
第32/54页图2-19/图2-20说明，写数据由WREADY指示有效、写LAST指示结束；
读数据由RVALID指示有效、RLAST指示结束。

|实际需要的数据拍数|IP端AWLEN/ARLEN|
|---:|---:|
|8|7|
|9|8|
|16|15|

这些是用户接口上的256位数据拍，与DDR器件自身的物理BL8不是同一个计数层级。

## 3. 已跑通官方例程的直接证据

只读参考目录：

`C:/Users/hero/Desktop/pango2026/盘古50K开发板/2_Demo/10_HDMI_DDR3_OV5640_test/10_HDMI_DDR3_OV5640_test/source/rtl`

|文件/位置|代码行为|意义|
|---|---|---|
|`wr_cmd_trans.v:154`、`:160`|`wr_len <= 4'd15`|常规写请求使用16拍|
|`wr_cmd_trans.v:167`|尾包编码为剩余拍数减1|尾包同样遵守LEN+1|
|`wr_cmd_trans.v:171`|写地址增加`{wr_len,3'd0}+8`|每256位拍占8个32位字，所以增量为`(LEN+1)*8`|
|`wr_cmd_trans.v:341`、`:347`|`rd_len <= 4'd15`|常规读请求使用16拍|
|`wr_cmd_trans.v:354`|读尾包同样减1|读写定义一致|
|`wr_cmd_trans.v:358`|读地址增加`{rd_len,3'd0}+8`|读地址同样按LEN+1推进|
|`wr_ctrl.v:87`|把`wr_len`传到`axi_awlen`|上层已编码，IP端不再额外减1|
|`rd_ctrl.v:112`|把`read_len`传到`axi_arlen`|读通道同理|
|`rd_ctrl.v:149`|`read_rdata_en=axi_rvalid`|数据拍按RVALID接收|
|`hdmi_ddr_ov5640_top.v:289`、`:344`|IP写LAST送给写控制器|符合简化AXI写接口，不能照搬普通AXI的LAST方向|

官方例程采用分块缓存、命令拆分和16拍调度；当前融合是网格映射、四邻点取样、8拍缓存。
不需要把整套官方帧缓存架构替换到融合工程，只需遵守同一IP接口协议。
官方读控制器含固定等待调度，不能把该等待常数当作任意DDR随机取样的固定返回延迟。

## 4. 当前新增融合接口存在的具体错误

修复前：顶层`M_AXI_BRUST_LEN=8`直接接到IP的`axi_arlen`，但取样缓存、显示预取和结果写主机均按8拍工作。

1. 新取样器发出读请求，IP接收到ARLEN=8。
2. 按手册，IP应返回9个有效数据拍。
3. 取样器收到第8拍时，内部`beat=7`，要求RLAST=1。
4. 实际最后一拍是第9拍，所以第8拍RLAST=0，触发一次`sampler_errors`并停止。

这与板上“取样错误1次、第一幅结果未完成、其他错误0”的现象一致。
目前可确定这是实际RTL中的协议编码错误；是否还存在别的问题，需要修复后上板复测。

之前的行为模型没有LEN输入，写死返回8拍，掩盖了顶层与IP之间的长度编码错误。
本轮模型新增AWLEN/ARLEN输入，并在地址握手时锁存长度，按LEN+1产生有效数据和LAST。

## 5. 最小修复与原四通路保留

用户确认原四路采集已经上板跑通。本轮保留该通路的原参数、FIFO预读和地址控制，不对其作未经验证的重构。

|通路|修复后IP端长度编码|
|---|---|
|原四路采集写入|仍为原来的`M_AXI_BRUST_LEN`值，默认8，保持既有行为|
|新增融合源图取样读|7，实际8拍|
|新增全景显示预取读|7，实际8拍|
|新增融合结果写回|7，实际8拍|

原采集写与新增结果写共用DDR端口，所以新增写仲裁器按锁定的owner选择AWLEN。
长度与地址一起保持到握手完成，owner保持到整个写突发结束。

不能把顶层`M_AXI_BRUST_LEN`整体由8改成7：原模块还用它计算地址步长、FIFO门限和帧末位置，整体修改会影响已跑通的原通路。
也不能通过删除RLAST检查或丢掉第9拍来掩盖接口错误。

实际RTL修改仅3个文件：

- `source/ddr_test_top.v`：新增读LEN常数7、接入仲裁后的写LEN，保留当前HDMI/以太网1/以太网0接线。
- `source/fusion/panorama_output_top.v`：传递原采集LEN配置和仲裁后AWLEN。
- `source/fusion/fusion_write_arbiter.v`：按事务owner选择原采集编码或新增结果编码7。

没有改动`axi_m.v`、`axi_m_arbitration.v`、`rw_fifo_ctrl.v`、输入缩放/抽帧、HSST、以太网或DDR IP。
PDS源码列表没有新增RTL文件，因此保留用户当前PDS。HDMI时钟、融合权重、映射精度、输出布局及约30fps更新调度均未改动。

## 6. 验证

- `hmic_len_tb`用LEN+1控制器行为，复现旧ARLEN=8时第8拍报一次取样错误、输出0像素；复位后ARLEN=7，连续输出128个像素，协议错误0。
- 完整图片回归同时使用原采集AWLEN=8与结果AWLEN=7，控制器分别产生9拍和8拍，并检查写事务归属和长度在握手时正确。
- 全景结果由RTL写回DDR模型，再由RTL连续视频读出；正常图及反相换帧图逐像素与整数参考一致。原四路输入的物理接收没有在这套模型中复现。
- 整工程使用当前板级源代码、原IP及原FDC进行Compile/Synthesize；最新资源与日志见`results/validation.json`及`board_synthesis.log`。
- 本轮没有布局布线、最终STA、生成bit或板卡下载；不将模型回归等同于实板修复确认。

## 7. 重新上板后先看这些

需要重新综合、实现、生成并下载匹配的bit/FIC，再用`ddr_ip_clk`抓：

- `sampler_errors[0]`、`writer_errors[0]`、`reader_errors[0]`应为0。
- `fusion_rendered_frames`应从0开始增长。
- 新读突发应恰有8个RVALID有效拍，RLAST与第8拍同时有效。
- `panorama_axi_awlen`在原采集事务时为8、结果事务时为7；Debugger组合总线位序需核对。

若仍报取样错误，以`sampler_errors[0]`上升沿触发并保留触发前的ARVALID/ARREADY/RVALID/RLAST，核对是否丢首拍、提前结束或超拍。
若计数正常而画面仍黑，再查看上半区坐标、display_valid和FIFO输出，不重复把黑色下半区当成故障。
