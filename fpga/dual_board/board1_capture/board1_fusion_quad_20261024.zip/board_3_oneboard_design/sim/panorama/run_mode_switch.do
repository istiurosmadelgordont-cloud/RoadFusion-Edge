catch {quit -sim}
if {![file exists source/fusion/panorama_output_top.v]} {error "cd to board_3_oneboard_design first"}
if {![file isdirectory sim/panorama/work]} {vlib sim/panorama/work}
vmap -modelsimini sim/panorama/modelsim.ini work_panorama sim/panorama/work
vlog -modelsimini sim/panorama/modelsim.ini -work work_panorama -timescale 1ns/1ps source/fusion/grid_node_rom.v
vlog -modelsimini sim/panorama/modelsim.ini -work work_panorama -timescale 1ns/1ps source/fusion/grid_coordinate_interp.v
vlog -modelsimini sim/panorama/modelsim.ini -work work_panorama -timescale 1ns/1ps source/fusion/rgb_bilinear_q8.v
vlog -modelsimini sim/panorama/modelsim.ini -work work_panorama -timescale 1ns/1ps source/fusion/fixed_seam_weights.v
vlog -modelsimini sim/panorama/modelsim.ini -work work_panorama -timescale 1ns/1ps source/fusion/rgb_feather_blend.v
vlog -modelsimini sim/panorama/modelsim.ini -work work_panorama -timescale 1ns/1ps source/fusion/grid_fusion_top.v
vlog -modelsimini sim/panorama/modelsim.ini -work work_panorama -timescale 1ns/1ps source/fusion/fusion_ddr_sampler.v
vlog -modelsimini sim/panorama/modelsim.ini -work work_panorama -timescale 1ns/1ps source/fusion/fusion_ddr_read_arbiter.v
vlog -modelsimini sim/panorama/modelsim.ini -work work_panorama -timescale 1ns/1ps source/fusion/fusion_ddr_pipeline.v
vlog -modelsimini sim/panorama/modelsim.ini -work work_panorama -timescale 1ns/1ps source/fusion/fusion_frame_writer.v
vlog -modelsimini sim/panorama/modelsim.ini -work work_panorama -timescale 1ns/1ps source/fusion/fusion_write_arbiter.v
vlog -modelsimini sim/panorama/modelsim.ini -work work_panorama -timescale 1ns/1ps source/fusion/fusion_async_fifo.v
vlog -modelsimini sim/panorama/modelsim.ini -work work_panorama -timescale 1ns/1ps source/fusion/fusion_frame_reader.v
vlog -modelsimini sim/panorama/modelsim.ini -work work_panorama -timescale 1ns/1ps source/fusion/quad_frame_renderer.v
vlog -modelsimini sim/panorama/modelsim.ini -work work_panorama -timescale 1ns/1ps source/fusion/panorama_output_top.v
vlog -modelsimini sim/panorama/modelsim.ini -work work_panorama source/sync_generator.v
vlog -modelsimini sim/panorama/modelsim.ini -sv -work work_panorama sim/fusion/bmp_image_source.sv sim/fusion/bmp_rgb_pack.sv sim/fusion/panorama_bmp_writer.sv sim/panorama/panorama_ddr_model.sv sim/panorama/panorama_output_tb.sv
vlog -modelsimini sim/panorama/modelsim.ini -work work_panorama source/fusion/Key_anti_shake.v source/fusion/video_mode_key.v
vlog -modelsimini sim/panorama/modelsim.ini -sv -work work_panorama sim/panorama/panorama_mode_tb.sv
vsim -modelsimini sim/panorama/modelsim.ini -voptargs=+acc -onfinish stop work_panorama.panorama_mode_tb
run -all
if {[examine -radix unsigned sim:/panorama_mode_tb/test_passed] != 1} {error "Mode test failed"}

puts "PASS: key, complete-frame mode switch, DDR packing and display pixels"
