`timescale 1ns/1ps
module sampler_boundary_tb;
    reg                     clk = 0;
    reg                     rst_n = 0;
    reg                     flush = 0;
    reg         [7 : 0]     pages = 8'he4;
    reg                     req_valid = 0;
    wire                    req_ready;
    reg         [107 : 0]   uv = 0;
    reg         [2 : 0]     mask = 0;
    wire                    rsp_valid;
    reg                     rsp_ready = 0;
    wire        [287 : 0]   pixels;
    wire                    arvalid;
    wire                    arready;
    wire        [27 : 0]    araddr;
    wire                    rvalid;
    wire                    rlast;
    reg         [255 : 0]   rdata;
    wire        [31 : 0]    bursts;
    wire        [31 : 0]    errors;
    reg                     pending = 0;
    reg         [27 : 0]    address = 0;
    integer                 beat = 0;
    integer                 cycle = 0;
    integer                 generation = 0;
    integer                 cases = 0;
    reg                     malformed = 0;
    reg                     test_passed = 0;
    reg         [287 : 0]   expected;
    reg         [287 : 0]   held;
    integer                 test_x[0 : 9];
    integer                 test_y[0 : 9];

    always #2.5 clk = ~clk;
    assign arready = !pending && cycle % 7 != 0;
    assign rvalid = pending && cycle % 3 != 0;
    assign rlast = rvalid && (malformed ? beat == 2 : beat == 7);

    function [15 : 0] source565;
        input integer absolute_pixel;
        begin
            source565 = (absolute_pixel * 37) ^ (absolute_pixel >> 4) ^ (generation * 16'h95a7);
        end
    endfunction

    function integer physical_channel;
        input integer camera;
        begin
            case(camera)
                0: physical_channel = 2;
                1: physical_channel = 0;
                default: physical_channel = 1;
            endcase
        end
    endfunction

    always@(*)begin
        for(integer lane = 0; lane < 16; lane = lane + 1)begin
            rdata[lane * 16 +: 16] = source565(address * 2 + beat * 16 + lane);
        end
    end

    fusion_ddr_sampler#(
        .LEFT_CHANNEL   (2),
        .CENTER_CHANNEL (0),
        .RIGHT_CHANNEL  (1)
    )dut(
        .clk             (clk),
        .rst_n           (rst_n),
        .flush           (flush),
        .frame_pages     (pages),
        .req_valid       (req_valid),
        .req_ready       (req_ready),
        .req_uv          (uv),
        .req_mask        (mask),
        .rsp_valid       (rsp_valid),
        .rsp_ready       (rsp_ready),
        .rsp_pixels      (pixels),
        .arvalid         (arvalid),
        .arready         (arready),
        .araddr          (araddr),
        .rvalid          (rvalid),
        .rlast           (rlast),
        .rdata           (rdata),
        .burst_count     (bursts),
        .protocol_errors (errors)
    );

    always@(posedge clk)begin
        if(rst_n)begin
            cycle = cycle + 1;
            if(arvalid && arready)begin
                if(araddr[5 : 0] != 0) $fatal(1, "Unaligned source burst");
                pending <= 1;
                address <= araddr;
                beat <= 0;
            end
            if(rvalid)begin
                if(rlast) pending <= 0;
                else beat <= beat + 1;
            end
            if(cycle > 300000) $fatal(1, "Sampler boundary timeout");
        end
    end

    task automatic run_case(input integer index, input integer valid_mask);
        integer x;
        integer y;
        integer ch;
        integer absolute_pixel;
        reg [15 : 0] p;
        begin
            @(negedge clk);
            expected = 0;
            mask = valid_mask;
            for(integer camera = 0; camera < 3; camera = camera + 1)begin
                x = test_x[(index + camera * 3) % 10];
                y = test_y[(index + camera * 3) % 10];
                uv[camera * 36 +: 18] = (x << 8) | 8'h83;
                uv[camera * 36 + 18 +: 18] = (y << 8) | 8'h51;
                ch = physical_channel(camera);
                for(integer corner = 0; corner < 4; corner = corner + 1)begin
                    absolute_pixel = ((ch << 22) | (pages[ch * 2 +: 2] << 20)) * 2;
                    absolute_pixel = absolute_pixel +
                        ((corner >= 2 && y < 539) ? y + 1 : y) * 960 +
                        ((corner % 2 != 0 && x < 959) ? x + 1 : x);
                    p = source565(absolute_pixel);
                    if(valid_mask & (1 << camera))begin
                        expected[camera * 96 + corner * 24 +: 24] =
                            {p[15 : 11], 3'd0, p[10 : 5], 2'd0, p[4 : 0], 3'd0};
                    end
                end
            end
            req_valid = 1;
            do @(posedge clk); while(!req_ready);
            @(negedge clk);
            req_valid = 0;
            wait(rsp_valid);
            @(negedge clk);
            held = pixels;
            repeat(4)begin
                @(negedge clk);
                if(!rsp_valid || pixels !== held || pixels !== expected)
                    $fatal(1, "Sampler boundary data mismatch case=%0d mask=%0d", index, valid_mask);
            end
            rsp_ready = 1;
            @(negedge clk);
            rsp_ready = 0;
            cases = cases + 1;
        end
    endtask

    initial begin
        test_x[0]=0; test_y[0]=0;
        test_x[1]=15; test_y[1]=1;
        test_x[2]=16; test_y[2]=2;
        test_x[3]=63; test_y[3]=3;
        test_x[4]=127; test_y[4]=4;
        test_x[5]=128; test_y[5]=5;
        test_x[6]=255; test_y[6]=538;
        test_x[7]=895; test_y[7]=539;
        test_x[8]=958; test_y[8]=538;
        test_x[9]=959; test_y[9]=539;
        #0.1 rst_n = 1;
        #0.1 rst_n = 0;
        repeat(4) @(negedge clk);
        rst_n = 1;
        for(integer epoch = 0; epoch < 3; epoch = epoch + 1)begin
            generation = epoch;
            pages = epoch == 2 ? 8'h1b : 8'he4;
            flush = 1;
            @(negedge clk);
            flush = 0;
            for(integer index = 0; index < 10; index = index + 1)begin
                for(integer valid_mask = 0; valid_mask < 8; valid_mask = valid_mask + 1)begin
                    run_case(index, valid_mask);
                end
            end
        end
        if(errors != 0) $fatal(1, "Unexpected sampler protocol error");
        flush = 1;
        @(negedge clk);
        flush = 0;
        malformed = 1;
        mask = 1;
        req_valid = 1;
        do @(posedge clk); while(!req_ready);
        @(negedge clk);
        req_valid = 0;
        wait(errors == 1);
        repeat(20) @(negedge clk);
        if(req_ready || rsp_valid || arvalid || errors != 1)
            $fatal(1, "Malformed burst did not stop the sampler");
        test_passed = 1;
        $display("PASS sampler boundary: cases=%0d bursts=%0d malformed_detected=%0d", cases, bursts, errors);
        $finish;
    end
endmodule
