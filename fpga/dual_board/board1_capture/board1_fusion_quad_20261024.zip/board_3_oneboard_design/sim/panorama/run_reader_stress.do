onerror {quit -code 1 -force}
onbreak {resume}
if {![file isdirectory sim/panorama/work_read_stress]} {vlib sim/panorama/work_read_stress}
vmap -modelsimini sim/panorama/modelsim.ini work_read_stress sim/panorama/work_read_stress
vlog -modelsimini sim/panorama/modelsim.ini -sv -work work_read_stress -timescale 1ns/1ps source/fusion/fusion_async_fifo.v source/fusion/fusion_frame_reader.v source/fusion/fusion_ddr_read_arbiter.v source/sync_generator.v sim/panorama/reader_stress_tb.sv
vsim -modelsimini sim/panorama/modelsim.ini -voptargs=+acc -onfinish stop work_read_stress.reader_stress_tb
run -all
if {[examine -radix unsigned sim:/reader_stress_tb/test_passed] != 1} {error "Display reader stress test failed"}
puts "PASS: 100MHz DDR / 150MHz pixel, delayed reads, concurrent fusion, three checked frames"
