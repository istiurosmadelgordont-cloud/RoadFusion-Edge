`timescale 1ns/1ps
module page_lock_tb;
    reg                     clk = 0;
    reg                     rst_n = 0;
    reg                     lock_valid = 0;
    reg         [1 : 0]     lock_page = 0;
    wire                    grant;
    wire                    complete_valid;
    wire        [1 : 0]     complete_page;
    wire        [27 : 0]    awaddr;
    wire                    awvalid;
    wire                    awready;
    wire                    wready;
    wire                    wlast;
    reg                     pending = 0;
    reg         [27 : 0]    pending_address;
    reg         [2 : 0]     beat = 0;
    reg         [31 : 0]    random_bits = 32'h913ac72d;
    integer                 commits = 0;
    integer                 frames = 0;
    integer                 cycles = 0;
    reg         [1 : 0]     last_committed_page = 0;
    reg                     had_commit = 0;
    reg                     grant_seen = 0;
    reg                     test_passed = 0;

    always #5 clk = ~clk;
    assign awready = !pending && random_bits[2 : 0] != 0;
    assign wready = pending && random_bits[1 : 0] != 0;
    assign wlast  = wready && beat == 7;

    AXI_FULL_M#(
        .READ_ENABLE            (0),
        .VIDEO_LENGTH           (16),
        .VIDEO_HIGTH            (16),
        .PIXEL_WIDTH            (16),
        .VIDEO_BASE_ADDR        (0)
    )dut(
        .lock_valid             (lock_valid),
        .lock_page              (lock_page),
        .lock_granted           (grant),
        .completed_valid        (complete_valid),
        .completed_page         (complete_page),
        .DDR_INIT_DONE          (1'b1),
        .M_AXI_ACLK             (clk),
        .M_AXI_ARESETN          (rst_n),
        .M_AXI_AWADDR           (awaddr),
        .M_AXI_AWVALID          (awvalid),
        .M_AXI_AWREADY          (awready),
        .M_AXI_WLAST            (wlast),
        .M_AXI_WREADY           (wready),
        .M_AXI_ARADDR           (),
        .M_AXI_ARVALID          (),
        .M_AXI_ARREADY          (1'b0),
        .M_AXI_RLAST            (1'b0),
        .M_AXI_RVALID           (1'b0),
        .vs_in                  (1'b0),
        .vs_out                 (1'b0),
        .wfifo_rd_water_level   (9'd32),
        .wfifo_rd_req           (),
        .wfifo_pre_rd_req       (),
        .rfifo_wr_water_level   (9'd0),
        .rfifo_wr_req           (),
        .r_fram_done            (),
        .wr_addr_min            (20'd0),
        .wr_addr_max            (20'd128),
        .r_wr_rst               (),
        .r_rd_rst               (),
        .w_fifo_state           (),
        .r_fifo_state           (),
        .wr_addr_cnt            ()
    );

    always@(posedge clk)begin
        if(rst_n)begin
            cycles = cycles + 1;
            random_bits <= {random_bits[30 : 0], random_bits[31] ^ random_bits[21] ^ random_bits[1] ^ random_bits[0]};
            if(awvalid && awready)begin
                if(grant_seen && lock_valid && awaddr[21 : 20] == lock_page)
                    $fatal(1, "Writer re-entered locked source page");
                pending <= 1;
                pending_address <= awaddr;
                beat <= 0;
            end
            if(wready)begin
                if(wlast)begin
                    pending <= 0;
                    commits = commits + 1;
                    if(pending_address[19 : 0] == 64)begin
                        frames = frames + 1;
                        last_committed_page = pending_address[21 : 20];
                        had_commit = 1;
                    end
                end
                else begin
                    beat <= beat + 1'b1;
                end
            end
            #1;
            if(complete_valid && (!had_commit || complete_page != last_committed_page))
                $fatal(1, "Source page published before final WDATA commit");
            if(grant)begin
                if(pending && pending_address[21 : 20] == lock_page)
                    $fatal(1, "Lock granted while source page write is in flight");
                grant_seen = 1;
            end
            if(cycles > 5000) $fatal(1, "Source lock timeout");
        end
    end

    initial begin
        #1 rst_n = 1;
        #1 rst_n = 0;
        repeat(5) @(negedge clk);
        rst_n = 1;
        wait(complete_valid);
        @(negedge clk); lock_page = complete_page; lock_valid = 1;
        wait(grant);
        wait(frames >= 12);
        @(negedge clk); lock_valid = 0; grant_seen = 0;
        wait(awvalid && awready && awaddr[21 : 20] == 2);
        @(negedge clk); lock_page = 2; lock_valid = 1;
        if(grant) $fatal(1, "Active source page lock granted too early");
        wait(grant);
        wait(frames >= 24);
        test_passed = 1;
        $display("PASS source page ownership: frames=%0d bursts=%0d", frames, commits);
        $finish;
    end
endmodule
