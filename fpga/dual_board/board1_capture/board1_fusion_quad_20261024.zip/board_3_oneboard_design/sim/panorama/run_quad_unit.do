catch {quit -sim}
if {![file isdirectory sim/panorama/work_units]} {vlib sim/panorama/work_units}
vmap -modelsimini sim/panorama/modelsim.ini work_units sim/panorama/work_units
vlog -modelsimini sim/panorama/modelsim.ini -sv -work work_units -timescale 1ns/1ps source/fusion/quad_frame_renderer.v sim/panorama/quad_renderer_tb.sv
vsim -modelsimini sim/panorama/modelsim.ini -voptargs=+acc -onfinish stop work_units.quad_renderer_tb
run -all
if {[examine -radix unsigned sim:/quad_renderer_tb/test_passed] != 1} {error "Unit test failed"}

