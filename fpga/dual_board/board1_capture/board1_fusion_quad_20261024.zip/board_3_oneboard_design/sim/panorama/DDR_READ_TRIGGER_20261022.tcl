# Run in Fabric Debugger Tcl Console after loading the matching bit and FIC.
# Prepare trigger only; acquisition starts when the user clicks Run.
dbg_set_cur_core -device 0 -core 1
dbg_stop
dbg_set_unit -unit 0 -func "==" -value XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX11XXXXXXXXXXX -radix 0
dbg_set_unit -unit 1 -func "==" -value 0000000XX -radix 0
dbg_set_unit -unit 2 -func "<>" -value 000000000XXXXXX -radix 0
dbg_set_condition -select 0 -set "TU0&&TU1&&TU2"
dbg_set_condition -active 0
dbg_set_capture -type 0 -windows 1 -position 1536
dbg_add_all_to_waveform
puts {CORE1 DDR low-watermark trigger prepared. Click Run to capture.}
