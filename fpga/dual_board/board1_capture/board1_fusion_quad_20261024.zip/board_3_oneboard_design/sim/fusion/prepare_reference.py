from pathlib import Path
import numpy as np
from PIL import Image

P=Path(__file__).resolve().parents[2]
REF=P/'sim/fusion/reference'
REF.mkdir(exist_ok=True)
xx,yy=np.meshgrid(np.arange(1920),np.arange(540))
fx=xx%16;fy=yy%16;gx=xx//16;gy=yy//16
wl=np.where(xx<576,256,np.where(xx<704,256-2*(xx-576),0))
wr=np.where(xx<1216,0,np.where(xx<1344,2*(xx-1216),256))
weights=[wl,256-wl-wr,wr]
frames=[]
total=np.zeros((540,1920,3),dtype=np.int64)
for camera,role in enumerate(['left','center','right','fourth']):
    path=P/'sim/fusion/input'/f'{role}.bmp'
    image=Image.open(path).convert('RGB')
    assert image.size==(960,540),f'{path}: expected 960x540'
    rgb=np.asarray(image).astype(np.int64)
    rgb=rgb//np.array([8,4,8])*np.array([8,4,8])
    frames.append(rgb.astype(np.uint8))
    packed=(rgb[...,0]<<16)|(rgb[...,1]<<8)|rgb[...,2]
    (REF/f'{role}_rgb.hex').write_text(''.join(f'{int(n):06x}\n' for n in packed.flat))
    if camera==3:continue
    banks=[np.array([int(v,16) for v in (P/'fusion_maps/grid16_bram'/f'{role}_b{b}.hex').read_text().splitlines()],dtype=np.uint64)
           for b in range(4)]
    nodes=[]
    for dx,dy in [(0,0),(1,0),(0,1),(1,1)]:
        nx=gx+dx;ny=gy+dy
        parity=(ny%2)*2+nx%2
        address=(ny//2)*61+nx//2
        node=np.zeros(xx.shape,dtype=np.uint64)
        for b in range(4):node[parity==b]=banks[b][address[parity==b]]
        nodes.append(node)
    coords=[]
    valid=np.ones(xx.shape,dtype=bool)
    for shift,limit in [(0,959*256),(18,539*256)]:
        q=[((n>>np.uint64(shift))&np.uint64((1<<18)-1)).astype(np.int64) for n in nodes]
        valid&=np.logical_and.reduce([v<=limit for v in q])
        coord=(q[0]*(16-fx)*(16-fy)+q[1]*fx*(16-fy)+q[2]*(16-fx)*fy+q[3]*fx*fy+128)>>8
        valid&=coord<=limit
        coords.append(np.where(weights[camera]>0,coord,0))
    assert np.all(valid | (weights[camera]==0)),f'{role}: fixed seams use invalid grid points'
    u,v=coords
    ix=u>>8;iy=v>>8;ix1=np.minimum(ix+1,959);iy1=np.minimum(iy+1,539)
    ax=(u&255)[...,None];ay=(v&255)[...,None]
    sample=(rgb[iy,ix]*(256-ax)*(256-ay)+rgb[iy,ix1]*ax*(256-ay)+
            rgb[iy1,ix]*(256-ax)*ay+rgb[iy1,ix1]*ax*ay+32768)>>16
    total+=sample*weights[camera][...,None]
fusion=((total+128)>>8).astype(np.uint8)
packed=(fusion[...,0].astype(np.uint32)<<16)|(fusion[...,1].astype(np.uint32)<<8)|fusion[...,2].astype(np.uint32)
(REF/'fusion_rgb.hex').write_text(''.join(f'{int(n):06x}\n' for n in packed.flat))
Image.fromarray(fusion).save(REF/'fusion_565.bmp')
quad=np.concatenate([np.concatenate(frames[:2],axis=1),np.concatenate(frames[2:],axis=1)],axis=0)
Image.fromarray(quad).save(REF/'quad.bmp')
canvas=np.zeros((1080,1920,3),dtype=np.uint8);canvas[:540]=fusion
Image.fromarray(canvas).save(REF/'fusion_canvas.bmp')
print('Prepared RGB565/grid integer references from local BMPs and BRAM files.')
