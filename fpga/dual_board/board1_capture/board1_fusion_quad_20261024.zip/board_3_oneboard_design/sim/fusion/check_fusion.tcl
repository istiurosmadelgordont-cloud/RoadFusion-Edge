set_arch -family Logos -device PGL50H -speedgrade -6 -package FBG484
foreach name {grid_node_rom grid_coordinate_interp rgb_bilinear_q8 fixed_seam_weights rgb_feather_blend grid_fusion_top fusion_ddr_sampler fusion_ddr_read_arbiter fusion_ddr_pipeline fusion_video_window} {
    add_design source/fusion/${name}.v
}
compile -top_module fusion_ddr_pipeline
synthesize -ads -selected_syn_tool_opt 2
