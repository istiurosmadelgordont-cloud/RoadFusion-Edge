`timescale 1ns/1ps
module fusion_board_tb;

    reg                     clk = 0;
    reg                     rst_n = 0;
    reg                     start = 0;
    reg         [3 : 0]     load_enable = 0;
    wire        [3 : 0]     load_valid;
    wire        [95 : 0]    load_rgb;
    wire                    loaded;
    reg         [7 : 0]     pages = 8'he4;
    wire                    busy;
    wire                    done;
    wire                    out_valid;
    reg                     out_ready = 0;
    wire        [23 : 0]    out_rgb;
    wire        [10 : 0]    out_x;
    wire        [9 : 0]     out_y;
    wire                    out_sof;
    wire                    out_eol;
    wire                    out_eof;
    wire                    arvalid;
    wire                    arready;
    wire        [27 : 0]    araddr;
    wire                    rvalid;
    wire                    rlast;
    wire        [255 : 0]   rdata;
    wire        [31 : 0]    bursts;
    wire        [31 : 0]    protocol_errors;
    wire        [31 : 0]    coverage_errors;
    wire        [31 : 0]    fallback_count;
    wire        [31 : 0]    ddr_requests;
    reg                     legacy_arvalid = 0;
    wire                    legacy_arready;
    reg         [27 : 0]    legacy_araddr = 0;
    wire                    legacy_rvalid;
    wire                    legacy_rlast;
    wire        [255 : 0]   legacy_rdata;
    reg         [27 : 0]    legacy_saved_address;
    reg                     legacy_pending = 0;
    integer                 legacy_beat = 0;
    integer                 legacy_bursts = 0;
    reg                     background_enable = 0;
    reg         [23 : 0]    expected[0 : 1036799];
    reg         [23 : 0]    source_ref[0 : 2073599];
    reg         [23 : 0]    rendered[0 : 1036799];
    reg         [31 : 0]    lfsr = 32'h2ac83f91;
    integer                 cycles = 0;
    integer                 pixels = 0;
    integer                 stalls = 0;
    integer                 owner;
    integer                 next_offset;
    reg                     render_complete = 0;
    reg                     render_write_valid = 0;
    reg         [23 : 0]    render_write_rgb;
    reg                     output_stalled = 0;
    reg         [47 : 0]    held_pixel;
    reg                     address_stalled = 0;
    reg         [27 : 0]    held_address;

    reg                     display_enable = 0;
    reg                     mode_toggle = 0;
    wire                    vs;
    wire                    hs;
    wire                    de;
    wire        [11 : 0]    x;
    wire        [11 : 0]    y;
    wire                    read_enable;
    wire                    read_panorama;
    wire        [1 : 0]     read_channel;
    wire        [20 : 0]    read_index;
    reg         [23 : 0]    read_rgb;
    wire                    mode_active;
    wire                    hdmi_vs;
    wire                    hdmi_hs;
    wire                    hdmi_de;
    wire        [23 : 0]    hdmi_rgb;
    wire                    sfp_vs;
    wire                    sfp_de;
    wire        [15 : 0]    sfp_rgb565;
    reg                     expected_de_s0;
    reg                     expected_de_s1;
    reg                     expected_vs_s0;
    reg                     expected_vs_s1;
    reg                     expected_hs_s0;
    reg                     expected_hs_s1;
    reg         [23 : 0]    expected_display_s0;
    reg         [23 : 0]    expected_display_s1;
    reg                     display_started = 0;
    reg                     previous_output_vs = 0;
    reg                     display_mode;
    integer                 display_frame = -1;
    integer                 display_pixel = 0;
    integer                 display_frame_pixels = 0;
    integer                 display_total = 0;
    reg                     quad_write_valid = 0;
    reg                     canvas_write_valid = 0;
    reg         [23 : 0]    display_write_rgb;
    reg                     test_passed = 0;

    always #5 clk = ~clk;

    bmp_rgb_pack#(
        .INPUT_ARG              ("LEFT"),
        .PIC_PATH               ("sim/fusion/input/left.bmp")
    )u_load0(
        .clk                    (clk),
        .rst_n                  (rst_n),
        .enable                 (load_enable[0]),
        .valid                  (load_valid[0]),
        .rgb                    (load_rgb[0 +: 24])
    );

    bmp_rgb_pack#(
        .INPUT_ARG              ("CENTER"),
        .PIC_PATH               ("sim/fusion/input/center.bmp")
    )u_load1(
        .clk                    (clk),
        .rst_n                  (rst_n),
        .enable                 (load_enable[1]),
        .valid                  (load_valid[1]),
        .rgb                    (load_rgb[24 +: 24])
    );

    bmp_rgb_pack#(
        .INPUT_ARG              ("RIGHT"),
        .PIC_PATH               ("sim/fusion/input/right.bmp")
    )u_load2(
        .clk                    (clk),
        .rst_n                  (rst_n),
        .enable                 (load_enable[2]),
        .valid                  (load_valid[2]),
        .rgb                    (load_rgb[48 +: 24])
    );

    bmp_rgb_pack#(
        .INPUT_ARG              ("FOURTH"),
        .PIC_PATH               ("sim/fusion/input/fourth.bmp")
    )u_load3(
        .clk                    (clk),
        .rst_n                  (rst_n),
        .enable                 (load_enable[3]),
        .valid                  (load_valid[3]),
        .rgb                    (load_rgb[72 +: 24])
    );

    fusion_ddr_pipeline dut(
        .clk                    (clk),
        .rst_n                  (rst_n),
        .start                  (start),
        .frame_pages            (pages),
        .busy                   (busy),
        .done                   (done),
        .out_ready              (out_ready),
        .out_valid              (out_valid),
        .out_rgb                (out_rgb),
        .out_x                  (out_x),
        .out_y                  (out_y),
        .out_sof                (out_sof),
        .out_eol                (out_eol),
        .out_eof                (out_eof),
        .legacy_urgent          (1'b0),
        .legacy_arvalid         (legacy_arvalid),
        .legacy_arready         (legacy_arready),
        .legacy_araddr          (legacy_araddr),
        .legacy_rvalid          (legacy_rvalid),
        .legacy_rlast           (legacy_rlast),
        .legacy_rdata           (legacy_rdata),
        .arvalid                (arvalid),
        .arready                (arready),
        .araddr                 (araddr),
        .rvalid                 (rvalid),
        .rlast                  (rlast),
        .rdata                  (rdata),
        .burst_count            (bursts),
        .protocol_errors        (protocol_errors),
        .coverage_errors        (coverage_errors),
        .fallback_count         (fallback_count)
    );

    fusion_ddr_model u_ddr(
        .clk                    (clk),
        .rst_n                  (rst_n),
        .load_valid             (load_valid),
        .load_rgb               (load_rgb),
        .loaded                 (loaded),
        .arvalid                (arvalid),
        .arready                (arready),
        .araddr                 (araddr),
        .rvalid                 (rvalid),
        .rlast                  (rlast),
        .rdata                  (rdata),
        .requests               (ddr_requests)
    );

    sync_generator u_sync(
        .clk                    (clk),
        .rstn                   (rst_n && display_enable),
        .vs_out                 (vs),
        .hs_out                 (hs),
        .de_out                 (de),
        .de_re                  (),
        .x_act                  (x),
        .y_act                  (y)
    );

    fusion_video_window u_window(
        .clk                    (clk),
        .rst_n                  (rst_n && display_enable),
        .mode_toggle            (mode_toggle),
        .panorama_ready         (render_complete),
        .vs                     (vs),
        .hs                     (hs),
        .de                     (de),
        .pixel_x                (x),
        .pixel_y                (y),
        .read_enable            (read_enable),
        .read_panorama          (read_panorama),
        .read_channel           (read_channel),
        .read_index             (read_index),
        .read_rgb               (read_rgb),
        .mode_active            (mode_active),
        .hdmi_vs                (hdmi_vs),
        .hdmi_hs                (hdmi_hs),
        .hdmi_de                (hdmi_de),
        .hdmi_rgb               (hdmi_rgb),
        .sfp_vs                 (sfp_vs),
        .sfp_de                 (sfp_de),
        .sfp_rgb565             (sfp_rgb565)
    );

    panorama_bmp_writer#(
        .OUTPUT_ARG ("FUSION_OUTPUT"),
        .PIC_PATH ("sim/fusion/results/fusion_1920x540.bmp")
    )u_fusion_writer(
        .clk(clk),
        .valid(render_write_valid),
        .rgb(render_write_rgb)
    );

    panorama_bmp_writer#(
        .HEIGHT (1080),
        .OUTPUT_ARG ("QUAD_OUTPUT"),
        .PIC_PATH ("sim/fusion/results/quad_hdmi.bmp")
    )u_quad_writer(
        .clk(clk),
        .valid(quad_write_valid),
        .rgb(display_write_rgb)
    );

    panorama_bmp_writer#(
        .HEIGHT (1080),
        .OUTPUT_ARG ("CANVAS_OUTPUT"),
        .PIC_PATH ("sim/fusion/results/fusion_upper_hdmi.bmp")
    )u_canvas_writer(
        .clk(clk),
        .valid(canvas_write_valid),
        .rgb(display_write_rgb)
    );

    initial begin
        $readmemh("sim/fusion/reference/fusion_rgb.hex", expected);
        $readmemh("sim/fusion/reference/left_rgb.hex", source_ref, 0, 518399);
        $readmemh("sim/fusion/reference/center_rgb.hex", source_ref, 518400, 1036799);
        $readmemh("sim/fusion/reference/right_rgb.hex", source_ref, 1036800, 1555199);
        $readmemh("sim/fusion/reference/fourth_rgb.hex", source_ref, 1555200, 2073599);
        #1 rst_n = 1;
        #1 rst_n = 0;
        repeat(10) @(negedge clk);
        rst_n = 1;
        for(integer c = 0; c < 4; c = c + 1)begin
            load_enable[c] = 1;
            repeat(11) @(negedge clk);
        end
        wait(loaded);
        @(negedge clk);
        background_enable = 1;
        start = 1;
        @(negedge clk);
        start = 0;
        // Deliberately alter live page inputs; the in-flight render must use its snapshot.
        repeat(500) @(negedge clk);
        pages = 8'h1b;
        // A second start during busy must not overwrite the active pages.
        start = 1;
        @(negedge clk);
        start = 0;
        wait(render_complete);
        @(negedge clk);
        background_enable = 0;
        wait(!legacy_pending && !legacy_arvalid);
        display_enable = 1;
        wait(display_frame == 0 && display_frame_pixels > 20000);
        @(negedge clk); mode_toggle = 1;
        @(negedge clk); mode_toggle = 0;
        wait(display_frame == 1 && display_frame_pixels > 20000);
        @(negedge clk); mode_toggle = 1;
        @(negedge clk); mode_toggle = 0;
        wait(display_frame == 3);
        if(display_total != 3 * 2073600 || !u_fusion_writer.image_saved ||
           !u_quad_writer.image_saved || !u_canvas_writer.image_saved)
            $fatal(1, "Display count/images incomplete");
        if(protocol_errors != 0 || coverage_errors != 0 || fallback_count != 0 || legacy_bursts < 100)
            $fatal(1, "DDR arbitration or mapping errors");
        test_passed = 1;
        $display("PASS board integration: RGB565 fusion pixels=%0d bursts=%0d legacy_bursts=%0d display_pixels=%0d cycles=%0d stalls=%0d",
                 pixels, bursts, legacy_bursts, display_total, cycles, stalls);
        $finish;
    end

    // The competing reader models independent background bursts, not a DDR PHY.
    always@(negedge clk)begin
        if(rst_n)begin
            lfsr <= {lfsr[30 : 0], lfsr[31] ^ lfsr[21] ^ lfsr[1] ^ lfsr[0]};
            out_ready <= lfsr[2 : 0] != 0;
            if(background_enable && !legacy_pending && !legacy_arvalid && lfsr[6 : 0] == 0)begin
                owner = legacy_bursts % 4;
                next_offset = (legacy_bursts * 64) % 259200;
                next_offset = (next_offset / 64) * 64;
                legacy_araddr <= (owner << 22) | (owner << 20) | next_offset;
                legacy_arvalid <= 1;
            end
        end
    end

    always@(posedge clk)begin
        if(rst_n)begin
            cycles = cycles + 1;
            render_write_valid <= 0;
            if(address_stalled && (!arvalid || araddr !== held_address))
                $fatal(1, "AXI address changed while stalled");
            address_stalled = arvalid && !arready;
            held_address = araddr;
            if(output_stalled && (!out_valid || {out_rgb, out_x, out_y, out_sof, out_eol, out_eof} !== held_pixel))
                $fatal(1, "Fusion output changed while stalled");
            output_stalled = out_valid && !out_ready;
            held_pixel = {out_rgb, out_x, out_y, out_sof, out_eol, out_eof};
            if(output_stalled) stalls = stalls + 1;
            if(legacy_arvalid && legacy_arready)begin
                legacy_arvalid <= 0;
                legacy_pending = 1;
                legacy_beat = 0;
                legacy_saved_address = legacy_araddr;
            end
            if(legacy_rvalid)begin
                if(!legacy_pending || legacy_rdata !== u_ddr.get_beat(legacy_saved_address + legacy_beat * 8) ||
                   legacy_rlast != (legacy_beat == 7))
                    $fatal(1, "DDR response routed to wrong owner/beat");
                if(legacy_rlast)begin
                    legacy_pending = 0;
                    legacy_bursts = legacy_bursts + 1;
                end
                else legacy_beat = legacy_beat + 1;
            end
            if(dut.u_read_arbiter.legacy_rvalid && dut.u_read_arbiter.fusion_rvalid)
                $fatal(1, "One DDR response reached two readers");
            if(out_valid && out_ready)begin
                if(out_rgb !== expected[pixels] || out_x != pixels % 1920 || out_y != pixels / 1920)
                    $fatal(1, "Fusion mismatch pixel=%0d rgb=%h expected=%h xy=%0d,%0d",
                           pixels, out_rgb, expected[pixels], out_x, out_y);
                if(out_sof != (pixels == 0) || out_eol != (pixels % 1920 == 1919) ||
                   out_eof != (pixels == 1036799))
                    $fatal(1, "Fusion raster flag mismatch");
                rendered[pixels] <= out_rgb;
                render_write_valid <= 1;
                render_write_rgb <= out_rgb;
                pixels = pixels + 1;
            end
            if(done)begin
                if(pixels != 1036800)
                    $fatal(1, "Incomplete panorama");
                render_complete = 1;
                $display("RENDER_PASS pixels=%0d cycles=%0d bursts=%0d legacy=%0d", pixels, cycles, bursts, legacy_bursts);
            end
            if(cycles % 5000000 == 0)
                $display("PROGRESS cycle=%0d render_pixels=%0d sampler_state=%0d display_frame=%0d", cycles, pixels, dut.u_sampler.state, display_frame);
            if(cycles > 100000000)
                $fatal(1, "Integration timeout");
        end
    end

    // Synchronous external frame-store read model. No frame arrays are in the RTL window.
    always@(posedge clk)begin
        if(display_enable)begin
            read_rgb <= 0;
            if(read_enable)begin
                if(read_panorama)begin
                    if(read_index >= 1036800) $fatal(1, "Read past panorama end");
                    read_rgb <= rendered[read_index];
                end
                else begin
                    if(read_index >= 518400) $fatal(1, "Read past quadrant end");
                    read_rgb <= source_ref[read_channel * 518400 + read_index];
                end
            end
        end
    end

    // Independent raster reference, delayed by the specified two registers.
    always@(posedge clk)begin
        if(!display_enable)begin
            expected_de_s0 <= 0;
            expected_de_s1 <= 0;
            expected_vs_s0 <= 0;
            expected_vs_s1 <= 0;
            expected_hs_s0 <= 0;
            expected_hs_s1 <= 0;
            expected_display_s0 <= 0;
            expected_display_s1 <= 0;
        end
        else begin
            expected_de_s0 <= de;
            expected_de_s1 <= expected_de_s0;
            expected_vs_s0 <= vs;
            expected_vs_s1 <= expected_vs_s0;
            expected_hs_s0 <= hs;
            expected_hs_s1 <= expected_hs_s0;
            expected_display_s0 <= 0;
            if(de)begin
                if(mode_active)begin
                    if(y < 540)
                        expected_display_s0 <= expected[y * 1920 + x];
                end
                else begin
                    expected_display_s0 <= source_ref[((y >= 540 ? 2 : 0) + (x >= 960 ? 1 : 0)) * 518400 +
                                                     (y >= 540 ? y - 540 : y) * 960 + (x >= 960 ? x - 960 : x)];
                end
            end
            expected_display_s1 <= expected_display_s0;
        end
    end

    always@(posedge clk)begin
        #2;
        quad_write_valid <= 0;
        canvas_write_valid <= 0;
        if(display_enable)begin
            if(hdmi_de !== expected_de_s1 || hdmi_vs !== expected_vs_s1 || hdmi_hs !== expected_hs_s1)
                $fatal(1, "Display sync latency mismatch");
            if(hdmi_rgb !== expected_display_s1)
                $fatal(1, "Display RGB mismatch frame=%0d pixel=%0d got=%h expected=%h",
                       display_frame, display_frame_pixels, hdmi_rgb, expected_display_s1);
            if(sfp_vs !== hdmi_vs || sfp_de !== hdmi_de ||
               sfp_rgb565 !== {hdmi_rgb[23 : 19], hdmi_rgb[15 : 10], hdmi_rgb[7 : 3]})
                $fatal(1, "HDMI/SFP parallel video mismatch");
            if(hdmi_vs && !previous_output_vs)begin
                if(display_started && display_frame_pixels != 2073600)
                    $fatal(1, "Wrong active pixel count frame=%0d count=%0d", display_frame, display_frame_pixels);
                display_started = 1;
                display_frame = display_frame + 1;
                display_frame_pixels = 0;
                display_mode = mode_active;
                if(mode_active != (display_frame == 1))
                    $fatal(1, "Mode did not switch on frame boundary frame=%0d", display_frame);
            end
            previous_output_vs = hdmi_vs;
            if(display_started && hdmi_de)begin
                if(mode_active != display_mode)
                    $fatal(1, "Mode changed inside active frame");
                if(display_frame == 0) quad_write_valid <= 1;
                if(display_frame == 1) canvas_write_valid <= 1;
                display_write_rgb <= hdmi_rgb;
                display_frame_pixels = display_frame_pixels + 1;
                display_total = display_total + 1;
            end
        end
    end

endmodule
