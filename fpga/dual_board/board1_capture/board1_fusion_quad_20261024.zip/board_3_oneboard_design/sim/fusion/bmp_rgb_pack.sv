`timescale 1ns/1ps

module bmp_rgb_pack#(
    parameter   INPUT_ARG                    =   "LEFT",
    parameter   PIC_PATH                     =   "../res/three_demo/left.bmp"
)(
    input                   clk,
    input                   rst_n,
    input                   enable,
    output reg              valid                =   0,
    output reg  [23 : 0]    rgb                  =   0
);

    wire                    byte_valid;
    wire        [7 : 0]     byte_data;
    reg         [15 : 0]    partial_rgb;
    reg         [1 : 0]     component;

    bmp_image_source#(
        .N                  (540                    ),
        .M                  (960                    ),
        .INPUT_ARG          (INPUT_ARG              ),
        .PIC_PATH           (PIC_PATH               )
    )u_source(
        .clk                (clk                    ),
        .camera_en          (enable                 ),
        .data_valid         (byte_valid             ),
        .data_out           (byte_data              )
    );

    always@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            component   <= 0;
            partial_rgb <= 0;
            valid       <= 1'b0;
            rgb         <= 0;
        end
        else begin
            valid <= 1'b0;
            if(byte_valid)begin
                if(component == 2)begin
                    rgb       <= {partial_rgb, byte_data};
                    component <= 0;
                    valid     <= 1'b1;
                end
                else begin
                    partial_rgb <= {partial_rgb[7 : 0], byte_data};
                    component   <= component + 1'b1;
                end
            end
        end
    end

endmodule

