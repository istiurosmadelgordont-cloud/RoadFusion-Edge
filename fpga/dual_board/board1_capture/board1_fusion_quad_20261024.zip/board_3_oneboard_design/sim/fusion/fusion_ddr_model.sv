`timescale 1ns/1ps
// Only simulation: BMP-loaded source planes behind the production DDR address convention.
// Other pages intentionally contain inverted data, exposing wrong page selection.
module fusion_ddr_model(
    input                   clk,
    input                   rst_n,
    input       [3 : 0]     load_valid,
    input       [95 : 0]    load_rgb,
    output                  loaded,
    input                   arvalid,
    output                  arready,
    input       [27 : 0]    araddr,
    output reg              rvalid = 0,
    output reg              rlast = 0,
    output reg  [255 : 0]   rdata,
    output reg  [31 : 0]    requests = 0
);

    reg         [15 : 0]    source_pixels[0 : 2073599];
    integer                 count[0 : 3];
    reg         [31 : 0]    lfsr = 32'h18d93fa1;
    reg                     pending = 0;
    reg         [27 : 0]    address;
    integer                 delay_count;
    integer                 beat;
    integer                 c;
    integer                 lane;
    reg         [23 : 0]    rgb;

    assign loaded = count[0] == 518400 && count[1] == 518400 &&
                    count[2] == 518400 && count[3] == 518400;
    assign arready = loaded && !pending && !rvalid && lfsr[2 : 0] != 0;

    function [15 : 0] get_pixel;
        input integer camera;
        input integer page;
        input integer index;
        begin
            if(camera < 0 || camera > 3 || index < 0 || index >= 518400)
                $fatal(1, "DDR read outside frame camera=%0d index=%0d", camera, index);
            get_pixel = source_pixels[camera * 518400 + index];
            if(page != camera)
                get_pixel = get_pixel ^ 16'hffff;
        end
    endfunction

    function [255 : 0] get_beat;
        input [27 : 0] address_word;
        integer j;
        integer camera;
        integer page;
        integer index;
        begin
            camera = address_word[23 : 22];
            page   = address_word[21 : 20];
            index  = address_word[19 : 0] * 2;
            if(address_word[27 : 24] != 0 || address_word[2 : 0] != 0)
                $fatal(1, "Invalid DDR word address %h", address_word);
            for(j = 0; j < 16; j = j + 1)
                get_beat[j * 16 +: 16] = get_pixel(camera, page, index + j);
        end
    endfunction

    initial begin
        for(c = 0; c < 4; c = c + 1)
            count[c] = 0;
    end

    always@(posedge clk)begin
        if(rst_n)begin
            for(c = 0; c < 4; c = c + 1)begin
                if(load_valid[c])begin
                    if(count[c] >= 518400)
                        $fatal(1, "Too many input pixels camera=%0d", c);
                    rgb = load_rgb[c * 24 +: 24];
                    source_pixels[c * 518400 + count[c]] <= {rgb[23 : 19], rgb[15 : 10], rgb[7 : 3]};
                    count[c] <= count[c] + 1;
                end
            end
        end
    end

    always@(posedge clk)begin
        if(rst_n)begin
            lfsr <= {lfsr[30 : 0], lfsr[31] ^ lfsr[21] ^ lfsr[1] ^ lfsr[0]};
            rvalid <= 0;
            rlast  <= 0;
            if(arvalid && arready)begin
                if(araddr[5 : 0] != 0)
                    $fatal(1, "Eight-beat burst is not 64-word aligned: %h", araddr);
                address <= araddr;
                beat <= 0;
                delay_count <= 1 + lfsr[5 : 3];
                pending <= 1;
                requests <= requests + 1;
            end
            if(pending)begin
                if(delay_count > 0)
                    delay_count <= delay_count - 1;
                else if(lfsr[1 : 0] != 0)begin
                    rdata <= get_beat(address + beat * 8);
                    rvalid <= 1;
                    rlast <= beat == 7;
                    if(beat == 7)
                        pending <= 0;
                    else
                        beat <= beat + 1;
                end
            end
        end
    end

endmodule
