`timescale 1ns/1ps

module panorama_bmp_writer#(
    parameter   WIDTH                        =   1920,
    parameter   HEIGHT                       =   540,
    parameter   OUTPUT_ARG                   =   "OUTPUT",
    parameter   PIC_PATH                     =   "../results/three_demo/panorama.bmp"
)(
    input                   clk,
    input                   valid,
    input       [23 : 0]    rgb
);

    localparam  STRIDE                       =   ((WIDTH * 3 + 3) / 4) * 4;
    localparam  FILE_SIZE                    =   54 + STRIDE * HEIGHT;
    reg         [7 : 0]     header[0 : 53];
    reg         [7 : 0]     pixels[0 : STRIDE * HEIGHT - 1];
    reg                     image_saved          =   0;
    integer                 pixel_count          =   0;
    integer                 fd;
    integer                 i;
    integer                 address;
    string                  path;
    string                  argument_format;

    initial begin
        path            = PIC_PATH;
        argument_format = {OUTPUT_ARG, "=%s"};
        if($value$plusargs(argument_format, path))begin end
        for(i = 0; i < 54; i = i + 1)
            header[i] = 0;
        for(i = 0; i < STRIDE * HEIGHT; i = i + 1)
            pixels[i] = 0;
        {header[1], header[0]}                          = 16'h4d42;
        {header[5], header[4], header[3], header[2]}     = FILE_SIZE;
        header[10]                                    = 54;
        header[14]                                    = 40;
        {header[21], header[20], header[19], header[18]} = WIDTH;
        {header[25], header[24], header[23], header[22]} = HEIGHT;
        header[26]                                    = 1;
        header[28]                                    = 24;
        {header[37], header[36], header[35], header[34]} = STRIDE * HEIGHT;
    end

    always@(negedge clk)begin
        if(valid)begin
            if(image_saved || pixel_count >= WIDTH * HEIGHT || (^rgb) === 1'bx)
                $fatal(1, "Invalid/excess panorama pixel %0d", pixel_count);
            address = (HEIGHT - 1 - pixel_count / WIDTH) * STRIDE + (pixel_count % WIDTH) * 3;
            pixels[address    ] = rgb[7 : 0];
            pixels[address + 1] = rgb[15 : 8];
            pixels[address + 2] = rgb[23 : 16];
            pixel_count = pixel_count + 1;
            if(pixel_count == WIDTH * HEIGHT)begin
                fd = $fopen(path, "wb");
                if(!fd)
                    $fatal(1, "Cannot create BMP: %s", path);
                for(i = 0; i < 54; i = i + 1)
                    $fwrite(fd, "%c", header[i]);
                for(i = 0; i < STRIDE * HEIGHT; i = i + 1)
                    $fwrite(fd, "%c", pixels[i]);
                $fclose(fd);
                image_saved = 1'b1;
                $display("SAVED %s (%0dx%0d)", path, WIDTH, HEIGHT);
            end
        end
    end

endmodule
