`timescale 1ns/1ps
module sampler_axi_tb;
    reg                     clk = 0;
    reg                     rst_n = 0;
    reg                     flush = 0;
    reg         [7 : 0]     pages = 8'he4;
    reg                     req_valid = 0;
    wire                    req_ready;
    reg         [107 : 0]   req_uv;
    reg         [2 : 0]     req_mask;
    wire                    rsp_valid;
    reg                     rsp_ready = 0;
    wire        [287 : 0]   rsp_pixels;
    wire                    arvalid;
    wire                    arready;
    wire        [27 : 0]    araddr;
    reg                     rvalid = 0;
    reg                     rlast = 0;
    reg         [255 : 0]   rdata;
    wire        [31 : 0]    burst_count;
    wire        [31 : 0]    errors;
    reg                     pending = 0;
    reg         [27 : 0]    saved_address;
    reg         [31 : 0]    lfsr = 32'h3197cc4a;
    reg                     bad_last = 0;
    integer                 beat = 0;
    integer                 delay_count = 0;
    integer                 cycles = 0;
    integer                 cases = 0;
    reg                     test_passed = 0;

    always #5 clk = ~clk;
    assign arready = !pending && !rvalid && lfsr[2 : 0] != 0;

    fusion_ddr_sampler dut(
        .clk(clk),
        .rst_n(rst_n),
        .flush(flush),
        .frame_pages(pages),
        .req_valid(req_valid),
        .req_ready(req_ready),
        .req_uv(req_uv),
        .req_mask(req_mask),
        .rsp_valid(rsp_valid),
        .rsp_ready(rsp_ready),
        .rsp_pixels(rsp_pixels),
        .arvalid(arvalid),
        .arready(arready),
        .araddr(araddr),
        .rvalid(rvalid),
        .rlast(rlast),
        .rdata(rdata),
        .burst_count(burst_count),
        .protocol_errors(errors)
    );

    function [15 : 0] raw_pixel;
        input integer c;
        input integer page;
        input integer index;
        begin
            raw_pixel = index ^ (c * 16'h1234) ^ (page * 16'h55aa);
        end
    endfunction

    function [23 : 0] expand;
        input [15 : 0] pixel;
        begin
            expand = {pixel[15 : 11], 3'd0, pixel[10 : 5], 2'd0, pixel[4 : 0], 3'd0};
        end
    endfunction

    task clear_cache;
        begin
            @(negedge clk); flush = 1;
            @(negedge clk); flush = 0;
        end
    endtask

    task sample;
        input integer x;
        input integer y;
        input [2 : 0] mask;
        reg [287 : 0] expected;
        integer c;
        integer k;
        integer px;
        integer py;
        begin
            expected = 0;
            @(negedge clk);
            req_uv = 0;
            for(c = 0; c < 3; c = c + 1)begin
                req_uv[c * 36 +: 36] = ((y * 256 + 17) << 18) | (x * 256 + 223);
                if(mask[c])begin
                    for(k = 0; k < 4; k = k + 1)begin
                        px = x + (k % 2);
                        py = y + (k / 2);
                        if(px > 959) px = 959;
                        if(py > 539) py = 539;
                        expected[c * 96 + k * 24 +: 24] = expand(raw_pixel(c, pages[c * 2 +: 2], py * 960 + px));
                    end
                end
            end
            req_mask = mask;
            req_valid = 1;
            do @(posedge clk); while(!req_ready);
            @(negedge clk); req_valid = 0;
            wait(rsp_valid);
            repeat(5)begin
                @(negedge clk);
                if(!rsp_valid || rsp_pixels !== expected)
                    $fatal(1, "Sample mismatch/stalled response x=%0d y=%0d mask=%b got=%h expected=%h", x,y,mask,rsp_pixels,expected);
            end
            rsp_ready = 1;
            @(negedge clk); rsp_ready = 0;
            cases = cases + 1;
        end
    endtask

    always@(posedge clk)begin
        if(!rst_n)begin
            rvalid <= 0;
            rlast <= 0;
            pending <= 0;
        end
        else begin
            cycles = cycles + 1;
            if(cycles > 100000) $fatal(1, "Sampler unit timeout");
            lfsr <= {lfsr[30 : 0], lfsr[31] ^ lfsr[21] ^ lfsr[1] ^ lfsr[0]};
            rvalid <= 0;
            rlast <= 0;
            if(arvalid && arready)begin
                if(araddr[5 : 0] != 0 || araddr[27 : 24] != 0) $fatal(1, "Wrong word address");
                pending <= 1;
                saved_address <= araddr;
                delay_count <= lfsr[5 : 3];
                beat <= 0;
            end
            if(pending)begin
                if(delay_count > 0) delay_count <= delay_count - 1;
                else if(lfsr[1 : 0] != 0)begin
                    rvalid <= 1;
                    rlast <= bad_last ? beat == 3 : beat == 7;
                    for(integer j = 0; j < 16; j = j + 1)
                        rdata[j * 16 +: 16] <= raw_pixel(saved_address[23 : 22], saved_address[21 : 20],
                                                       saved_address[19 : 0] * 2 + beat * 16 + j);
                    if(bad_last ? beat == 3 : beat == 7) pending <= 0;
                    else beat <= beat + 1;
                end
            end
        end
    end

    initial begin
        #1 rst_n = 1;
        #1 rst_n = 0;
        repeat(5) @(negedge clk);
        rst_n = 1;
        sample(0,0,7);
        sample(15,0,7);
        sample(127,16,7);
        sample(959,539,7);
        sample(250,250,0);
        sample(958,538,5);
        pages = 8'h1b;
        clear_cache;
        sample(0,0,7);
        sample(959,539,7);
        for(integer t = 0; t < 100; t = t + 1)
            sample((t * 127) % 960, (t * 37) % 540, t % 8);
        clear_cache;
        bad_last = 1;
        @(negedge clk); req_uv = 0; req_mask = 1; req_valid = 1;
        do @(posedge clk); while(!req_ready);
        @(negedge clk); req_valid = 0;
        wait(errors != 0);
        repeat(5) @(negedge clk);
        if(errors != 1 || rsp_valid || req_ready)
            $fatal(1, "Malformed burst must fail closed");
        rst_n = 0;
        bad_last = 0;
        repeat(4) @(negedge clk);
        rst_n = 1;
        sample(127,16,7);
        test_passed = 1;
        $display("PASS sampler AXI: cases=%0d, page/cache flush, end-pixel clamp, response stalls, malformed-RLAST detection/reset recovery", cases);
        $finish;
    end
endmodule
