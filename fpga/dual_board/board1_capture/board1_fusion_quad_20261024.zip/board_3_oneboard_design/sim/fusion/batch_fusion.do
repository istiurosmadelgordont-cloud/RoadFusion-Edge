onerror {quit -code 1 -force}
onbreak {}
do sim/fusion/run_fusion.do
quit -code 0 -force
