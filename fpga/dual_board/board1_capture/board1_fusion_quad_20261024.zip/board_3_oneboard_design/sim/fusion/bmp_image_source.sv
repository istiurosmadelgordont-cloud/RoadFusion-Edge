`timescale 1ns/1ps

// Simulation-only BMP input; one pixel is R, G, B on three clocks.
module bmp_image_source#(
    parameter   N                            =   450,
    parameter   M                            =   450,
    parameter   INPUT_ARG                    =   "LEFT",
    parameter   PIC_PATH                     =   "../res/left.bmp"
)(
    input                   clk,
    input                   camera_en,
    output reg              data_valid           =   0,
    output reg  [7 : 0]     data_out             =   0
);

    localparam  STRIDE                       =   ((M * 3 + 3) / 4) * 4;
    localparam  BYTE_COUNT                   =   N * M * 3;
    reg         [7 : 0]     header[0 : 53];
    reg         [7 : 0]     pixels[0 : STRIDE * N - 1];
    reg         [7 : 0]     mem[0 : BYTE_COUNT - 1];
    integer                 ptr                  =   0;
    integer                 fd;
    integer                 bytes_read;
    integer                 offset;
    integer                 dib;
    integer                 width;
    integer                 height;
    integer                 compression;
    integer                 x;
    integer                 y;
    integer                 row;
    integer                 address;
    string                  path;
    string                  argument_format;

    initial begin
        path            = PIC_PATH;
        argument_format = {INPUT_ARG, "=%s"};
        if($value$plusargs(argument_format, path))begin end
        fd = $fopen(path, "rb");
        if(!fd)
            $fatal(1, "Cannot open %s BMP: %s", INPUT_ARG, path);
        bytes_read = $fread(header, fd);
        if(bytes_read != 54)
            $fatal(1, "Truncated BMP header: %s", path);
        offset      = {header[13], header[12], header[11], header[10]};
        dib         = {header[17], header[16], header[15], header[14]};
        width       = {header[21], header[20], header[19], header[18]};
        height      = $signed({header[25], header[24], header[23], header[22]});
        compression = {header[33], header[32], header[31], header[30]};
        if({header[1], header[0]} != 16'h4d42 || dib < 40 || offset < 54 ||
           {header[27], header[26]} != 1 || {header[29], header[28]} != 24 || compression != 0)
            $fatal(1, "Input must be uncompressed 24-bit BMP: %s", path);
        if(width != M || (height != N && height != -N))
            $fatal(1, "%s is %0dx%0d; expected %0dx%0d", path, width, height, M, N);
        if($fseek(fd, offset, 0) != 0)
            $fatal(1, "Invalid BMP pixel offset: %s", path);
        bytes_read = $fread(pixels, fd);
        $fclose(fd);
        if(bytes_read != STRIDE * N)
            $fatal(1, "Truncated BMP pixels: %s", path);
        for(y = 0; y < N; y = y + 1)begin
            row = height < 0 ? y : N - 1 - y;
            for(x = 0; x < M; x = x + 1)begin
                address                  = row * STRIDE + x * 3;
                mem[(y * M + x) * 3    ] = pixels[address + 2];
                mem[(y * M + x) * 3 + 1] = pixels[address + 1];
                mem[(y * M + x) * 3 + 2] = pixels[address    ];
            end
        end
        $display("Loaded %s BMP %s (%0dx%0d, RGB byte stream)", INPUT_ARG, path, M, N);
    end

    always@(posedge clk)begin
        if(camera_en && ptr < BYTE_COUNT)begin
            data_valid <= 1'b1;
            data_out   <= mem[ptr];
            ptr        <= ptr + 1;
        end
        else begin
            data_valid <= 1'b0;
            data_out   <= 8'd0;
            if(!camera_en)
                ptr <= 0;
        end
    end

endmodule

module image#(
    parameter   N                            =   450,
    parameter   M                            =   450
)(
    input                   clk,
    input                   camera_en,
    output                  data_valid,
    output      [7 : 0]     data_out
);

    bmp_image_source#(
        .N                  (N                      ),
        .M                  (M                      ),
        .INPUT_ARG          ("LEFT"                 ),
        .PIC_PATH           ("../res/left.bmp" )
    )u_source(
        .clk                (clk                    ),
        .camera_en          (camera_en              ),
        .data_valid         (data_valid             ),
        .data_out           (data_out               )
    );

endmodule

module image2#(
    parameter   N                            =   450,
    parameter   M                            =   450
)(
    input                   clk,
    input                   camera_en,
    output                  data_valid,
    output      [7 : 0]     data_out
);

    bmp_image_source#(
        .N                  (N                      ),
        .M                  (M                      ),
        .INPUT_ARG          ("RIGHT"                 ),
        .PIC_PATH           ("../res/right.bmp" )
    )u_source(
        .clk                (clk                    ),
        .camera_en          (camera_en              ),
        .data_valid         (data_valid             ),
        .data_out           (data_out               )
    );

endmodule
