catch {quit -sim}
if {![file exists source/fusion/fusion_ddr_pipeline.v]} {error "cd to board_3_oneboard_design first"}
set FUSION_ROOT [pwd]
file mkdir sim/fusion/results
if {![file isdirectory sim/fusion/work]} {vlib sim/fusion/work}
vmap -modelsimini sim/fusion/modelsim.ini work_fusion sim/fusion/work
vlog -work work_fusion -timescale 1ns/1ps source/fusion/grid_node_rom.v
vlog -work work_fusion -timescale 1ns/1ps source/fusion/grid_coordinate_interp.v
vlog -work work_fusion -timescale 1ns/1ps source/fusion/rgb_bilinear_q8.v
vlog -work work_fusion -timescale 1ns/1ps source/fusion/fixed_seam_weights.v
vlog -work work_fusion -timescale 1ns/1ps source/fusion/rgb_feather_blend.v
vlog -work work_fusion -timescale 1ns/1ps source/fusion/grid_fusion_top.v
vlog -work work_fusion -timescale 1ns/1ps source/fusion/fusion_ddr_sampler.v
vlog -work work_fusion -timescale 1ns/1ps source/fusion/fusion_ddr_read_arbiter.v
vlog -work work_fusion -timescale 1ns/1ps source/fusion/fusion_ddr_pipeline.v
vlog -work work_fusion -timescale 1ns/1ps source/fusion/fusion_video_window.v
vlog -work work_fusion source/sync_generator.v
vlog -sv -work work_fusion sim/fusion/bmp_image_source.sv sim/fusion/bmp_rgb_pack.sv sim/fusion/panorama_bmp_writer.sv sim/fusion/fusion_ddr_model.sv sim/fusion/fusion_board_tb.sv
vsim -modelsimini sim/fusion/modelsim.ini -voptargs=+acc -onfinish stop work_fusion.fusion_board_tb
run -all
if {[examine -radix unsigned sim:/fusion_board_tb/test_passed] != 1} {error "Board fusion integration test did not pass"}
puts "PASS: RGB565 DDR read-side integration and quadrant/panorama output selection"
