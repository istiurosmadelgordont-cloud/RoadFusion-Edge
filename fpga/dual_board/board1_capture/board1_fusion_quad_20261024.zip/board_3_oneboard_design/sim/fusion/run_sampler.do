catch {quit -sim}
if {![file exists source/fusion/fusion_ddr_sampler.v]} {error "cd to board_3_oneboard_design first"}
if {![file isdirectory sim/fusion/work_sampler]} {vlib sim/fusion/work_sampler}
vmap -modelsimini sim/fusion/modelsim.ini work_sampler sim/fusion/work_sampler
vlog -work work_sampler -timescale 1ns/1ps source/fusion/fusion_ddr_sampler.v
vlog -sv -work work_sampler sim/fusion/sampler_axi_tb.sv
vsim -modelsimini sim/fusion/modelsim.ini -voptargs=+acc -onfinish stop work_sampler.sampler_axi_tb
run -all
if {[examine -radix unsigned sim:/sampler_axi_tb/test_passed] != 1} {error "Sampler AXI test did not pass"}
