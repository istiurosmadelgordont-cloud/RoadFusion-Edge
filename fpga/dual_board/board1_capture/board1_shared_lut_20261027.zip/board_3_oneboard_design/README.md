# 板卡一：三组共用 LUT、融合与四宫格切换

当前为 **2026-10-27 共用 LUT 构建**，2026-10-29 核对桌面工程后归档上传。替换仓库原 2026-10-24 板卡一工程与 bit。

## 下载

- [工程 ZIP](../board1_shared_lut_20261027.zip)：PDS 工程、RTL、生成 IP、12 份 BRAM LUT、约束、匹配的 bit/FIC 与构建记录。
- [单独 bit](generate_bitstream/test_ddr_shared_lut_20261027.sbit)。Debugger 使用 ZIP 内 `generate_bitstream/test_ddr_shared_lut_20261027.fic`；两者需配套。
- [SHA256](SHA256SUMS.txt)。ZIP 内 `SOURCE_MANIFEST.csv` 逐文件记录大小和校验值。

解压进入 `board_3_oneboard_design`，用 **PDS 2022.2-SP6.4** 打开 `3_ddr_test.pds`；器件 **PGL50H / FBG484 / -6**，顶层 `test_ddr`（`source/ddr_test_top.v`）。重建请从 Compile 开始，使用包内全部源文件及约束。本次归档不重新构建或操作硬件下载。

包内通用 `generate_bitstream/test_ddr.sbit` / `.fic` 与上述有日期版本逐字节相同。不要把本机其他旧 bit 或 Flash 回读文件与本包混用。

## 共用 LUT 的含义

以下三组前左 / 前中 / 前右视频共同估计一套相机映射参数，**三组共用同一套 12 个 BRAM 初始化 hex**，运行时无需按视频组切表：

- `02_sunny_dashed_solid_473423e3`
- `03_sunny_middle_lane_fdab85ad`
- `04_daylight_cloudy_backup_47e8da5f`

“共用”指三组素材共用一套映射；每个相机仍有独立映射（left/center/right 各 4 bank），并非三路相机读取完全相同的坐标。

实际加载位置 `fusion_maps/grid16_bram`。16 像素网格，每相机 121×35 节点；每 bank 1098 个 36 位 Q10.8 节点，u 在低 18 位、v 在高 18 位，全 1 无效。详见包内 `sim/panorama/SHARED_LUT_20261027.md`、`config.json` 和 `geometry.json`。

保留固定接缝 **x=640 / 1280、128 像素羽化**。动态接缝实验已经回退；未启用窄带羽化。LUT 是综合期 BRAM 初值，没有运行时写入接口；换表需重建并下载新 bit。

## 输入、输出与按键

| DDR 通道 | 实际输入 | 融合视角 | 四宫格位置 |
| --- | --- | --- | --- |
| 0 | HDMI | 前左 | 左上 |
| 1 | 以太网1 | 前中广角 | 右上 |
| 2 | 以太网0 | 前右 | 左下 |
| 3 | SFP（板卡二回传） | 不参与融合 | 右下 |

每路 960×540 RGB565。融合为 1920×540，位于 1920×1080 上半区，下半区黑色；四宫格为完整 1920×1080。HDMI 与 SFP 共用同一输出。

**KEY2：L15 / 3.3 V / LVCMOS33 / 低电平按下**。上电默认融合，每按一次切换融合 / 四宫格；消抖沿用原 `Key_anti_shake.v`，KEY1 保留复位。等待完整结果生成后，在垂直消隐期切换。

包含 **缺 SFP 的模式切换修复**：四宫格只锁定已有完整帧的输入，未就绪象限输出黑色；SFP 初始未接入时，其他三格仍可更新，不再一直等待第四路。三路融合仍要求通道 0、1、2 都有完整帧。

`source_valid` 表示曾收到完整帧的粘滞状态，**不是实时在线检测**。已经有帧后再拔线，可能保留末帧；不保证自动变黑。各路页面锁定不等于相机曝光或视频时间戳同步。

以太网0：`192.168.1.10 / A0-B1-C2-D3-E4-E4`；以太网1：`192.168.1.11 / A0-B1-C2-D3-E1-E1`，UDP 1234。系统接线及发送说明见 [双板说明](https://github.com/istiurosmadelgordont-cloud/RoadFusion-Edge/blob/main/fpga/dual_board/README.md)。

## 与仓库旧版相比

1. 以三组视频共同估计的 LUT 替换旧单组映射，通道顺序不变。
2. 保留缺 SFP 四宫格黑区修复及显示 FIFO 紧急阈值 192、连续突发读补水逻辑。
3. 保留 KEY2、原按键消抖和两路输出共用的融合 / 四宫格切换。
4. 动态接缝改动已回退至上述固定接缝；新暗光 / 去雾串联实验未接入本工程。

## 验证与边界

本次归档核对了 62 个构建输入的 SHA256、PDS 有效配置、12 个 bank 格式及 bit/FIC 哈希，全部与 2026-10-27 构建记录一致；未重新运行仿真、综合和布局布线。

已有三组 RTL 记录随包保留：第1组完整显示 / 缺 SFP / 恢复 / 回融合回归，`fusion=8, missing_quad=4, missing_updated=6, full_quad=8, returned=2, renders=11, underruns=0`；第2/3组各逐像素核对 1,036,800 个融合输出像素。日志在 `docs/verification`。原始视频、提取素材、预览画廊及仿真编译缓存不随本次工程包上传。

2026-10-29 用户确认当前这一版已上板可运行；此前也已反馈四路完整输入时按键切换正常。此为功能运行反馈，尚无覆盖温度、电压、长时间运行及全部缺路场景的验收记录。

**用户上板可运行，物理时序尚未收敛**：DDR Slow Setup −4.021 ns、Slow Hold −0.044 ns、Fast Hold −0.088 ns，像素 Slow Setup −0.865 ns。报告为包内 `report_timing/test_ddr.rtr`。HDMI 名义 150 MHz / 2200×1125 ≈ 60.606 Hz；融合结果的新画面生成速率受渲染吞吐限制。本次保留原工程与码流，不为消除报告负裕量而改动 RTL 或约束。

共用 LUT 是图像估计的折中参数，并非官方内外参或任意视角通用标定；近景视差、运动、曝光不同步及第三组车辆仍可产生残差或重影。更换镜头、安装位姿、分辨率或裁剪后需重新验证 / 生成 LUT。

bit SHA256：`52b79dac54a7f50509094f134cc6483dc25e8e2cdc0eb9f5deca1d515c26596f`。

FIC SHA256：`82701ffb836baf9568c6e39799712f1451bfc7290371c2944a0424520a6e2aa1`。

第三方声明保留在工程包内；见 [权利通知](https://github.com/istiurosmadelgordont-cloud/RoadFusion-Edge/blob/main/fpga/dual_board/DISCLAIMER.md)。旧版本可在 Git 历史中恢复。
