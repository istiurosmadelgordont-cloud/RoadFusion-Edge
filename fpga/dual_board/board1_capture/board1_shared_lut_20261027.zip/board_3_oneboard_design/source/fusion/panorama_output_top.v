// Fixed panorama output. Source pages are locked until the result is committed.
// Two result frames live in DDR, separate from the four source-channel regions.
module panorama_output_top#(
    parameter   [3 : 0]     CAPTURE_AXI_LEN          =   4'd8,
    parameter               MODE_SWITCH_ENABLE       =   0
)(
    input                     clk,
    input                     rst_n,
    input                     requested_quad,
    output                    mode_active,
    input       [3 : 0]       source_valid,
    input       [7 : 0]       source_pages,
    input       [3 : 0]       lock_granted,
    output      [3 : 0]       lock_valid,
    output reg  [7 : 0]       lock_pages,
    input                     capture_awvalid,
    output                    capture_awready,
    input       [27 : 0]      capture_awaddr,
    input       [255 : 0]     capture_wdata,
    input       [31 : 0]      capture_wstrb,
    output                    capture_wready,
    output                    capture_wlast,
    output      [3 : 0]       awlen,
    output                    awvalid,
    input                     awready,
    output      [27 : 0]      awaddr,
    output      [255 : 0]     wdata,
    output      [31 : 0]      wstrb,
    input                     wready,
    input                     wlast,
    output                    arvalid,
    input                     arready,
    output      [27 : 0]      araddr,
    input                     rvalid,
    input                     rlast,
    input       [255 : 0]     rdata,
    input                     pixel_clk,
    input                     vs,
    input                     hs,
    input                     de,
    input       [11 : 0]      pixel_y,
    output                    video_vs,
    output                    video_hs,
    output                    video_de,
    output      [23 : 0]      video_rgb/* synthesis PAP_MARK_DEBUG="1" */,
    output reg  [31 : 0]      rendered_frames,
    output      [31 : 0]      underrun_count,
    output      [31 : 0]      error_count
);
    localparam  WAIT_SOURCE                  =   2'd0;
    localparam  CLAIM                        =   2'd1;
    localparam  RENDER                       =   2'd2;
    localparam  PRESENT                      =   2'd3;
    reg         [1 : 0]     state /* synthesis PAP_MARK_DEBUG="1" */;
    localparam  RESULT_BUFFER1 = 28'h1100000;
    reg                     render_start;
    reg                     render_quad;
    reg         [3 : 0]     render_sources;
    reg                     published_quad;
    (* syn_preserve = 1 *) reg mode_s0;
    (* syn_preserve = 1 *) reg mode_s1;
    wire                    requested_mode;
    wire        [3 : 0]     requested_mask;
    wire        [3 : 0]     render_mask;
    wire                    display_quad;
    wire                    grid_pixel_valid;
    wire        [23 : 0]    grid_pixel_rgb;
    wire                    quad_pixel_valid;
    wire        [23 : 0]    quad_pixel_rgb;
    wire                    quad_done;
    wire                    renderer_done;
    wire                    quad_arvalid;
    wire                    quad_arready;
    wire        [27 : 0]    quad_araddr;
    wire                    quad_rvalid;
    wire                    quad_rlast;
    wire        [255 : 0]   quad_rdata;
    wire        [31 : 0]    quad_errors;
    reg                     render_buffer;
    reg                     render_done;
    reg                     published_valid /* synthesis PAP_MARK_DEBUG="1" */;
    reg                     published_buffer;
    wire                    display_valid /* synthesis PAP_MARK_DEBUG="1" */;
    wire                    display_buffer;
    wire                    grid_busy /* synthesis PAP_MARK_DEBUG="1" */;
    wire                    grid_done;
    wire                    pixel_valid /* synthesis PAP_MARK_DEBUG="1" */;
    wire                    pixel_ready /* synthesis PAP_MARK_DEBUG="1" */;
    wire        [23 : 0]    pixel_rgb;
    wire                    writer_done;
    wire                    result_awvalid;
    wire                    result_awready;
    wire        [27 : 0]    result_awaddr;
    wire        [255 : 0]   result_wdata;
    wire                    result_wready;
    wire                    result_wlast;
    wire                    display_read_urgent;
    wire                    display_arvalid;
    wire                    display_arready;
    wire        [27 : 0]    display_araddr;
    wire                    display_rvalid;
    wire                    display_rlast;
    wire        [255 : 0]   display_rdata;
    wire        [31 : 0]    writer_errors /* synthesis PAP_MARK_DEBUG="1" */;
    wire        [31 : 0]    reader_errors /* synthesis PAP_MARK_DEBUG="1" */;
    wire        [31 : 0]    sampler_errors /* synthesis PAP_MARK_DEBUG="1" */;
    wire        [31 : 0]    coverage_errors /* synthesis PAP_MARK_DEBUG="1" */;
    wire        [31 : 0]    fallback_count;

    // DDR-clock observations only. These counters never feed functional control.
    reg         [31 : 0]    debug_read_bursts /* synthesis PAP_MARK_DEBUG="1" */;
    reg         [31 : 0]    debug_read_beats /* synthesis PAP_MARK_DEBUG="1" */;
    reg         [31 : 0]    debug_capture_bursts /* synthesis PAP_MARK_DEBUG="1" */;
    reg         [31 : 0]    debug_result_bursts /* synthesis PAP_MARK_DEBUG="1" */;

    always@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            debug_read_bursts    <= 0;
            debug_read_beats     <= 0;
            debug_capture_bursts <= 0;
            debug_result_bursts  <= 0;
        end
        else begin
            if(arvalid && arready)begin
                debug_read_bursts <= debug_read_bursts + 1'b1;
            end
            if(rvalid)begin
                debug_read_beats <= debug_read_beats + 1'b1;
            end
            if(capture_wready && capture_wlast)begin
                debug_capture_bursts <= debug_capture_bursts + 1'b1;
            end
            if(result_wready && result_wlast)begin
                debug_result_bursts <= debug_result_bursts + 1'b1;
            end
        end
    end

    assign requested_mode = MODE_SWITCH_ENABLE && mode_s1;
    // The first three inputs are required. SFP is optional in quad mode.
    assign requested_mask = 4'b0111;
    assign render_mask    = render_sources;
    assign lock_valid     = (state == CLAIM || state == RENDER) ? render_mask : 4'b0000;
    assign pixel_valid    = render_quad ? quad_pixel_valid : grid_pixel_valid;
    assign pixel_rgb      = render_quad ? quad_pixel_rgb : grid_pixel_rgb;
    assign renderer_done  = render_quad ? quad_done : grid_done;
    assign error_count = writer_errors + reader_errors + sampler_errors + coverage_errors + quad_errors;

    always@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            state            <= WAIT_SOURCE;
            mode_s0          <= 0;
            mode_s1          <= 0;
            render_quad      <= 0;
            render_sources   <= 4'b0111;
            published_quad   <= 0;
            lock_pages       <= 0;
            render_start     <= 0;
            render_buffer    <= 0;
            render_done      <= 0;
            published_valid  <= 0;
            published_buffer <= 0;
            rendered_frames  <= 0;
        end
        else begin
            mode_s0 <= requested_quad;
            mode_s1 <= mode_s0;
            render_start <= 0;
            case(state)
                WAIT_SOURCE:begin
                    if((source_valid & requested_mask) == requested_mask && error_count == 0)begin
                        lock_pages    <= source_pages;
                        render_quad   <= requested_mode;
                        render_sources <= requested_mode ? source_valid : 4'b0111;
                        render_buffer <= display_valid ? !display_buffer : 1'b0;
                        state         <= CLAIM;
                    end
                end
                CLAIM:begin
                    if((lock_granted & render_mask) == render_mask)begin
                        render_start <= 1;
                        render_done  <= 0;
                        state        <= RENDER;
                    end
                end
                RENDER:begin
                    if(renderer_done)begin
                        render_done <= 1;
                    end
                    if(writer_done && (render_done || renderer_done))begin
                        published_buffer <= render_buffer;
                        published_quad   <= render_quad;
                        published_valid  <= 1;
                        rendered_frames  <= rendered_frames + 1'b1;
                        state            <= PRESENT;
                    end
                end
                PRESENT:begin
                    if(display_valid && display_buffer == published_buffer && display_quad == published_quad)begin
                        state <= WAIT_SOURCE;
                    end
                end
            endcase
        end
    end

    fusion_ddr_pipeline#(
        .DISPLAY_PRIORITY        (1                           ),
        .DISPLAY_URGENT_ENABLE   (1                           ),
        .QUAD_RENDER_ENABLE      (MODE_SWITCH_ENABLE          )
    )u_pipeline(
        .clk                     (clk                         ),
        .rst_n                   (rst_n                       ),
        .start                   (render_start && !render_quad),
        .quad_select             (render_quad                 ),
        .quad_arvalid            (quad_arvalid                ),
        .quad_arready            (quad_arready                ),
        .quad_araddr             (quad_araddr                 ),
        .quad_rvalid             (quad_rvalid                 ),
        .quad_rlast              (quad_rlast                  ),
        .quad_rdata              (quad_rdata                  ),
        .frame_pages             (lock_pages                  ),
        .busy                    (grid_busy                   ),
        .done                    (grid_done                   ),
        .out_ready               (pixel_ready && !render_quad ),
        .out_valid               (grid_pixel_valid            ),
        .out_rgb                 (grid_pixel_rgb              ),
        .out_x                   (                            ),
        .out_y                   (                            ),
        .out_sof                 (                            ),
        .out_eol                 (                            ),
        .out_eof                 (                            ),
        .legacy_urgent           (display_read_urgent         ),
        .legacy_arvalid          (display_arvalid             ),
        .legacy_arready          (display_arready             ),
        .legacy_araddr           (display_araddr              ),
        .legacy_rvalid           (display_rvalid              ),
        .legacy_rlast            (display_rlast               ),
        .legacy_rdata            (display_rdata               ),
        .arvalid                 (arvalid                     ),
        .arready                 (arready                     ),
        .araddr                  (araddr                      ),
        .rvalid                  (rvalid                      ),
        .rlast                   (rlast                       ),
        .rdata                   (rdata                       ),
        .burst_count             (                            ),
        .protocol_errors         (sampler_errors              ),
        .coverage_errors         (coverage_errors             ),
        .fallback_count          (fallback_count              )
    );

    quad_frame_renderer#(
        .SOURCE_MASK_ENABLE      (1                           )
    )u_quad(
        .clk                     (clk                         ),
        .rst_n                   (rst_n                       ),
        .start                   (render_start && render_quad ),
        .frame_pages             (lock_pages                  ),
        .frame_valid             (render_sources              ),
        .busy                    (                            ),
        .done                    (quad_done                   ),
        .out_valid               (quad_pixel_valid            ),
        .out_ready               (pixel_ready && render_quad  ),
        .out_rgb                 (quad_pixel_rgb              ),
        .arvalid                 (quad_arvalid                ),
        .arready                 (quad_arready                ),
        .araddr                  (quad_araddr                 ),
        .rvalid                  (quad_rvalid                 ),
        .rlast                   (quad_rlast                  ),
        .rdata                   (quad_rdata                  ),
        .errors                  (quad_errors                 )
    );

    fusion_frame_writer#(
        .BUFFER1                 (RESULT_BUFFER1              ),
        .MODE_SWITCH_ENABLE      (MODE_SWITCH_ENABLE          )
    )u_writer(
        .clk                     (clk                         ),
        .rst_n                   (rst_n                       ),
        .start                   (render_start                ),
        .buffer_select           (render_buffer               ),
        .render_quad             (render_quad                 ),
        .pixel_valid             (pixel_valid                 ),
        .pixel_ready             (pixel_ready                 ),
        .pixel_rgb               (pixel_rgb                   ),
        .busy                    (                            ),
        .done                    (writer_done                 ),
        .awvalid                 (result_awvalid              ),
        .awready                 (result_awready              ),
        .awaddr                  (result_awaddr               ),
        .wdata                   (result_wdata                ),
        .wready                  (result_wready               ),
        .wlast                   (result_wlast                ),
        .errors                  (writer_errors               )
    );

    fusion_write_arbiter#(
        .CAPTURE_AXI_LEN         (CAPTURE_AXI_LEN             ),
        .RESULT_AXI_LEN          (4'd7                       )
    )u_write_arbiter(
        .clk                     (clk                         ),
        .rst_n                   (rst_n                       ),
        .capture_awvalid         (capture_awvalid             ),
        .capture_awready         (capture_awready             ),
        .capture_awaddr          (capture_awaddr              ),
        .capture_wdata           (capture_wdata               ),
        .capture_wstrb           (capture_wstrb               ),
        .capture_wready          (capture_wready              ),
        .capture_wlast           (capture_wlast               ),
        .result_awvalid          (result_awvalid              ),
        .result_awready          (result_awready              ),
        .result_awaddr           (result_awaddr               ),
        .result_wdata            (result_wdata                ),
        .result_wready           (result_wready               ),
        .result_wlast            (result_wlast                ),
        .awlen                   (awlen                       ),
        .awvalid                 (awvalid                     ),
        .awready                 (awready                     ),
        .awaddr                  (awaddr                      ),
        .wdata                   (wdata                       ),
        .wstrb                   (wstrb                       ),
        .wready                  (wready                      ),
        .wlast                   (wlast                       )
    );

    fusion_frame_reader#(
        .BUFFER1                 (RESULT_BUFFER1              ),
        .MODE_SWITCH_ENABLE      (MODE_SWITCH_ENABLE          )
    )u_reader(
        .clk                     (clk                         ),
        .rst_n                   (rst_n                       ),
        .published_valid         (published_valid             ),
        .published_buffer        (published_buffer            ),
        .published_quad          (published_quad              ),
        .display_valid           (display_valid               ),
        .display_buffer          (display_buffer              ),
        .display_quad            (display_quad                ),
        .video_quad              (mode_active                 ),
        .read_urgent             (display_read_urgent         ),
        .arvalid                 (display_arvalid             ),
        .arready                 (display_arready             ),
        .araddr                  (display_araddr              ),
        .rvalid                  (display_rvalid              ),
        .rlast                   (display_rlast               ),
        .rdata                   (display_rdata               ),
        .pixel_clk               (pixel_clk                   ),
        .vs                      (vs                          ),
        .hs                      (hs                          ),
        .de                      (de                          ),
        .pixel_y                 (pixel_y                     ),
        .video_vs                (video_vs                    ),
        .video_hs                (video_hs                    ),
        .video_de                (video_de                    ),
        .video_rgb               (video_rgb                   ),
        .protocol_errors         (reader_errors               ),
        .underrun_count          (underrun_count              )
    );

endmodule
