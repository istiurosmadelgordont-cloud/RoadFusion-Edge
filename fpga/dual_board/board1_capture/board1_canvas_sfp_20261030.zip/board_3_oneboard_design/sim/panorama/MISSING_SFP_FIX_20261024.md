# SFP 缺失时四宫格切换冻结修复（2026-10-24）

## 原因与用户反馈

用户已上板验证上一版 KEY2 切换，四路齐全时切换正常；SFP 没有输入时按键请求四宫格，画面冻结在上一张融合结果。
旧版四宫格的 requested_mask=1111，只有前三路时 source_valid=0111，状态机一直处于 WAIT_SOURCE，也不再启动融合渲染。
HDMI 扫描时序继续运行，但读端只重复旧结果，导致画面内容完全不动。

## 本次行为

前三路 HDMI / 以太网1 / 以太网0 仍是生成结果的必要输入。三路均有完整源帧后：

- 默认融合保持原行为，1920×540 在 1080p 上半区显示，下半区黑色，原 128 像素融合过渡。
- 按 KEY2 进入四宫格，SFP 没有完整源帧时，右下格为黑色，其余三格继续更新。
- SFP 首次有完整源帧后，下一次新结果会包含第四路；当前正在生成的帧保持原有效路数快照。
- 再按 KEY2 返回融合，继续按原完整帧发布规则切换。

KEY2 / L15 及原消抖模块、四路接线、HDMI/SFP 共用输出、DDR 读补水策略和 LUT 均保持原版实现。
这版修复“前三路有效、SFP 从未有完整输入帧”的等待问题。source_valid 是完整帧就绪标志，未增加实时掉线超时检测；曾经有完整帧后停止送图的通道仍可能显示最后一帧。

## 修改点

`source/fusion/panorama_output_top.v`：四宫格和融合均要求前三路有效；在选择源页时一起锁存 render_sources。
只对 render_sources 中有效的源页请求锁定，避免等待尚未有完整源帧的 SFP。

`source/fusion/quad_frame_renderer.v`：新增 SOURCE_MASK_ENABLE / frame_valid，在 start 时锁存源路数。
缺失象限直接逐像素输出黑色，不发 DDR 读请求，也不取用未初始化缓存；完整 1920×1080 输出顺序及反压处理保持。
默认关闭源掩码功能，兼容旧的独立仿真接口。

## 仿真

```tcl
do sim/panorama/run_missing_unit.do
do sim/panorama/run_missing_integration.do
```

单元测试覆盖缺 SFP、恢复四路、全部无输入的黑色填充能力，逐帧检查完整像素、有效页、禁止读取缺失输入、反压保持和忙时 start/源掩码变化。
其中“全部无输入”只验证取样器的黑色填充能力，板级顶层仍要求前三路有效。

集成测试使用 100MHz DDR / 150MHz 视频和原图像参考，叠加采集写竞争、24～31 周期读返回延迟及随机间隔：
先融合，再在无 SFP 时切四宫格；保持无 SFP 并切换前三路源页，逐像素确认画面确实更新；渲染中途使 SFP 有效，检查第四路在完整结果中出现，最后切回融合。
同时检查帧缓冲不被覆盖、完整帧发布、源掩码不在渲染中改变、DDR 写回/像素格式、视频同步和零欠读。

结果和日志在 `sim/panorama/results/missing_sfp/`。仿真通过不替代新 bit 的板级验证。

本次成品：`generate_bitstream/test_ddr_missing_sfp_20261024.sbit` 和同名 `.fic`。
通用输出文件在构建后变化；成品从已固定且哈希校验不变的本次 PNR 数据库，在独立输出目录重新生成。

DDR Slow Setup=-4.021ns，最差 DDR Hold=-0.088ns，像素 Slow Setup=-0.865ns。
物理时序仍未收敛，本次是功能已仿真通过的上板调试版本。

本次完整仿真：`fusion=9 missing_quad=4 missing_updated=6 full_quad=9 returned=2 renders=11 underruns=0 captures=438976 cycles=57744226`。

bit SHA256：`372aaeafc24c00401b8034c1b62ef03c3f66bf11fd67f4d8ca7c9400f41f4a01`；FIC SHA256：`82701ffb836baf9568c6e39799712f1451bfc7290371c2944a0424520a6e2aa1`。
