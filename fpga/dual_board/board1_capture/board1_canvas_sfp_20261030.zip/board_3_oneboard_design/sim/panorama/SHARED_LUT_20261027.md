# 三组共用 LUT / 2026-10-27

当前工程使用一套共用 BRAM 坐标映射处理以下三组视频；切换视频组不需要更换 LUT。

- 02_sunny_dashed_solid_473423e3
- 03_sunny_middle_lane_fdab85ad
- 04_daylight_cloudy_backup_47e8da5f

## 输入与输出

镜头和输入顺序必须保持：ch0 HDMI=left，ch1 Ethernet1=front 广角，ch2 Ethernet0=right。
ch3 SFP 只用于四宫格。输入必须与离线标定一致：完整 16:9 原图缩为 960×540，不额外裁剪、旋转、翻转或加黑边。
播放时三路应为同一组、相近时刻的片段。当前 FPGA 锁定各路完整帧，但没有按原视频时间戳对齐三路；LUT 只处理空间映射。
融合输出仍是 1920×540，放在 1080p 上半区；KEY2 切换四宫格，HDMI/SFP 共用输出。
保留当前缺少 SFP 时四宫格右下区黑色、其余三路持续更新的逻辑，以及显示读 FIFO 的修复。

## 标定与独立验证

沿用 SIFT 双向 ratio 0.75、球面旋转 RANSAC、名义等距镜头模型和鲁棒旋转拟合。
视频与时间戳均核对原 manifest SHA256，并确认 front 是 camera_front_wide_120fov。
各组训练时间为 1/5/9/13/17 秒，验证时间为 3/7/11/15/19 秒，共 90 张输入图像。按原始微秒时间戳最近邻配对，不按相同帧号硬配对。
各帧空间均衡取样，每个训练时间点近似等权。验证时间点没有参与拟合。
焦距自由拟合再次触及上界，因此仅作为诊断保存，没有安装。正式表保持名义焦距 458.366236 像素。

| 组 | 最大三路时间差/µs | 左侧验证中位/P90 | 右侧验证中位/P90 |
|---|---:|---:|---:|
| 02_sunny_dashed_solid_473423e3 | 9910 | 3.77/5.72 | 8.99/19.93 |
| 03_sunny_middle_lane_fdab85ad | 628 | 1.96/4.37 | 12.11/14.75 |
| 04_daylight_cloudy_backup_47e8da5f | 8956 | 5.26/6.20 | 3.23/5.75 |

误差定义：独立 RANSAC 接受的验证特征点，旋转后的单位射线差乘以名义焦距，单位是输入像素等效值；不是完整画面接缝的直接像素误差。
共用表总体误差小于旧表，但右侧不同组的最佳旋转存在明显差异。第三组近景车辆仍有明显重影；不能把共用表解释为三组都已精确配准。
这些参数是从图像估计的，不是 NVIDIA 官方内外参；没有实测实际 180° 视角。固定 LUT 无法同时补偿不同深度的视差、动态物体、曝光时差或不同相机安装差异。

## BRAM 格式与生成 bit

工程实际读取 fusion_maps/grid16_bram 下 12 个 hex。16 像素网格，每相机 121×35 节点，边界补到 (1920,544)。
每节点 36 位，低 18 位 u、高 18 位 v，均为无符号 Q10.8，36 位全 1 表示无效。
bank=(node_y%2)*2+node_x%2；地址=(node_y//2)*61+node_x//2；每 bank 1098 条。
固定接缝 x=640/1280，保留 128 像素羽化，不启用窄带测试。全部有效采样的四个节点都已核验；无额外像素级回退表。
与连续浮点投影相比，网格+量化造成的最大坐标误差小于 0.032 个输入像素。
hex 是综合时装入 BRAM 的初值。只复制 hex 不会改变已经下载的 FPGA，需重新综合、布局布线、生成并下载新 sbit；当前设计没有运行时写 LUT 的接口。

## 效果与验证记录

预览入口：results/shared_lut/index.html。图像按 RGB565 截断、Q8 双线性采样和整数羽化舍入计算。
RTL 仿真及 bit 构建结果在完成后写入同目录 simulation_results.json 和 delivery.json。
本次只替换 LUT 与说明，RTL、引脚、KEY2 消抖和 FIC 信号集合保持原字节。历史命名的 bit 不覆盖。

## 本次构建结果

新 bit：`generate_bitstream/test_ddr_shared_lut_20261027.sbit`；配套 FIC：同名 `.fic`。请先下载这个新 bit 再加载对应 FIC；本次没有操作硬件下载。

- 02_sunny_dashed_solid_473423e3：`PASS missing integration: fusion=8 missing_quad=4 missing_updated=6 full_quad=8 returned=2 renders=11 underruns=0 captures=400308 cycles=52794721`
- 03_sunny_middle_lane_fdab85ad：`PASS shared LUT: RGB565 fusion pixels=1036800 bursts=37569 legacy_bursts=15690 cycles=5697582 stalls=231560`
- 04_daylight_cloudy_backup_47e8da5f：`PASS shared LUT: RGB565 fusion pixels=1036800 bursts=37569 legacy_bursts=15690 cycles=5697582 stalls=231560`

DDR Slow Setup -4.021ns，Slow Hold -0.044ns，Fast Hold -0.088ns；像素 Slow Setup -0.865ns。

物理时序尚未收敛；本次提供用于上板验证的调试版本，不把 RTL 数字模型验证当成硬件稳定性验证。
共用参数在三组近景处仍有残差，不能保证无重影；后续如追求单组最佳效果，可使用按组独立 LUT 或取得真实内外参后重建。

bit SHA256 `52b79dac54a7f50509094f134cc6483dc25e8e2cdc0eb9f5deca1d515c26596f`；FIC SHA256 `82701ffb836baf9568c6e39799712f1451bfc7290371c2944a0424520a6e2aa1`。
