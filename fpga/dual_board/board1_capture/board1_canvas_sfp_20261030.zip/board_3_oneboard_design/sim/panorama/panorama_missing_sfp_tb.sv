`timescale 1ns/1ps
module panorama_missing_sfp_tb;
    reg                     clk = 0;
    reg                     pixel_clk = 0;
    reg                     rst_n = 0;
    reg         [3 : 0]     load_enable = 0;
    wire        [3 : 0]     load_valid;
    wire        [95 : 0]    load_rgb;
    wire                    loaded;
    reg         [7 : 0]     source_pages = 8'he4;
    wire        [3 : 0]     lock_valid;
    wire        [7 : 0]     lock_pages;
    reg         [3 : 0]     lock_granted = 0;
    reg                     capture_awvalid = 0;
    wire                    capture_awready;
    wire        [27 : 0]    capture_awaddr;
    wire        [255 : 0]   capture_wdata;
    wire                    capture_wready;
    wire                    capture_wlast;
    reg                     capture_busy = 0;
    reg         [3 : 0]     capture_beat = 0;
    integer                 capture_bursts = 0;
    wire        [3 : 0]     awlen;
    wire                    awvalid;
    wire                    awready;
    wire        [27 : 0]    awaddr;
    wire        [255 : 0]   wdata;
    wire        [31 : 0]    wstrb;
    wire                    wready;
    wire                    wlast;
    wire                    arvalid;
    wire                    arready;
    wire        [27 : 0]    araddr;
    wire                    rvalid;
    wire                    rlast;
    wire        [255 : 0]   rdata;
    wire                    vs;
    wire                    hs;
    wire                    de;
    wire        [11 : 0]    x;
    wire        [11 : 0]    y;
    wire                    video_vs;
    wire                    video_hs;
    wire                    video_de;
    wire        [23 : 0]    video_rgb;
    wire        [31 : 0]    rendered_frames;
    wire        [31 : 0]    underruns;
    wire        [31 : 0]    errors;
    reg         [23 : 0]    expected[0 : 2073599];
    integer                 render_phase = 0;
    integer                 write_pixels = 0;
    integer                 result_bursts = 0;
    integer                 versions[0 : 1];
    reg                     model_write_owner;
    reg         [27 : 0]    model_write_address;
    integer                 model_write_beat;
    integer                 cycles = 0;
    integer                 render_start_cycle = 0;
    integer                 previous_commit_cycle = 0;
    integer                 good_normal_frames = 0;
    integer                 good_inverse_frames = 0;
    integer                 black_frames = 0;
    integer                 panel_frame = -1;
    integer                 panel_count = 0;
    integer                 panel_phase;
    reg                     panel_show;
    reg                     panel_bank;
    reg                     panel_started = 0;
    reg                     output_vs_d = 0;
    reg                     expected_vs;
    reg                     expected_hs;
    reg                     expected_de;
    reg         [11 : 0]    expected_x;
    reg         [11 : 0]    expected_y;
    reg         [23 : 0]    target_pixel;
    reg                     normal_write = 0;
    reg                     inverse_write = 0;
    reg         [23 : 0]    image_pixel;
    reg                     test_passed = 0;
    reg                     pixel_check_enable = 0;

    reg                     ref_clk = 0;
    reg                     key_n = 1;
    reg         [3 : 0]     available = 4'b0111;
    wire                    requested_quad;
    wire                    mode_active;
    reg                     panel_quad;
    integer                 good_return_frames = 0;
    integer                 quad_versions[0 : 1];
    reg         [23 : 0]    source_ref[0 : 2073599];
    reg         [23 : 0]    quad_expected;
    integer                 requested_changes = 0;
    reg                     previous_requested = 0;
    reg         [3 : 0]     render_source_mask;
    reg         [3 : 0]     mask_versions[0 : 1];
    reg         [3 : 0]     panel_sources;
    integer                 missing_normal_frames = 0;
    integer                 missing_changed_frames = 0;
    integer                 full_quad_frames = 0;
    reg                     connected_write = 0;

    always #10 ref_clk = ~ref_clk;
    video_mode_key#(
        .MCNT                    (9999                        )
    )key_control(
        .clk                     (ref_clk                     ),
        .rst_n                   (rst_n                       ),
        .key_n                   (key_n                       ),
        .requested_quad          (requested_quad              )
    );

    always@(negedge ref_clk)begin
        if(rst_n && requested_quad != previous_requested) requested_changes = requested_changes + 1;
        previous_requested = requested_quad;
    end

    function [23 : 0] quad_pixel_at;
        input integer px;
        input integer py;
        input integer phase;
        input [3 : 0] mask;
        integer camera;
        integer offset;
        begin
            camera = (py >= 540 ? 2 : 0) + (px >= 960 ? 1 : 0);
            offset = camera * 518400 + (py % 540) * 960 + px % 960;
            quad_pixel_at = mask[camera] ? source_ref[offset] ^ (phase ? 24'hf8fcf8 : 24'h0) : 24'd0;
        end
    endfunction

    task key_level;
        input integer level;
        begin
            repeat(5)begin
                @(negedge ref_clk); key_n = ~key_n;
                repeat(3) @(negedge ref_clk);
            end
            key_n = level;
            repeat(20000) @(negedge ref_clk);
        end
    endtask

    always #5 clk = ~clk;
    always #(10.0 / 3.0) pixel_clk = ~pixel_clk;
    assign capture_awaddr = 28'h0d00000 + (capture_bursts % 1000) * 64;
    assign capture_wdata = {8{32'h6a72c991}};

    bmp_rgb_pack#(
        .INPUT_ARG ("LEFT"),
        .PIC_PATH ("sim/fusion/input/left.bmp")
    )u_load0(
        .clk (clk),
        .rst_n (rst_n),
        .enable (load_enable[0]),
        .valid (load_valid[0]),
        .rgb (load_rgb[0 +: 24])
    );

    bmp_rgb_pack#(
        .INPUT_ARG ("CENTER"),
        .PIC_PATH ("sim/fusion/input/center.bmp")
    )u_load1(
        .clk (clk),
        .rst_n (rst_n),
        .enable (load_enable[1]),
        .valid (load_valid[1]),
        .rgb (load_rgb[24 +: 24])
    );

    bmp_rgb_pack#(
        .INPUT_ARG ("RIGHT"),
        .PIC_PATH ("sim/fusion/input/right.bmp")
    )u_load2(
        .clk (clk),
        .rst_n (rst_n),
        .enable (load_enable[2]),
        .valid (load_valid[2]),
        .rgb (load_rgb[48 +: 24])
    );

    bmp_rgb_pack#(
        .INPUT_ARG ("FOURTH"),
        .PIC_PATH ("sim/fusion/input/fourth.bmp")
    )u_load3(
        .clk (clk),
        .rst_n (rst_n),
        .enable (load_enable[3]),
        .valid (load_valid[3]),
        .rgb (load_rgb[72 +: 24])
    );

    panorama_output_top#(
        .MODE_SWITCH_ENABLE      (1                            )
    )dut(
        .clk                     (clk                           ),
        .rst_n                   (rst_n                         ),
        .requested_quad          (requested_quad               ),
        .mode_active             (mode_active                  ),
        .source_valid            ({4{loaded}} & available       ),
        .source_pages            (source_pages                  ),
        .lock_granted            (lock_granted                  ),
        .lock_valid              (lock_valid                    ),
        .lock_pages              (lock_pages                    ),
        .capture_awvalid         (capture_awvalid               ),
        .capture_awready         (capture_awready               ),
        .capture_awaddr          (capture_awaddr                ),
        .capture_wdata           (capture_wdata                 ),
        .capture_wstrb           (32'hffffffff                  ),
        .capture_wready          (capture_wready                ),
        .capture_wlast           (capture_wlast                 ),
        .awlen                   (awlen                         ),
        .awvalid                 (awvalid                       ),
        .awready                 (awready                       ),
        .awaddr                  (awaddr                        ),
        .wdata                   (wdata                         ),
        .wstrb                   (wstrb                         ),
        .wready                  (wready                        ),
        .wlast                   (wlast                         ),
        .arvalid                 (arvalid                       ),
        .arready                 (arready                       ),
        .araddr                  (araddr                        ),
        .rvalid                  (rvalid                        ),
        .rlast                   (rlast                         ),
        .rdata                   (rdata                         ),
        .pixel_clk               (pixel_clk                     ),
        .vs                      (vs                            ),
        .hs                      (hs                            ),
        .de                      (de                            ),
        .pixel_y                 (y                             ),
        .video_vs                (video_vs                      ),
        .video_hs                (video_hs                      ),
        .video_de                (video_de                      ),
        .video_rgb               (video_rgb                     ),
        .rendered_frames         (rendered_frames               ),
        .underrun_count          (underruns                     ),
        .error_count             (errors                        )
    );

    panorama_ddr_model#(.READ_BASE_DELAY(24))u_ddr(
        .clk                     (clk                           ),
        .rst_n                   (rst_n                         ),
        .load_valid              (load_valid                    ),
        .load_rgb                (load_rgb                      ),
        .loaded                  (loaded                        ),
        .lock_valid              (lock_valid                    ),
        .lock_pages              (lock_pages                    ),
        .awlen                   (awlen                         ),
        .arlen                   (4'd7                         ),
        .awvalid                 (awvalid                       ),
        .awready                 (awready                       ),
        .awaddr                  (awaddr                        ),
        .wdata                   (wdata                         ),
        .wstrb                   (wstrb                         ),
        .wready                  (wready                        ),
        .wlast                   (wlast                         ),
        .arvalid                 (arvalid                       ),
        .arready                 (arready                       ),
        .araddr                  (araddr                        ),
        .rvalid                  (rvalid                        ),
        .rlast                   (rlast                         ),
        .rdata                   (rdata                         )
    );

    sync_generator u_sync(
        .clk                     (pixel_clk                     ),
        .rstn                    (rst_n                         ),
        .vs_out                  (vs                            ),
        .hs_out                  (hs                            ),
        .de_out                  (de                            ),
        .de_re                   (                              ),
        .x_act                   (x                             ),
        .y_act                   (y                             )
    );

    panorama_bmp_writer#(
        .HEIGHT                  (1080                          ),
        .OUTPUT_ARG              ("NORMAL_OUTPUT"               ),
        .PIC_PATH                ("sim/panorama/results/missing_sfp/fusion_before.bmp")
    )u_normal(
        .clk                     (pixel_clk                     ),
        .valid                   (normal_write                  ),
        .rgb                     (image_pixel                   )
    );

    panorama_bmp_writer#(
        .HEIGHT                  (1080                          ),
        .OUTPUT_ARG              ("INVERSE_OUTPUT"              ),
        .PIC_PATH                ("sim/panorama/results/missing_sfp/quad_missing.bmp")
    )u_inverse(
        .clk                     (pixel_clk                     ),
        .valid                   (inverse_write                 ),
        .rgb                     (image_pixel                   )
    );

    panorama_bmp_writer#(
        .HEIGHT                  (1080                          ),
        .OUTPUT_ARG              ("CONNECTED_OUTPUT"             ),
        .PIC_PATH                ("sim/panorama/results/missing_sfp/quad_sfp_ready.bmp")
    )u_connected(
        .clk                     (pixel_clk                     ),
        .valid                   (connected_write               ),
        .rgb                     (image_pixel                   )
    );

    initial begin
        mask_versions[0] = 0;
        mask_versions[1] = 0;
        versions[0] = -1;
        versions[1] = -1;
        quad_versions[0] = -1;
        quad_versions[1] = -1;
        $readmemh("sim/panorama/reference/fusion_rgb.hex", expected, 0, 1036799);
        $readmemh("sim/panorama/reference/complement_rgb.hex", expected, 1036800, 2073599);
        $readmemh("sim/panorama/reference/left_rgb.hex", source_ref, 0, 518399);
        $readmemh("sim/panorama/reference/center_rgb.hex", source_ref, 518400, 1036799);
        $readmemh("sim/panorama/reference/right_rgb.hex", source_ref, 1036800, 1555199);
        $readmemh("sim/panorama/reference/fourth_rgb.hex", source_ref, 1555200, 2073599);
        #0.1 rst_n = 1;
        #0.1 rst_n = 0;
        repeat(10) @(negedge clk);
        rst_n = 1;
        for(integer camera = 0; camera < 4; camera = camera + 1)begin
            load_enable[camera] = 1;
            repeat(11) @(negedge clk);
        end
        wait(good_normal_frames >= 1);
        wait(de && y == 100);
        key_level(0);
        if(!requested_quad) $fatal(1, "Key did not request quad");
        // No SFP from startup: quad must display and continue to accept new source pages.
        wait(missing_normal_frames >= 2);
        if(!requested_quad || requested_changes != 1) $fatal(1, "Held key retriggered");
        source_pages = 8'h1b;
        wait(missing_changed_frames >= 2);
        // Make SFP valid in the middle of a render: it may only appear in a later complete result.
        wait(dut.render_quad && dut.state == 2 && write_pixels > 100000 && write_pixels < 1000000);
        @(negedge clk);
        available = 4'hf;
        wait(full_quad_frames >= 2);
        key_level(1);
        if(requested_changes != 1) $fatal(1, "Release toggled mode");
        wait(de && y == 200);
        key_level(0);
        if(requested_quad || requested_changes != 2) $fatal(1, "Second press did not request fusion");
        wait(good_return_frames >= 2);
        if(errors != 0 || underruns != 0 || capture_bursts < 100 || !u_normal.image_saved || !u_inverse.image_saved || !u_connected.image_saved)
            $fatal(1, "Mode switch output failed");
        test_passed = 1;
        $display("PASS missing integration: fusion=%0d missing_quad=%0d missing_updated=%0d full_quad=%0d returned=%0d renders=%0d underruns=%0d captures=%0d cycles=%0d",
                 good_normal_frames, missing_normal_frames, missing_changed_frames, full_quad_frames,
                 good_return_frames, rendered_frames, underruns, capture_bursts, cycles);
        $finish;
    end

    always@(posedge clk)begin
        if(rst_n)begin
            cycles = cycles + 1;
            lock_granted <= lock_valid;
            if(loaded && !capture_busy && !capture_awvalid && cycles % 128 == 0) capture_awvalid <= 1;
            if(capture_awvalid && capture_awready)begin
                capture_awvalid <= 0;
                capture_busy <= 1;
                capture_beat <= 0;
            end
            if(capture_wready)begin
                if(capture_wlast != (capture_beat == 8)) $fatal(1, "Capture WLAST misrouting");
                if(capture_wlast)begin
                    capture_busy <= 0;
                    capture_bursts = capture_bursts + 1;
                end
                else capture_beat <= capture_beat + 1;
            end
            if(dut.render_start)begin
                render_start_cycle = cycles;
                render_phase = dut.lock_pages == 8'he4 ? 0 : 1;
                write_pixels = 0;
                result_bursts = 0;
                render_source_mask = dut.render_quad ? available : 4'h7;
                if(lock_valid !== render_source_mask || dut.render_sources !== render_source_mask)
                    $fatal(1, "Wrong source/lock mask");
            end
            if(dut.state == 2 && dut.render_sources !== render_source_mask) $fatal(1, "Source mask changed during render");
            if(dut.u_quad.arvalid && dut.u_quad.arready && !render_source_mask[dut.u_quad.araddr[23 : 22]])
                $fatal(1, "DDR request for missing SFP source");
            if(awvalid && awready)begin
                model_write_owner = awaddr[27 : 24] == 1;
                if(awlen != (model_write_owner ? 7 : 8)) $fatal(1, "AWLEN mismatch");
                model_write_address = awaddr;
                model_write_beat = 0;
                if(model_write_owner)begin
                    if(dut.display_valid && awaddr[20] == dut.display_buffer)
                        $fatal(1, "Overwrote displayed result");
                    if(awaddr[19 : 0] != result_bursts * 64) $fatal(1, "Write address order mismatch");
                    result_bursts = result_bursts + 1;
                end
            end
            if(wready)begin
                if(wlast != (model_write_beat == (model_write_owner ? 7 : 8))) $fatal(1, "WLAST mismatch");
                if(model_write_owner)begin
                    if(dut.render_quad)begin
                        for(integer j = 0; j < 16; j = j + 1)begin
                            quad_expected = quad_pixel_at(write_pixels % 1920, write_pixels / 1920, render_phase, render_source_mask);
                            if(wdata[j * 16 +: 16] !== {quad_expected[23:19], quad_expected[15:10], quad_expected[7:3]})
                                $fatal(1, "Quad DDR write mismatch index=%0d", write_pixels);
                            write_pixels = write_pixels + 1;
                        end
                    end
                    else begin
                        for(integer j = 0; j < 8; j = j + 1)begin
                            if(wdata[j * 32 +: 32] !== {8'd0, expected[render_phase * 1036800 + write_pixels]})
                                $fatal(1, "Fusion DDR write mismatch index=%0d", write_pixels);
                            write_pixels = write_pixels + 1;
                        end
                    end
                end
                model_write_beat = model_write_beat + 1;
            end
            if(dut.u_writer.done)begin
                if(write_pixels != (dut.render_quad ? 2073600 : 1036800) || result_bursts != 16200)
                    $fatal(1, "Premature publication");
                mask_versions[dut.render_buffer] = render_source_mask;
                versions[dut.render_buffer] = render_phase;
                quad_versions[dut.render_buffer] = dut.render_quad;
                $display("COMMIT quad=%0d phase=%0d bank=%0d cycles=%0d", dut.render_quad, render_phase, dut.render_buffer, cycles);
            end
            if(errors != 0 || underruns != 0) $fatal(1, "Protocol error/underrun errors=%0d underruns=%0d", errors, underruns);
            if(cycles % 10000000 == 0) $display("PROGRESS cycles=%0d mode=%0d renders=%0d", cycles, mode_active, rendered_frames);
            if(cycles > 100000000) $fatal(1, "Mode simulation timeout");
        end
    end

    always@(posedge pixel_clk)begin
        pixel_check_enable <= rst_n && dut.u_reader.pixel_reset_n;
        expected_vs <= vs;
        expected_hs <= hs;
        expected_de <= de;
        expected_x <= x;
        expected_y <= y;
        #0.1;
        normal_write <= 0;
        inverse_write <= 0;
        connected_write <= 0;
        if(pixel_check_enable)begin
            if(video_vs !== expected_vs || video_hs !== expected_hs || video_de !== expected_de)
                $fatal(1, "HDMI timing alignment mismatch");
            if(video_vs && !output_vs_d)begin
                if(panel_started)begin
                    if(panel_count != 2073600) $fatal(1, "Panel frame size mismatch");
                    if(panel_show)begin
                        if(panel_quad)begin
                            good_inverse_frames = good_inverse_frames + 1;
                            if(panel_sources[3]) full_quad_frames = full_quad_frames + 1;
                            else if(panel_phase == 0) missing_normal_frames = missing_normal_frames + 1;
                            else missing_changed_frames = missing_changed_frames + 1;
                        end
                        else if(panel_phase == 0) good_normal_frames = good_normal_frames + 1;
                        else good_return_frames = good_return_frames + 1;
                        $display("DISPLAY quad=%0d phase=%0d frame=%0d", panel_quad, panel_phase, panel_frame);
                    end
                    else black_frames = black_frames + 1;
                end
                panel_started = 1;
                panel_frame = panel_frame + 1;
                panel_count = 0;
            end
            output_vs_d = video_vs;
            if(video_de)begin
                if(panel_count == 0)begin
                    panel_show = dut.u_reader.frame_show;
                    panel_bank = dut.display_buffer;
                    panel_phase = versions[panel_bank];
                    panel_sources = mask_versions[panel_bank];
                    panel_quad = mode_active;
                    if(panel_show && (panel_phase < 0 || panel_quad != quad_versions[panel_bank]))
                        $fatal(1, "Incomplete/mismatched format displayed");
                end
                if(panel_show && (dut.display_buffer != panel_bank || mode_active != panel_quad))
                    $fatal(1, "Buffer or mode changed during active frame");
                target_pixel = 0;
                if(panel_show)begin
                    if(panel_quad) target_pixel = quad_pixel_at(expected_x, expected_y, panel_phase, panel_sources);
                    else if(expected_y < 540) target_pixel = expected[panel_phase * 1036800 + expected_y * 1920 + expected_x];
                end
                if(video_rgb !== target_pixel)
                    $fatal(1, "Video mismatch quad=%0d phase=%0d xy=%0d,%0d got=%h expected=%h", panel_quad, panel_phase, expected_x, expected_y, video_rgb, target_pixel);
                if(panel_show && !panel_quad && panel_phase == 0 && good_normal_frames == 0) normal_write <= 1;
                if(panel_show && panel_quad && good_inverse_frames == 0) inverse_write <= 1;
                if(panel_show && panel_quad && panel_sources[3] && full_quad_frames == 0) connected_write <= 1;
                image_pixel <= video_rgb;
                panel_count = panel_count + 1;
            end
        end
    end
endmodule
