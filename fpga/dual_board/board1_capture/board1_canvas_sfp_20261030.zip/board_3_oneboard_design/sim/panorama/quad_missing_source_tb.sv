`timescale 1ns/1ps
module quad_missing_source_tb;
    reg                     clk = 0;
    reg                     rst_n = 0;
    reg                     start = 0;
    reg         [7 : 0]     pages = 8'he4;
    reg         [7 : 0]     expected_pages;
    reg         [3 : 0]     valid_mask = 4'h7;
    reg         [3 : 0]     expected_mask;
    integer                 reads_at_start;
    wire                    busy;
    wire                    done;
    wire                    out_valid;
    wire                    out_ready;
    wire        [23 : 0]    out_rgb;
    wire                    arvalid;
    wire                    arready;
    wire        [27 : 0]    araddr;
    reg                     rvalid = 0;
    reg                     rlast = 0;
    reg         [255 : 0]   rdata = 0;
    wire        [31 : 0]    errors;
    reg                     pending = 0;
    reg         [27 : 0]    address;
    integer                 delay_count = 0;
    integer                 beat = 0;
    integer                 cycles = 0;
    integer                 reads = 0;
    integer                 pixels = 0;
    integer                 px;
    integer                 py;
    integer                 camera;
    integer                 index;
    reg         [15 : 0]    raw;
    reg         [23 : 0]    expected;
    reg                     stalled = 0;
    reg         [23 : 0]    stalled_rgb;
    reg                     test_passed = 0;

    always #5 clk = ~clk;
    assign arready = !pending && !rvalid && cycles % 7 != 0;
    assign out_ready = cycles % 1024 >= 127 && cycles % 11 != 0;

    function [15 : 0] value_for;
        input integer channel;
        input integer page;
        input integer offset;
        begin
            value_for = (offset * 16'h1327) ^ (channel * 16'h2311) ^ (page * 16'h8003);
        end
    endfunction

    quad_frame_renderer#(
        .SOURCE_MASK_ENABLE (1)
    )dut(
        .clk             (clk         ),
        .rst_n           (rst_n       ),
        .start           (start       ),
        .frame_pages     (pages       ),
        .frame_valid     (valid_mask  ),
        .busy            (busy        ),
        .done            (done        ),
        .out_valid       (out_valid   ),
        .out_ready       (out_ready   ),
        .out_rgb         (out_rgb     ),
        .arvalid         (arvalid     ),
        .arready         (arready     ),
        .araddr          (araddr      ),
        .rvalid          (rvalid      ),
        .rlast           (rlast       ),
        .rdata           (rdata       ),
        .errors          (errors      )
    );

    task run_frame;
        input [3 : 0] mask;
        input [7 : 0] page_select;
        input integer expected_reads;
        begin
            @(negedge clk);
            pixels = 0;
            reads_at_start = reads;
            expected_mask = mask;
            expected_pages = page_select;
            valid_mask = mask;
            pages = page_select;
            start = 1;
            @(negedge clk);
            start = 0;
            repeat(1000) @(negedge clk);
            // Changes and a second start while busy must not affect this frame.
            valid_mask = ~mask;
            pages = ~page_select;
            start = 1;
            @(negedge clk);
            start = 0;
            wait(done);
            @(negedge clk);
            if(pixels != 2073600 || errors != 0 || reads - reads_at_start != expected_reads)
                $fatal(1, "Missing-input frame failed mask=%h pixels=%0d reads=%0d", mask, pixels, reads - reads_at_start);
            $display("PASS quad mask=%h: 2073600 pixels checked, reads=%0d", mask, reads - reads_at_start);
        end
    endtask

    initial begin
        repeat(5) @(negedge clk);
        rst_n = 1;
        // With the right-bottom quadrant absent, 270 left-bottom row-edge bursts stay cached.
        run_frame(4'h7, 8'he4, 12690);
        run_frame(4'hf, 8'h1b, 17280);
        run_frame(4'h0, 8'he4, 0);
        test_passed = 1;
        $display("PASS missing unit: black SFP quadrant, restored input, no-input black frame, mask/page snapshots and stalls");
        $finish;
    end

    always@(posedge clk)begin
        if(rst_n)begin
            cycles = cycles + 1;
            rvalid <= 0;
            rlast <= 0;
            if(arvalid && arready)begin
                if(!expected_mask[araddr[23 : 22]]) $fatal(1, "Read missing input");
                if(araddr[21 : 20] !== expected_pages[araddr[23 : 22] * 2 +: 2]) $fatal(1, "Read unlocked page");
                if(araddr[27 : 24] != 0 || araddr[5 : 0] != 0 || araddr[19 : 0] * 2 + 127 >= 518400)
                    $fatal(1, "Invalid source burst address %h", araddr);
                address <= araddr;
                beat <= 0;
                pending <= 1;
                delay_count <= 26 + reads % 6;
                reads = reads + 1;
            end
            if(pending)begin
                if(delay_count != 0) delay_count <= delay_count - 1;
                else if(cycles % 7 != 0)begin
                    rvalid <= 1;
                    rlast <= beat == 7;
                    for(integer lane = 0; lane < 16; lane = lane + 1)
                        rdata[lane * 16 +: 16] <= value_for(address[23 : 22], address[21 : 20],
                                                          address[19 : 0] * 2 + beat * 16 + lane);
                    if(beat == 7) pending <= 0;
                    else beat <= beat + 1;
                end
            end
            if(stalled && (!out_valid || out_rgb !== stalled_rgb))
                $fatal(1, "Quad output changed under backpressure");
            stalled = out_valid && !out_ready;
            stalled_rgb = out_rgb;
            if(out_valid && out_ready)begin
                px = pixels % 1920;
                py = pixels / 1920;
                camera = (py >= 540 ? 2 : 0) + (px >= 960 ? 1 : 0);
                index = (py % 540) * 960 + px % 960;
                raw = value_for(camera, expected_pages[camera * 2 +: 2], index);
                expected = expected_mask[camera] ?
                           {raw[15 : 11], 3'b0, raw[10 : 5], 2'b0, raw[4 : 0], 3'b0} : 24'd0;
                if(out_rgb !== expected) $fatal(1, "Quad pixel mismatch index=%0d got=%h expected=%h", pixels, out_rgb, expected);
                pixels = pixels + 1;
            end
            if(errors != 0 || cycles > 30000000) $fatal(1, "Quad failure/timeout");
        end
    end
endmodule
