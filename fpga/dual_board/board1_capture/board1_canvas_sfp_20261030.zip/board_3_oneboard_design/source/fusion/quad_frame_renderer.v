// Copy four locked 960x540 RGB565 source pages into a 1920x1080 RGB888 stream.
// One aligned 128-pixel DDR burst is cached; pixels are emitted in raster order.
module quad_frame_renderer#(
    parameter   SOURCE_MASK_ENABLE           =   0,
    parameter   BOTTOM_CENTER_ENABLE         =   0
)(
    input                   clk,
    input                   rst_n,
    input                   start,
    input                   bottom_center,
    input       [7 : 0]     frame_pages,
    input       [3 : 0]     frame_valid,
    output                  busy,
    output reg              done,
    output                  out_valid,
    input                   out_ready,
    output      [23 : 0]    out_rgb,
    output                  arvalid,
    input                   arready,
    output      [27 : 0]    araddr,
    input                   rvalid,
    input                   rlast,
    input       [255 : 0]   rdata,
    output reg  [31 : 0]    errors
);
    localparam  IDLE                         =   3'd0;
    localparam  LOOKUP                       =   3'd1;
    localparam  ADDRESS                      =   3'd2;
    localparam  DATA                         =   3'd3;
    localparam  PIXELS                       =   3'd4;
    localparam  FAILED                       =   3'd5;
    reg         [2 : 0]     state;
    reg         [7 : 0]     pages;
    reg         [3 : 0]     sources;
    reg                     bottom_layout;
    wire                    region_present;
    wire                    region_end;
    reg         [10 : 0]    x;
    reg         [10 : 0]    y;
    reg         [2 : 0]     beat;
    reg                     cache_valid;
    reg         [27 : 0]    cache_address;
    reg         [255 : 0]   cache[0 : 7];
    reg         [255 : 0]   word_data;
    wire        [1 : 0]     channel;
    wire        [1 : 0]     page;
    wire        [9 : 0]     local_x;
    wire        [9 : 0]     local_y;
    wire        [18 : 0]    source_index;
    wire        [27 : 0]    request_address;
    wire        [15 : 0]    raw_pixel;
    wire                    source_present;

    assign channel         = bottom_layout ? 2'd3 : {y >= 540, x >= 960};
    assign page            = pages[channel * 2 +: 2];
    assign region_present  = !bottom_layout || (x >= 480 && x < 1440);
    assign region_end      = bottom_layout ? (x == 479 || x == 1439) : x == 959;
    assign source_present  = region_present && sources[channel];
    assign local_x         = bottom_layout ? x - 11'd480 : (x >= 960 ? x - 11'd960 : x);
    assign local_y         = y >= 540 ? y - 11'd540 : y;
    assign source_index    = local_y * 19'd960 + local_x;
    assign request_address = {4'd0, channel, page, 20'd0} + {10'd0, source_index[18 : 7], 6'd0};
    assign arvalid         = state == ADDRESS;
    assign araddr          = cache_address;
    assign busy            = state != IDLE;
    assign out_valid       = state == PIXELS;
    assign raw_pixel       = word_data[source_index[3 : 0] * 16 +: 16];
    assign out_rgb         = source_present ?
                             {raw_pixel[15 : 11], 3'd0, raw_pixel[10 : 5], 2'd0,
                              raw_pixel[4 : 0], 3'd0} : 24'd0;

    always@(posedge clk)begin
        if(state == DATA && rvalid)begin
            cache[beat] <= rdata;
        end
        if(state == LOOKUP && source_present && cache_valid && cache_address == request_address)begin
            word_data <= cache[source_index[6 : 4]];
        end
        else if(state == PIXELS && source_present && out_ready && source_index[3 : 0] == 15 &&
                source_index[6 : 4] != 7 && !region_end && x != 1919)begin
            word_data <= cache[source_index[6 : 4] + 3'd1];
        end
    end

    always@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            state         <= IDLE;
            pages         <= 0;
            sources       <= 4'hf;
            bottom_layout <= 0;
            x             <= 0;
            y             <= 0;
            beat          <= 0;
            cache_valid   <= 0;
            cache_address <= 0;
            done          <= 0;
            errors        <= 0;
        end
        else begin
            done <= 0;
            case(state)
                IDLE:begin
                    if(start)begin
                        pages       <= frame_pages;
                        sources     <= SOURCE_MASK_ENABLE ? frame_valid : 4'hf;
                        x           <= 0;
                        y           <= BOTTOM_CENTER_ENABLE && bottom_center ? 11'd540 : 11'd0;
                        bottom_layout <= BOTTOM_CENTER_ENABLE && bottom_center;
                        cache_valid <= 0;
                        state       <= LOOKUP;
                    end
                end
                LOOKUP:begin
                    // Missing input: emit a black quadrant without a DDR request.
                    if(!source_present)begin
                        state <= PIXELS;
                    end
                    else if(cache_valid && cache_address == request_address)begin
                        state <= PIXELS;
                    end
                    else begin
                        cache_address <= request_address;
                        cache_valid   <= 0;
                        state         <= ADDRESS;
                    end
                end
                ADDRESS:begin
                    if(arready)begin
                        beat  <= 0;
                        state <= DATA;
                    end
                end
                DATA:begin
                    if(rvalid)begin
                        if(rlast != (beat == 7))begin
                            errors <= errors + 1'b1;
                            state  <= FAILED;
                        end
                        else if(beat == 7)begin
                            cache_valid <= 1;
                            state       <= LOOKUP;
                        end
                        else begin
                            beat <= beat + 1'b1;
                        end
                    end
                end
                PIXELS:begin
                    if(out_ready)begin
                        if(x == 1919)begin
                            x <= 0;
                            if(y == 1079)begin
                                done  <= 1;
                                state <= IDLE;
                            end
                            else begin
                                y     <= y + 1'b1;
                                state <= LOOKUP;
                            end
                        end
                        else begin
                            x <= x + 1'b1;
                            if(region_end || (source_present && source_index[6 : 0] == 127))begin
                                state <= LOOKUP;
                            end
                        end
                    end
                end
                FAILED:begin
                    state <= FAILED;
                end
                default:begin
                    state <= IDLE;
                end
            endcase
        end
    end
endmodule
