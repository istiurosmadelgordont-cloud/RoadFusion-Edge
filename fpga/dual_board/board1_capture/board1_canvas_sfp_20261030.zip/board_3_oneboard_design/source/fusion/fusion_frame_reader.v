// Prefetch a completed RGB888 frame from DDR; repeat it at the video frame rate.
// A frame request crosses to DDR at VS. FIFO reset/re-prime occurs during blanking.
module fusion_frame_reader#(
    parameter   FRAME_PIXELS                 =   1036800,
    parameter   FRAME_HEIGHT                 =   540,
    parameter   BUFFER0                      =   28'h1000000,
    parameter   BUFFER1                      =   28'h1100000,
    parameter   MODE_SWITCH_ENABLE           =   0,
    parameter   FULL_CANVAS_ENABLE           =   0
)(
    input                   clk,
    input                   rst_n,
    input                   published_valid,
    input                   published_buffer,
    input                   published_quad,
    output reg              display_valid,
    output reg              display_buffer,
    output reg              display_quad,
    output                  video_quad,
    output                  read_urgent,
    output                  arvalid,
    input                   arready,
    output      [27 : 0]    araddr,
    input                   rvalid,
    input                   rlast,
    input       [255 : 0]   rdata,
    input                   pixel_clk,
    input                   vs,
    input                   hs,
    input                   de,
    input       [11 : 0]    pixel_y,
    output reg              video_vs,
    output reg              video_hs,
    output reg              video_de,
    output reg  [23 : 0]    video_rgb,
    output reg  [31 : 0]    protocol_errors,
    output reg  [31 : 0]    underrun_count
);
    localparam  WAIT_FRAME                   =   3'd0;
    localparam  PREFETCH                     =   3'd1;
    localparam  ADDRESS                      =   3'd2;
    localparam  DATA                         =   3'd3;
    localparam  RESET_FIFO                   =   3'd4;
    localparam  WARMUP                       =   3'd5;
    localparam  FAILED                       =   3'd6;
    reg         [2 : 0]     state;
    reg         [20 : 0]    offset;
    reg         [3 : 0]     delay_count;
    reg         [2 : 0]     beat;
    reg                     fifo_release;
    reg                     request_toggle;
    (* syn_preserve = 1 *) reg request_s0;
    (* syn_preserve = 1 *) reg request_s1;
    reg                     request_seen;
    reg                     pending_request;
    reg                     refill_active;
    (* syn_preserve = 1 *) reg display_valid_s0;
    (* syn_preserve = 1 *) reg display_valid_s1;
    wire                    fifo_wr_ready;
    wire        [8 : 0]     fifo_level /* synthesis PAP_MARK_DEBUG="1" */;
    wire                    fifo_rd_valid /* synthesis PAP_MARK_DEBUG="1" */;
    wire                    fifo_rd_ready;
    wire        [255 : 0]   fifo_rd_data;
    reg         [3 : 0]     pixel_lane /* synthesis PAP_MARK_DEBUG="1" */;
    reg                     vs_d;
    reg                     first_pixel_seen;
    reg                     frame_show /* synthesis PAP_MARK_DEBUG="1" */;
    reg                     frame_bad /* synthesis PAP_MARK_DEBUG="1" */;
    (* syn_preserve = 1 *) reg [1 : 0] pixel_reset_sync;
    wire                    pixel_reset_n /* synthesis PAP_MARK_DEBUG="1" */;
    (* syn_preserve = 1 *) reg display_quad_s0;
    (* syn_preserve = 1 *) reg display_quad_s1;
    reg                     frame_quad;
    wire        [15 : 0]    quad_pixel;
    wire                    upper_pixel;
    wire                    packed_rgb565;
    wire                    showing;
    wire                    pop_pixel;

    // Reserve new read grants at or below 96 words until 192 words are buffered.
    // One FIFO word contains eight pixels; the write-side count is conservative.
    assign read_urgent   = refill_active && display_valid && fifo_release &&
                           offset < FRAME_PIXELS && !pending_request && state != FAILED;
    assign arvalid       = state == ADDRESS;
    assign araddr        = (display_buffer ? BUFFER1 : BUFFER0) + offset;
    assign video_quad    = frame_quad;
    assign packed_rgb565 = FULL_CANVAS_ENABLE || frame_quad;
    assign upper_pixel   = de && pixel_y < (packed_rgb565 ? 12'd1080 : FRAME_HEIGHT);
    assign showing       = (first_pixel_seen ? frame_show : display_valid_s1) && !frame_bad;
    assign pop_pixel     = upper_pixel && showing && fifo_rd_valid;
    assign fifo_rd_ready = pop_pixel && pixel_lane == (packed_rgb565 ? 4'd15 : 4'd7);
    assign quad_pixel    = fifo_rd_data[pixel_lane * 16 +: 16];
    assign pixel_reset_n = pixel_reset_sync[1];

    always@(posedge pixel_clk or negedge rst_n)begin
        if(!rst_n)begin
            pixel_reset_sync <= 0;
        end
        else begin
            pixel_reset_sync <= {pixel_reset_sync[0], 1'b1};
        end
    end

    fusion_async_fifo u_fifo(
        .reset_n                (rst_n && fifo_release      ),
        .wr_clk                 (clk                        ),
        .wr_valid               (state == DATA && rvalid    ),
        .wr_ready               (fifo_wr_ready              ),
        .wr_data                (rdata                      ),
        .wr_level               (fifo_level                 ),
        .rd_clk                 (pixel_clk                  ),
        .rd_valid               (fifo_rd_valid              ),
        .rd_ready               (fifo_rd_ready              ),
        .rd_data                (fifo_rd_data               )
    );

    always@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            state           <= WAIT_FRAME;
            offset          <= 0;
            delay_count     <= 0;
            beat            <= 0;
            fifo_release    <= 0;
            request_s0      <= 0;
            request_s1      <= 0;
            request_seen    <= 0;
            pending_request <= 0;
            refill_active   <= 0;
            display_valid   <= 0;
            display_buffer  <= 0;
            display_quad    <= 0;
            protocol_errors <= 0;
        end
        else begin
            request_s0 <= request_toggle;
            request_s1 <= request_s0;
            if(request_s1 != request_seen)begin
                request_seen    <= request_s1;
                pending_request <= 1;
            end
            if(!display_valid || !fifo_release || pending_request ||
               offset >= FRAME_PIXELS || state == FAILED)begin
                refill_active <= 0;
            end
            else if(fifo_level <= 96)begin
                refill_active <= 1;
            end
            else if(fifo_level >= 192)begin
                refill_active <= 0;
            end
            case(state)
                WAIT_FRAME, PREFETCH:begin
                    if(pending_request)begin
                        pending_request <= 0;
                        fifo_release    <= 0;
                        delay_count     <= 8;
                        state           <= RESET_FIFO;
                    end
                    else if(state == PREFETCH && display_valid && offset < FRAME_PIXELS && fifo_level < 192)begin
                        state <= ADDRESS;
                    end
                end
                ADDRESS:begin
                    if(arready)begin
                        beat  <= 0;
                        state <= DATA;
                    end
                end
                DATA:begin
                    if(rvalid)begin
                        if(!fifo_wr_ready || rlast != (beat == 7))begin
                            protocol_errors <= protocol_errors + 1'b1;
                            state <= FAILED;
                        end
                        else if(beat == 7)begin
                            offset <= offset + 21'd64;
                            // Chain the next burst without a PREFETCH request bubble.
                            // Finish an outstanding read before handling a new VS.
                            if(!pending_request && request_s1 == request_seen &&
                               offset + 21'd64 < FRAME_PIXELS && fifo_level < 192)begin
                                state <= ADDRESS;
                            end
                            else begin
                                state <= PREFETCH;
                            end
                        end
                        else begin
                            beat <= beat + 1'b1;
                        end
                    end
                end
                RESET_FIFO:begin
                    if(delay_count == 0)begin
                        display_valid  <= published_valid;
                        display_buffer <= published_buffer;
                        display_quad   <= MODE_SWITCH_ENABLE && published_quad;
                        offset         <= 0;
                        fifo_release   <= 1;
                        delay_count    <= 4;
                        state          <= WARMUP;
                    end
                    else begin
                        delay_count <= delay_count - 1'b1;
                    end
                end
                WARMUP:begin
                    if(delay_count == 0)begin
                        state <= PREFETCH;
                    end
                    else begin
                        delay_count <= delay_count - 1'b1;
                    end
                end
                FAILED:begin
                    state <= FAILED;
                end
                default:begin
                    state <= WAIT_FRAME;
                end
            endcase
        end
    end

    always@(posedge pixel_clk or negedge pixel_reset_n)begin
        if(!pixel_reset_n)begin
            request_toggle  <= 0;
            display_valid_s0 <= 0;
            display_valid_s1 <= 0;
            display_quad_s0 <= 0;
            display_quad_s1 <= 0;
            frame_quad      <= 0;
            pixel_lane      <= 0;
            vs_d            <= 0;
            first_pixel_seen <= 0;
            frame_show      <= 0;
            frame_bad       <= 0;
            video_vs        <= 0;
            video_hs        <= 0;
            video_de        <= 0;
            video_rgb       <= 0;
            underrun_count  <= 0;
        end
        else begin
            display_valid_s0 <= display_valid;
            display_valid_s1 <= display_valid_s0;
            display_quad_s0 <= display_quad;
            display_quad_s1 <= display_quad_s0;
            // Mode follows the selected complete buffer during vertical blanking.
            // Hold it throughout the active frame.
            if(!first_pixel_seen && !de)begin
                frame_quad <= display_quad_s1;
            end
            vs_d     <= vs;
            video_vs <= vs;
            video_hs <= hs;
            video_de <= de;
            video_rgb <= 0;
            if(vs && !vs_d)begin
                request_toggle   <= ~request_toggle;
                pixel_lane       <= 0;
                first_pixel_seen <= 0;
                frame_show       <= 0;
                frame_bad        <= 0;
            end
            else if(upper_pixel)begin
                if(!first_pixel_seen)begin
                    first_pixel_seen <= 1;
                    frame_show <= display_valid_s1 && fifo_rd_valid;
                end
                if(showing)begin
                    if(fifo_rd_valid)begin
                        if(packed_rgb565)begin
                            video_rgb <= {quad_pixel[15 : 11], 3'd0, quad_pixel[10 : 5], 2'd0,
                                          quad_pixel[4 : 0], 3'd0};
                        end
                        else begin
                            video_rgb <= fifo_rd_data[pixel_lane * 32 +: 24];
                        end
                        pixel_lane <= fifo_rd_ready ? 4'd0 : pixel_lane + 1'b1;
                    end
                    else begin
                        frame_bad      <= 1;
                        underrun_count <= underrun_count + 1'b1;
                    end
                end
            end
        end
    end
endmodule
