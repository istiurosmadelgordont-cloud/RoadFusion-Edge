// Pango DDR addresses count 32-bit words. One beat contains sixteen RGB565 pixels.
// Fixed eight-beat bursts; row-parity banks read all four neighbours in parallel.
module fusion_ddr_sampler#(
    parameter   LEFT_CHANNEL                 =   0,
    parameter   CENTER_CHANNEL               =   1,
    parameter   RIGHT_CHANNEL                =   2
)(
    input                   clk,
    input                   rst_n,
    input                   flush,
    input       [7 : 0]     frame_pages,
    input                   req_valid,
    output                  req_ready,
    input       [107 : 0]   req_uv,
    input       [2 : 0]     req_mask,
    output                  rsp_valid,
    input                   rsp_ready,
    output      [287 : 0]   rsp_pixels,
    output                  arvalid,
    input                   arready,
    output      [27 : 0]    araddr,
    input                   rvalid,
    input                   rlast,
    input       [255 : 0]   rdata,
    output reg  [31 : 0]    burst_count,
    output reg  [31 : 0]    protocol_errors
);

    localparam  IDLE                         =   3'd0;
    localparam  CHECK_POINTS                 =   3'd1;
    localparam  PUBLISH                      =   3'd2;
    localparam  READ_ADDRESS                 =   3'd3;
    localparam  FILL_CACHE                   =   3'd4;
    localparam  RESPOND                      =   3'd5;
    localparam  FAILED                       =   3'd6;
    localparam  PREPARE_INDEX                =   3'd7;

    reg         [2 : 0]     state;
    reg         [107 : 0]   uv;
    reg         [2 : 0]     remaining;
    reg         [7 : 0]     pages;
    reg         [1 : 0]     camera;
    reg         [287 : 0]   saved_pixels;
    reg         [287 : 0]   assembled_pixels;
    reg         [27 : 0]    miss_address;
    reg         [4 : 0]     miss_line;
    reg         [2 : 0]     beat;
    reg         [31 : 0]    cache_valid;
    (* syn_ramstyle = "registers" *) reg [21 : 0] cache_tag[0 : 31];
    (* syn_ramstyle = "block_ram" *) reg [255 : 0] cache_even[0 : 127];
    (* syn_ramstyle = "block_ram" *) reg [255 : 0] cache_odd[0 : 127];
    reg         [255 : 0]   even_word0;
    reg         [255 : 0]   even_word1;
    reg         [255 : 0]   odd_word0;
    reg         [255 : 0]   odd_word1;
    reg         [9 : 0]     point_x[0 : 3];
    reg         [9 : 0]     point_y[0 : 3];
    reg         [19 : 0]    pixel_index[0 : 3];
    reg         [27 : 0]    word_address[0 : 3];
    reg         [4 : 0]     cache_line[0 : 3];
    reg         [3 : 0]     hit;
    reg         [1 : 0]     channel;
    reg         [1 : 0]     first_missing;
    reg         [6 : 0]     even_address0;
    reg         [6 : 0]     even_address1;
    reg         [6 : 0]     odd_address0;
    reg         [6 : 0]     odd_address1;
    wire        [2 : 0]     next_remaining;
    wire                    last_camera;
    wire                    read_cache;
    wire        [6 : 0]     fill_address;
    reg         [255 : 0]   selected_word[0 : 3];
    reg         [15 : 0]    selected_pixel[0 : 3];
    reg         [9 : 0]     prepared_x[0 : 11];
    reg         [9 : 0]     prepared_y[0 : 11];
    reg         [19 : 0]    prepared_index[0 : 11];
    integer                 point;
    integer                 prepare_point;

    function [1 : 0] first_camera;
        input   [2 : 0] valid_mask;
        begin
            if(valid_mask[0])begin
                first_camera = 0;
            end
            else if(valid_mask[1])begin
                first_camera = 1;
            end
            else begin
                first_camera = 2;
            end
        end
    endfunction

    assign req_ready      = state == IDLE && !flush;
    assign rsp_valid      = state == RESPOND;
    assign rsp_pixels     = saved_pixels;
    assign arvalid        = state == READ_ADDRESS;
    assign araddr         = {miss_address[27 : 6], 6'd0};
    assign next_remaining = remaining & ~(3'b001 << camera);
    assign last_camera    = next_remaining == 0;
    // Speculative reads are consumed only after all tags hit. Miss reads
    // are discarded; the BRAM enable no longer depends on address/tag arithmetic.
    assign read_cache     = state == CHECK_POINTS;
    assign fill_address   = {miss_line[4 : 3], miss_line[1 : 0], beat};

    always@(*)begin
        case(camera)
            2'd0: channel = LEFT_CHANNEL;
            2'd1: channel = CENTER_CHANNEL;
            default: channel = RIGHT_CHANNEL;
        endcase
        for(point = 0; point < 4; point = point + 1)begin
            point_x[point] = prepared_x[camera * 4 + point];
            point_y[point] = prepared_y[camera * 4 + point];
            pixel_index[point] = prepared_index[camera * 4 + point];
            word_address[point] = {4'd0, channel, pages[channel * 2 +: 2], 20'd0} |
                                  {9'd0, pixel_index[point][19 : 1]};
            cache_line[point] = {camera, point_y[point][0], pixel_index[point][8 : 7]};
            hit[point] = cache_valid[cache_line[point]] &&
                         cache_tag[cache_line[point]] == word_address[point][27 : 6];
        end
        if(!hit[0])begin
            first_missing = 0;
        end
        else if(!hit[1])begin
            first_missing = 1;
        end
        else if(!hit[2])begin
            first_missing = 2;
        end
        else begin
            first_missing = 3;
        end

        // Each parity bank is a true dual-port RAM. Horizontal neighbours may
        // cross a 256-bit beat or burst; the two ports have independent addresses.
        even_address0 = {cache_line[0][4 : 3], cache_line[0][1 : 0], word_address[0][5 : 3]};
        even_address1 = {cache_line[1][4 : 3], cache_line[1][1 : 0], word_address[1][5 : 3]};
        odd_address0 = even_address0;
        odd_address1 = even_address1;
        if(point_y[0][0])begin
            even_address0 = {cache_line[2][4 : 3], cache_line[2][1 : 0], word_address[2][5 : 3]};
            even_address1 = {cache_line[3][4 : 3], cache_line[3][1 : 0], word_address[3][5 : 3]};
        end
        else begin
            odd_address0 = {cache_line[2][4 : 3], cache_line[2][1 : 0], word_address[2][5 : 3]};
            odd_address1 = {cache_line[3][4 : 3], cache_line[3][1 : 0], word_address[3][5 : 3]};
        end
        selected_word[0] = point_y[0][0] ? odd_word0 : even_word0;
        selected_word[1] = point_y[1][0] ? odd_word1 : even_word1;
        selected_word[2] = point_y[2][0] ? odd_word0 : even_word0;
        selected_word[3] = point_y[3][0] ? odd_word1 : even_word1;
        assembled_pixels = saved_pixels;
        for(point = 0; point < 4; point = point + 1)begin
            selected_pixel[point] = selected_word[point][pixel_index[point][3 : 0] * 16 +: 16];
            if(state == PUBLISH)begin
                assembled_pixels[camera * 96 + point * 24 +: 24] =
                    {selected_pixel[point][15 : 11], 3'd0, selected_pixel[point][10 : 5],
                     2'd0, selected_pixel[point][4 : 0], 3'd0};
            end
        end
    end

    // All three cameras are prepared together. One setup cycle per request
    // separates camera selection, edge clamping and the 960-pixel row stride.
    // These registers are read only after PREPARE_INDEX has completed.
    always@(posedge clk)begin
        if(req_valid && req_ready)begin
            for(prepare_point = 0; prepare_point < 12; prepare_point = prepare_point + 1)begin
                prepared_x[prepare_point] <= req_uv[(prepare_point / 4) * 36 + 8 +: 10] +
                    ((prepare_point % 2 != 0 &&
                      req_uv[(prepare_point / 4) * 36 + 8 +: 10] < 959) ? 10'd1 : 10'd0);
                prepared_y[prepare_point] <= req_uv[(prepare_point / 4) * 36 + 26 +: 10] +
                    ((prepare_point % 4 >= 2 &&
                      req_uv[(prepare_point / 4) * 36 + 26 +: 10] < 539) ? 10'd1 : 10'd0);
            end
        end
        if(state == PREPARE_INDEX)begin
            for(prepare_point = 0; prepare_point < 12; prepare_point = prepare_point + 1)begin
                prepared_index[prepare_point] <= prepared_y[prepare_point] * 20'd960 + prepared_x[prepare_point];
            end
        end
    end

    // One read/write port and one read-only port on each row-parity bank.
    always@(posedge clk)begin
        if(state == FILL_CACHE && rvalid && !miss_line[2])begin
            cache_even[fill_address] <= rdata;
        end
        else if(read_cache)begin
            even_word0 <= cache_even[even_address0];
        end
        if(read_cache)begin
            even_word1 <= cache_even[even_address1];
        end
        if(state == FILL_CACHE && rvalid && miss_line[2])begin
            cache_odd[fill_address] <= rdata;
        end
        else if(read_cache)begin
            odd_word0 <= cache_odd[odd_address0];
        end
        if(read_cache)begin
            odd_word1 <= cache_odd[odd_address1];
        end
    end

    always@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            state           <= IDLE;
            cache_valid     <= 0;
            uv              <= 0;
            remaining       <= 0;
            pages           <= 0;
            camera          <= 0;
            miss_address    <= 0;
            miss_line       <= 0;
            beat            <= 0;
            saved_pixels    <= 0;
            burst_count     <= 0;
            protocol_errors <= 0;
        end
        else begin
            if(flush && state == IDLE)begin
                cache_valid <= 0;
            end
            case(state)
                IDLE:begin
                    if(req_valid && req_ready)begin
                        uv           <= req_uv;
                        remaining    <= req_mask;
                        pages        <= frame_pages;
                        camera       <= first_camera(req_mask);
                        saved_pixels <= 0;
                        state        <= PREPARE_INDEX;
                    end
                end
                PREPARE_INDEX:begin
                    state <= CHECK_POINTS;
                end
                CHECK_POINTS:begin
                    if(remaining == 0)begin
                        state <= RESPOND;
                    end
                    else if(&hit)begin
                        state <= PUBLISH;
                    end
                    else begin
                        miss_address <= word_address[first_missing];
                        miss_line    <= cache_line[first_missing];
                        state        <= READ_ADDRESS;
                    end
                end
                READ_ADDRESS:begin
                    if(arready)begin
                        beat        <= 0;
                        burst_count <= burst_count + 1'b1;
                        state       <= FILL_CACHE;
                    end
                end
                FILL_CACHE:begin
                    if(rvalid)begin
                        if(rlast != (beat == 7))begin
                            protocol_errors <= protocol_errors + 1'b1;
                            state <= FAILED;
                        end
                        else if(beat == 7)begin
                            cache_valid[miss_line] <= 1'b1;
                            cache_tag[miss_line]   <= miss_address[27 : 6];
                            state <= CHECK_POINTS;
                        end
                        else begin
                            beat <= beat + 1'b1;
                        end
                    end
                end
                PUBLISH:begin
                    saved_pixels <= assembled_pixels;
                    if(last_camera)begin
                        state <= RESPOND;
                    end
                    else begin
                        remaining <= next_remaining;
                        camera    <= first_camera(next_remaining);
                        state     <= CHECK_POINTS;
                    end
                end
                RESPOND:begin
                    if(rsp_ready)begin
                        state <= IDLE;
                    end
                end
                FAILED:begin
                    state <= FAILED;
                end
                default:begin
                    state <= IDLE;
                end
            endcase
        end
    end

endmodule
