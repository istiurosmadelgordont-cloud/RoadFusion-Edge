// Uniform 16x16 control grid, padded to x=1920 and y=544.
// Each node: bits35:18 v Q10.8, bits17:0 u Q10.8; all-ones is invalid.
// Parity banking permits four different corner nodes to be read on one clock.
module grid_coordinate_interp#(
    parameter   FILE_0                       =   "",
    parameter   FILE_1                       =   "",
    parameter   FILE_2                       =   "",
    parameter   FILE_3                       =   ""
)(
    input                   clk,
    input                   rst_n,
    input                   in_valid,
    input       [10 : 0]    in_x,
    input       [9 : 0]     in_y,
    output reg              out_valid,
    output reg              coordinate_valid,
    output reg  [17 : 0]    source_u,
    output reg  [17 : 0]    source_v
);

    wire        [6 : 0]     col;
    wire        [5 : 0]     row;
    reg                     base_valid;
    reg         [10 : 0]    address_base;
    reg         [1 : 0]     base_parity;
    reg         [4 : 0]     base_fx;
    reg         [4 : 0]     base_fy;
    wire        [10 : 0]    even_row_base;
    reg         [10 : 0]    address0_q;
    reg         [10 : 0]    address1_q;
    reg         [10 : 0]    address2_q;
    reg         [10 : 0]    address3_q;
    reg                     address_valid;
    reg         [1 : 0]     address_parity;
    reg         [4 : 0]     address_fx;
    reg         [4 : 0]     address_fy;
    wire        [35 : 0]    bank0;
    wire        [35 : 0]    bank1;
    wire        [35 : 0]    bank2;
    wire        [35 : 0]    bank3;
    reg         [35 : 0]    node00;
    reg         [35 : 0]    node10;
    reg         [35 : 0]    node01;
    reg         [35 : 0]    node11;
    reg         [7 : 0]     valid_pipe;
    reg         [7 : 1]     corners_pipe;
    reg         [1 : 0]     parity_s0;
    reg         [4 : 0]     fx_s0;
    reg         [4 : 0]     fy_s0;
    reg         [4 : 0]     fx_s1;
    reg         [4 : 0]     fy_pipe[1 : 4];
    reg         [35 : 0]    nodes_q[0 : 3];
    wire        [17 : 0]    horizontal_source[0 : 7];
    wire        [4 : 0]     horizontal_fraction[0 : 7];
    reg         [22 : 0]    horizontal_lo[0 : 7];
    reg         [22 : 0]    horizontal_hi[0 : 7];
    reg         [22 : 0]    horizontal_product[0 : 7];
    reg         [22 : 0]    horizontal_sum[0 : 3];
    wire        [4 : 0]     vertical_fraction[0 : 3];
    reg         [27 : 0]    vertical_lo[0 : 3];
    reg         [27 : 0]    vertical_hi[0 : 3];
    reg         [27 : 0]    vertical_product[0 : 3];
    reg         [27 : 0]    u_sum;
    reg         [27 : 0]    v_sum;
    integer                 stage;
    integer                 data_stage;
    genvar                  lane;

    // Split each shift/add multiplier across registers; no additional APMs.
    function [27 : 0] scale_low;
        input [22 : 0] value;
        input [4 : 0] fraction;
        reg   [27 : 0] extended_value;
        begin
            extended_value = {5'd0, value};
            scale_low = (fraction[0] ? extended_value : 28'd0) +
                        (fraction[1] ? extended_value << 1 : 28'd0);
        end
    endfunction

    function [27 : 0] scale_high;
        input [22 : 0] value;
        input [4 : 0] fraction;
        reg   [27 : 0] extended_value;
        begin
            extended_value = {5'd0, value};
            scale_high = ((fraction[2] ? extended_value << 2 : 28'd0) +
                          (fraction[3] ? extended_value << 3 : 28'd0)) +
                         (fraction[4] ? extended_value << 4 : 28'd0);
        end
    endfunction

    generate
        for(lane = 0; lane < 8; lane = lane + 1)begin : horizontal_inputs
            assign horizontal_source[lane] = lane < 4 ? nodes_q[lane % 4][17 : 0] :
                                                                       nodes_q[lane % 4][35 : 18];
            assign horizontal_fraction[lane] = lane % 2 == 0 ? 5'd16 - fx_s1 : fx_s1;
        end
        for(lane = 0; lane < 4; lane = lane + 1)begin : vertical_inputs
            assign vertical_fraction[lane] = lane % 2 == 0 ? 5'd16 - fy_pipe[4] : fy_pipe[4];
        end
    endgenerate

    assign col    = in_x[10 : 4];
    assign row    = in_y[9 : 4];
    // Address of the odd-row/odd-column bank is the shared cell base.
    // The even parity banks add one column and/or one bank row (61 nodes).
    assign even_row_base = address_base + (base_parity[1] ? 11'd61 : 11'd0);

    grid_node_rom#(
        .INIT_FILE          (FILE_0                 )
    )u_bank0(
        .clk                (clk                    ),
        .rd_en              (address_valid          ),
        .rd_addr            (address0_q             ),
        .rd_data            (bank0                  )
    );

    grid_node_rom#(
        .INIT_FILE          (FILE_1                 )
    )u_bank1(
        .clk                (clk                    ),
        .rd_en              (address_valid          ),
        .rd_addr            (address1_q             ),
        .rd_data            (bank1                  )
    );

    grid_node_rom#(
        .INIT_FILE          (FILE_2                 )
    )u_bank2(
        .clk                (clk                    ),
        .rd_en              (address_valid          ),
        .rd_addr            (address2_q             ),
        .rd_data            (bank2                  )
    );

    grid_node_rom#(
        .INIT_FILE          (FILE_3                 )
    )u_bank3(
        .clk                (clk                    ),
        .rd_en              (address_valid          ),
        .rd_addr            (address3_q             ),
        .rd_data            (bank3                  )
    );

    always@(*)begin
        case(parity_s0)
            2'd0:begin
                node00 = bank0;
                node10 = bank1;
                node01 = bank2;
                node11 = bank3;
            end
            2'd1:begin
                node00 = bank1;
                node10 = bank0;
                node01 = bank3;
                node11 = bank2;
            end
            2'd2:begin
                node00 = bank2;
                node10 = bank3;
                node01 = bank0;
                node11 = bank1;
            end
            default:begin
                node00 = bank3;
                node10 = bank2;
                node01 = bank1;
                node11 = bank0;
            end
        endcase
    end

    // Eleven registered stages, including address setup and synchronous ROM read.
    // Pixel tags in grid_fusion_top are delayed by the same eleven stages.
    always@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            base_valid       <= 0;
            address_valid    <= 0;
            valid_pipe       <= 0;
            corners_pipe     <= 0;
            out_valid        <= 0;
            coordinate_valid <= 0;
            parity_s0        <= 0;
            fx_s0            <= 0;
            fy_s0            <= 0;
            fx_s1            <= 0;
            source_u         <= 0;
            source_v         <= 0;
        end
        else begin
            base_valid    <= in_valid;
            address_valid <= base_valid;
            valid_pipe <= {valid_pipe[6 : 0], address_valid};
            out_valid  <= valid_pipe[7];
            if(address_valid)begin
                parity_s0 <= address_parity;
                fx_s0     <= address_fx;
                fy_s0     <= address_fy;
            end
            if(valid_pipe[0])begin
                fx_s1 <= fx_s0;
                corners_pipe[1] <=
                    (node00[17 : 0] <= 245504 && node00[35 : 18] <= 137984) &&
                    (node10[17 : 0] <= 245504 && node10[35 : 18] <= 137984) &&
                    (node01[17 : 0] <= 245504 && node01[35 : 18] <= 137984) &&
                    (node11[17 : 0] <= 245504 && node11[35 : 18] <= 137984);
            end
            for(stage = 2; stage < 8; stage = stage + 1)begin
                corners_pipe[stage] <= corners_pipe[stage - 1];
            end
            if(valid_pipe[7])begin
                source_u <= u_sum[25 : 8];
                source_v <= v_sum[25 : 8];
                coordinate_valid <= corners_pipe[7] && (u_sum >> 8) <= 28'd245504 &&
                                                      (v_sum >> 8) <= 28'd137984;
            end
        end
    end

    // Register the row stride before parity-bank offset arithmetic. Keeping
    // logic between these registers and the ROM prevents RAM register folding
    // from restoring the original render_y-to-ROM address critical path.
    always@(posedge clk)begin
        if(in_valid)begin
            address_base <= row[5 : 1] * 11'd61 + col[6 : 1];
            base_parity  <= {row[0], col[0]};
            base_fx      <= {1'b0, in_x[3 : 0]};
            base_fy      <= {1'b0, in_y[3 : 0]};
        end
        if(base_valid)begin
            address0_q     <= even_row_base + {10'd0, base_parity[0]};
            address1_q     <= even_row_base;
            address2_q     <= address_base + {10'd0, base_parity[0]};
            address3_q     <= address_base;
            address_parity <= base_parity;
            address_fx     <= base_fx;
            address_fy     <= base_fy;
        end
    end

    // Data registers are qualified by valid_pipe and do not need reset trees.
    always@(posedge clk)begin
        if(valid_pipe[0])begin
            nodes_q[0] <= node00;
            nodes_q[1] <= node10;
            nodes_q[2] <= node01;
            nodes_q[3] <= node11;
        end
        fy_pipe[1] <= fy_s0;
        for(data_stage = 2; data_stage < 5; data_stage = data_stage + 1)begin
            fy_pipe[data_stage] <= fy_pipe[data_stage - 1];
        end
        for(data_stage = 0; data_stage < 8; data_stage = data_stage + 1)begin
            horizontal_lo[data_stage] <= scale_low({5'd0, horizontal_source[data_stage]},
                                              horizontal_fraction[data_stage]);
            horizontal_hi[data_stage] <= scale_high({5'd0, horizontal_source[data_stage]},
                                               horizontal_fraction[data_stage]);
            horizontal_product[data_stage] <= horizontal_lo[data_stage] + horizontal_hi[data_stage];
        end
        for(data_stage = 0; data_stage < 4; data_stage = data_stage + 1)begin
            horizontal_sum[data_stage] <= horizontal_product[data_stage * 2] +
                                     horizontal_product[data_stage * 2 + 1];
            vertical_lo[data_stage] <= scale_low(horizontal_sum[data_stage], vertical_fraction[data_stage]);
            vertical_hi[data_stage] <= scale_high(horizontal_sum[data_stage], vertical_fraction[data_stage]);
            vertical_product[data_stage] <= vertical_lo[data_stage] + vertical_hi[data_stage];
        end
        u_sum <= vertical_product[0] + vertical_product[1] + 28'd128;
        v_sum <= vertical_product[2] + vertical_product[3] + 28'd128;
    end

endmodule
