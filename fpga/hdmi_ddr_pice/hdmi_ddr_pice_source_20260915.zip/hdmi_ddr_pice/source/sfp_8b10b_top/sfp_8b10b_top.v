//****************************************Copyright (c)***********************************//
//ԭ�Ӹ����߽�ѧƽ̨��www.yuanzige.com
//����֧�֣�http://www.openedv.com/forum.php
//�Ա����̣�https://zhengdianyuanzi.tmall.com
//��ע΢�Ź���ƽ̨΢�źţ�"����ԭ��"����ѻ�ȡZYNQ & FPGA & STM32 & LINUX���ϡ�
//��Ȩ���У�����ؾ���
//Copyright(C) ����ԭ�� 2023-2033
//All rights reserved                                  
//----------------------------------------------------------------------------------------
// File name:           sfp_8b10b_top
// Created by:          ����ԭ��
// Created date:        2023��2��3��14:17:02
// Version:             V1.0
// Descriptions:        sfp_8b10b_top
//
//----------------------------------------------------------------------------------------
//****************************************************************************************//

module sfp_8b10b_top(
    //��ڽӿ�
    input           i_p_refckn_0,              //��ֲο�ʱ��
    input           i_p_refckp_0,
    input           i_p_l2rxn,                 //��ֽ�������
    input           i_p_l2rxp,
    input           i_p_l3rxn,                   
    input           i_p_l3rxp,
    output          o_p_l2txn,                 //��ַ�������
    output          o_p_l2txp,
    output          o_p_l3txn,
    output          o_p_l3txp,
    output  [1:0]   tx_disable,	               //tx�˷��ͽ�ֹʹ��
	//�û��ӿ�
	input           drp_clk,                   //�������ʱ��  
	input           clk_in,                    //����ʱ��
	input           rst_n,                     //���븴λ
	input	[10:0]	h_pixel,                   //����������
	input           vs_in,	                   //���볡�ź�
	input           data_valid_in,	           //����������Ч�ź�
	input   [15:0]  data_in,	               //��������

	output          o_vs/* synthesis syn_keep="1" */,	                   //������ź�
	output          data_valid_out,	           //���������Ч�ź�
	output  [15:0]  data_out	               //�������   
    );
//localparam define     
localparam VS_POSE_DATA1	=	32'h55a101bc;
localparam VS_POSE_DATA2	=	32'h55a102bc;	
localparam DATA_START1      =	32'h55a105bc;
localparam DATA_START2      =	32'h55a106bc;
localparam DATA_END1        =	32'h55a107bc;
localparam DATA_END2	    =	32'h55a108bc;
localparam UNUSE_DATA	    =	32'h55a109bc; 

//wire define    
wire	    tx0_user_clk; 
wire        tx0_rst_n; 
wire [3:0]  tx0_gt_txcharisk/* synthesis syn_keep="1" */;
wire [31:0] tx0_gt_txdata/* synthesis syn_keep="1" */;
wire		rx1_user_clk/* synthesis syn_keep="1" */; 
wire		rx1_rst_n; 
wire [3:0]  rx1_gt_rxcharisk;
wire [31:0] rx1_gt_rxdata;  
wire [3:0]  rx1_charisk_align/* synthesis syn_keep="1" */;
wire [31:0] rx1_data_align/* synthesis syn_keep="1" */; 
wire        i_wtchdg_clr_0 /* synthesis syn_keep="1" */;
wire        pll_rst_d;
wire        i_pll_rst_0/* synthesis syn_keep="1" */;
wire        i_p_cfg_rst;
wire		o_pll_done_0 /* synthesis syn_keep="1" */ ;

//*****************************************************
//**                    main code
//*****************************************************
 
assign     tx_disable 	 = 2'b00;
assign     i_p_cfg_rst	 = ~rst_n;
assign     i_pll_rst_0	 = pll_rst_d;
assign     pll_rst_d  	 = i_p_cfg_rst;
assign     i_wtchdg_clr_0 = pll_rst_d;

//��ڱ���ģ��
sfp_encoder#(
	.VS_POSE_DATA1	    (VS_POSE_DATA1	),
	.VS_POSE_DATA2	    (VS_POSE_DATA2	),	
	.DATA_START1	    (DATA_START1	),
	.DATA_START2	    (DATA_START2	),
	.DATA_END1   	    (DATA_END1   	),
	.DATA_END2	        (DATA_END2	    ),
	.UNUSE_DATA	        (UNUSE_DATA	    )
)
u_sfp_encoder(
	.clk_in             (clk_in         ),  //����ʱ��
	.rst_n              (rst_n          ),  //���븴λ
    .h_pixel            (h_pixel        ),  //����������
	.vs_in              (vs_in          ),  //���볡�ź� 
	.data_valid_in      (data_valid_in  ),  //����������Ч�ź�
	.data_in            (data_in        ),  //��������
	.tx_clk             (tx0_user_clk   ),  //���tx��ʱ��
	.tx_rst_n           (tx0_rst_n      ),  //���tx�˸�λ
            
	.gt_txcharisk       (tx0_gt_txcharisk), //���tx��K�뷢���ź�
	.gt_txdata	        (tx0_gt_txdata  )   //���tx�˷�������
); 

//��ڽ���ģ��    
sfp_decode#(
	.VS_POSE_DATA1	    (VS_POSE_DATA1	),
	.VS_POSE_DATA2	    (VS_POSE_DATA2	),	
	.DATA_START1	    (DATA_START1	),
	.DATA_START2	    (DATA_START2	),
	.DATA_END1   	    (DATA_END1   	),
	.DATA_END2	        (DATA_END2	    ),
	.UNUSE_DATA	        (UNUSE_DATA	    )
)
u_sfp_decode(
	.clk_in             (clk_in         ),
	.rst_n              (rst_n          ),
    .rx_clk             (rx1_user_clk   ),
	.rx_rst_n           (rx1_rst_n      ),
	.rx_charisk_align   (rx1_charisk_align),
	.rx_data_align      (rx1_data_align ),
        
	.o_vs               (o_vs           ),
	.data_valid_out     (data_valid_out ),
	.data_out           (data_out       )
);   
    
//����ֶ���ģ��    
sfp_data_align u_sfp_data_align(
	.clk_in             (rx1_user_clk   ),  //rx��ʱ��
	.rst_n			    (rx1_rst_n      ),  //rx�˸�λ
	.rx_data_in		    (rx1_gt_rxdata  ),  //rx��K��δУ�������ź�
	.rx_charisk_in	    (rx1_gt_rxcharisk), //rx��δУ����������
    
	.rx_data_out	    (rx1_data_align ),  //rx��K��У��������ź�
	.rx_charisk_out	    (rx1_charisk_align) //rx��У����������
);   


hsst hsst (
    .i_free_clk         (drp_clk		),
    .i_pll_rst_0        (i_pll_rst_0	),
    .i_wtchdg_clr_0     (i_wtchdg_clr_0 ),
    .o_wtchdg_st_0      (),               
    .o_pll_done_0       (o_pll_done_0				),
    .o_txlane_done_2    (tx0_rst_n		),
    .o_txlane_done_3    (),              
    .o_rxlane_done_2    (),              
    .o_rxlane_done_3    (rx1_rst_n		),
    .i_p_refckn_0       (i_p_refckn_0	),
    .i_p_refckp_0       (i_p_refckp_0	),
    .o_p_clk2core_tx_2  (tx0_user_clk	),
    .o_p_clk2core_tx_3  (rx1_user_clk	),
    .i_p_tx2_clk_fr_core(tx0_user_clk	),
    .i_p_tx3_clk_fr_core(1'b0			),
    .i_p_rx2_clk_fr_core(1'b0			),
    .i_p_rx3_clk_fr_core(rx1_user_clk	),
    .o_p_pll_lock_0     (),               
    .o_p_rx_sigdet_sta_2(),   
    .o_p_rx_sigdet_sta_3(),   
    .o_p_lx_cdr_align_2 (),   
    .o_p_lx_cdr_align_3 (),   
    .o_p_pcs_lsm_synced_2(),  
    .o_p_pcs_lsm_synced_3(),  
    .i_p_l2rxn          (i_p_l2rxn		),   
    .i_p_l2rxp          (i_p_l2rxp		),   
    .i_p_l3rxn          (i_p_l3rxn		),   
    .i_p_l3rxp          (i_p_l3rxp		),   
    .o_p_l2txn          (o_p_l2txn		),   
    .o_p_l2txp          (o_p_l2txp		),   
    .o_p_l3txn          (o_p_l3txn		),   
    .o_p_l3txp          (o_p_l3txp		),   
    .i_txd_2            (tx0_gt_txdata  ),   
    .i_tdispsel_2       (4'd0			),   
    .i_tdispctrl_2      (4'd0			),   
    .i_txk_2            (tx0_gt_txcharisk),  
    .i_txd_3            (32'd0 			),   
    .i_tdispsel_3       (4'd0			),   
    .i_tdispctrl_3      (4'd0			),   
    .i_txk_3            (4'd0			),   
    .o_rxstatus_2       (),                  
    .o_rxd_2            (),                  
    .o_rdisper_2        (),                  
    .o_rdecer_2         (),                  
    .o_rxk_2            (),                  
    .o_rxstatus_3       (),                  
    .o_rxd_3            (rx1_gt_rxdata	),   
    .o_rdisper_3        (),                  
    .o_rdecer_3         (),                  
    .o_rxk_3            (rx1_gt_rxcharisk)   
);

endmodule
