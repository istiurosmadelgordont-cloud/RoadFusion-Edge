
module sfp_decode#(
	parameter VS_POSE_DATA1	=	32'h55a101bc,
	parameter VS_POSE_DATA2	=	32'h55a102bc,		
	parameter DATA_START1   =	32'h55a105bc,
	parameter DATA_START2   =	32'h55a106bc,
	parameter DATA_END1     =	32'h55a107bc,
	parameter DATA_END2	    =	32'h55a108bc,
	parameter UNUSE_DATA   	=	32'h55a109bc

)	
(
	input			    clk_in /* synthesis syn_keep="1" */,
	input               rst_n,
	output  reg         o_vs/* synthesis syn_keep="1" */,           //������ź�
	output  reg     	data_valid_out,   //���������Ч�ź�
	output      [15:0]  data_out,         //��������ź�
	
	input    		    rx_clk/* synthesis syn_keep="1" */,
	input               rx_rst_n,
	input       [3:0]   rx_charisk_align/* synthesis syn_keep="1" */, //rx��K��У��������ź�
	input       [31:0]  rx_data_align/* synthesis syn_keep="1" */     //rx��У���������� 
	
);
//reg define 
reg 		sfp_line_end_t;
reg 		sfp_line_end_t1;

reg [7:0]	data_end_en_d;
reg 		sfp_line_end;
reg [7:0]	cnt_vs;	
reg 		data_start_en/* synthesis syn_keep="1" */;	
reg 		data_end_en/* synthesis syn_keep="1" */;
reg 		fifo_wren;	
reg [31:0]	fifo_datain;
reg     	fifo_rd_en;

reg [31:0]	rx_data_align_d0;
reg [3:0]	rx_charisk_align_d0;
reg [31:0]	rx_data_align_d1;
reg [3:0]	rx_charisk_align_d1;
reg [3:0]	data_start_en_d;

//wire define 	
wire [12:0]  rd_water_level;
	
//*****************************************************
//**                    main code
//*****************************************************

//����������ݽ��д���
always@(posedge rx_clk or negedge rx_rst_n)begin
	if(!rx_rst_n)begin		
		rx_charisk_align_d0 <= 1'b0;
		rx_data_align_d0 <= 16'd0;	
		rx_charisk_align_d1 <= 1'b0;
		rx_data_align_d1 <= 16'd0;							
	end
	else begin		
		rx_charisk_align_d0 <= rx_charisk_align;
		rx_data_align_d0 <= rx_data_align;		
		rx_charisk_align_d1 <= rx_charisk_align_d0;
		rx_data_align_d1 <= rx_data_align_d0;					
	end
end	

//�����ݽ��տ�ʼ�ͽ����źŽ�����λ
always@(posedge rx_clk or negedge rx_rst_n)begin
	if(!rx_rst_n)begin	
		data_end_en_d <= 8'd0;
		data_start_en_d <= 4'd0;
	end						
	else begin
		data_end_en_d <= {data_end_en_d[6:0],data_end_en};
		data_start_en_d <= {data_start_en_d[2:0],data_start_en};			
	end			
end	

//����һ�����ݽ��ս����ź�
always@(posedge rx_clk or negedge rx_rst_n)begin
	if(!rx_rst_n)	
		sfp_line_end <= 1'd0;					
	else if(data_end_en_d >0)
		sfp_line_end <= 1'd1;
    else
		sfp_line_end <= 1'd0;	
end	

//����������ź�
always@(posedge rx_clk or negedge rx_rst_n)begin
	if(!rx_rst_n)begin		
		o_vs <= 1'b0;	
		cnt_vs <= 8'h0;		
	end	
	else if((rx_charisk_align == 4'd1) && (rx_data_align == VS_POSE_DATA2) 
		&& ((rx_data_align_d0 == VS_POSE_DATA1)))begin
		o_vs <= 1'b1;	
		cnt_vs <= 8'h0;
	end
	else if(cnt_vs >= 100)begin
			o_vs <= 1'b0;	
			cnt_vs <= cnt_vs;	
	end			
	else begin
			o_vs <= o_vs;
			cnt_vs <= cnt_vs + 1;			
	end		
end		
	
//�������ݽ��տ�ʼ�ź�	
always@(posedge rx_clk or negedge rx_rst_n)begin
	if(!rx_rst_n)begin		
		data_start_en <= 1'b0;		
	end	
	else if((rx_charisk_align == 4'd1) && (rx_data_align == DATA_START2) 
		&& ((rx_data_align_d0 == DATA_START1)))begin
		data_start_en <= 1'b1;
	end		
	else begin
		data_start_en <= 1'b0;		
	end		
end	

//�������ݽ��ս����ź�		
always@(posedge rx_clk or negedge rx_rst_n)begin
	if(!rx_rst_n)begin		
		data_end_en <= 1'b0;		
	end	
	else if((rx_charisk_align == 4'd1) && (rx_data_align == DATA_END2) 
		&& ((rx_data_align_d0 == DATA_END1)))begin
		data_end_en <= 1'b1;
	end		
	else begin
		data_end_en <= 1'b0;		
	end		
end	

//����fifoдʹ��	
always@(posedge rx_clk or negedge rx_rst_n)begin
	if(!rx_rst_n)	
		fifo_wren <= 1'b0;		
	else if(data_start_en_d[1]) 
		fifo_wren <= 1'b1;	
	else if(data_end_en) 
		fifo_wren <= 1'b0;		
	else 
		fifo_wren <= fifo_wren;			
end	

//����fifoд����
always@(posedge rx_clk or negedge rx_rst_n)begin
	if(!rx_rst_n)	
		fifo_datain <= 32'b0;		
	else 
		fifo_datain <= rx_data_align_d1;					
end		
	
/*****************������*****************************/
	
//��һ�����ݽ��ս����źŽ���ʱ�����л�
always@(posedge clk_in or negedge rst_n)begin
	if(!rst_n)begin	
		sfp_line_end_t <= 1'b0;	
		sfp_line_end_t1 <= 1'b0;			
    end		
	else begin
		sfp_line_end_t  <= sfp_line_end;
		sfp_line_end_t1 <= sfp_line_end_t;		
    end		
end	

//����fifo��ʹ��
always@(posedge clk_in or negedge rst_n)begin
	if(!rst_n)
		fifo_rd_en <= 1'b0;					
	else begin
		if(sfp_line_end_t1)	
			fifo_rd_en <= 1'b1;	
        else if(rd_water_level <= 1)
			fifo_rd_en <= 1'b0;	
        else
			fifo_rd_en <= fifo_rd_en;			
    end		
end	

//�������������Ч�ź�
always@(posedge clk_in or negedge rst_n)begin
	if(!rst_n)
		data_valid_out <= 1'b0;					
	else 
		data_valid_out <= fifo_rd_en;			
end				

wire  ful    /* synthesis syn_keep="1" */ ;
sfp_rx_32x2048 u_sfp_rx_32x2048 (
    .wr_clk            (rx_clk),          
    .wr_rst            (o_vs),          
    .wr_en             (fifo_wren),       
    .wr_data           (fifo_datain),     
    .wr_full           (ful ),            
    .almost_full       ( ),      
    .rd_clk            (clk_in),          
    .rd_rst            (o_vs),          
    .rd_en             (fifo_rd_en),      
    .rd_data           (data_out),        
    .rd_empty          (fifo_empty),        
    .rd_water_level    (rd_water_level),  
    .almost_empty      (fifo_almost_empty)
);

endmodule
